/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.lock;

import com.zb.framework.enums.BizCode;
import com.zb.framework.exception.BizException;

import java.io.Serializable;

/**
 * Created by  on 2015/9/9.
 */
public class LockFailException extends BizException implements Serializable {
    private static final long serialVersionUID = -7124118043544775249L;

    public LockFailException() {
        super();
    }

    public LockFailException(BizCode code, String message) {
        super(code, message);
    }

    public LockFailException(BizCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public LockFailException(BizCode code, Throwable cause) {
        super(code, cause);
    }

    public LockFailException(boolean ignoreStackTrace) {
        super(ignoreStackTrace);
    }

    public LockFailException(BizCode code, String message, boolean ignoreStackTrace) {
        super(code, message, ignoreStackTrace);
    }

    public LockFailException(BizCode code, String message, Throwable cause, boolean ignoreStackTrace) {
        super(code, message, cause, ignoreStackTrace);
    }

    public LockFailException(BizCode code, Throwable cause, boolean ignoreStackTrace) {
        super(code, cause, ignoreStackTrace);
    }
}
