package com.zb.framework.framework.flow;

import com.zb.framework.base.AbstractResponse;
import com.zb.framework.framework.flow.enums.PhaseCode;

/**
 * Pipe line执行接口<br/>
 *
 * Created by  2014/12/10.
 */
public interface OutboundInvoker extends OutboundProperty {
    /**
     * 启动流程<br/>
     *
     */
    void start();

    /**
     * 执行到指定的阶段（phase），跳过之前的阶段（phase）<br/>
     *
     */
    void start(PhaseCode phase);

    /**
     * 辅助函数，用于简化返回值的转换操作<br/>
     *
     * @return
     */
    <TRes extends AbstractResponse>
    TRes toResponse();
}
