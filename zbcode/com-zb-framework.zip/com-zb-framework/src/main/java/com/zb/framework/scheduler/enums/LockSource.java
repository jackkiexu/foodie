/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.scheduler.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * Created by  2015/4/21.
 */
public class LockSource extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = 6503091028475442774L;

    public static final LockSource Exception = new LockSource("Exception", "异常数据扫描");

    protected LockSource() {
        super();// 解决反序列化无法构造新实例的问题！！
    }

    protected LockSource(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return LockSource.class;
    }
}
