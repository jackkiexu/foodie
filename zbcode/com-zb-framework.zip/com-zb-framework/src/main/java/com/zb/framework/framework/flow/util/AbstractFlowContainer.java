package com.zb.framework.framework.flow.util;

import com.zb.framework.enums.BizCode;
import com.zb.framework.util.CoreCommonUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by  2014/12/12.
 */
public abstract class AbstractFlowContainer<T> implements FlowContainer<T> {
    private ArrayList<T> _list = null;

    public AbstractFlowContainer(int capacity) {
        if(capacity < 0) {
            CoreCommonUtils.raiseBizException(BizCode.ParamGE0
                    , "容量必须大于等于0， capacity = " + capacity);
        }

        _list = new ArrayList<T>(capacity);
    }

    @Override
    public boolean add(T field) {
        return _list.add(field);
    }

    @Override
    public int size() {
        return _list.size();
    }

    @Override
    public List<T> toList() {
        return Collections.unmodifiableList(_list);
    }

    @Override
    public void ensureCapacity(int minCapacity) {
        _list.ensureCapacity(minCapacity);
    }

    @Override
    public void expandCapacity(int addedCapacity) {
        _list.ensureCapacity(_list.size() + addedCapacity);
    }

    @Override
    public boolean isEmpty() {
        return _list.isEmpty();
    }
}
