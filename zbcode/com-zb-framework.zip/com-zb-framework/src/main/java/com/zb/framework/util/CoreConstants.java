package com.zb.framework.util;

/**
 * Created by  2015/3/5.
 */
public class CoreConstants {
    /**
     * 监控Log的名称<br/>
     *
     */
    public static final String Monitor_Log_Name = "monitor_log";

    /**
     * perf Log的名称<br/>
     *
     */
    public static final String Perf_Log_Name = "perf_log";

    /**
     * digist Log的名称<br/>
     *
     */
    public static final String Digist_Log_Name = "digest_log";
    /**
     * dal 日志
     */
    public static final String Digist_Dal_Log_Name = "dal_digest_log";
    /**
     * provider 日志
     */
    public static final String Digist_Service_Log_Name = "service_digest_log";
    /**
     * consumer 日志
     */
    public static final String Digist_Remote_Log_Name = "remote_digest_log";


    /**
     * 当前线程UUID键值<br/>
     *
     */
    public static final String Curr_Thread_Uuid_Key = "__thread_uuid__";

    /**
     * 当前线程Second UUID键值<br/>
     *
     */
    public static final String Curr_Thread_Uuidb_Key = "__thread_uuidb__";

    /**
     * 当前线程App Name键值<br/>
     *
     */
    public static final String Curr_Thread_AppName_Key = "__thread_app_name__";

    public static final String MQ_TAGS = "TAGS";

    public static final String MQ_KEYS = "KEYS";


    public static final String DIGIST_METHOD = "method";
}
