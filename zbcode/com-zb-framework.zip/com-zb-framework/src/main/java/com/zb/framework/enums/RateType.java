/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import java.io.Serializable;

import com.zb.framework.base.AbstractEnum;

/**
 * 
 * @author 
 * @version $Id: RateTypeCode.java, v 0.1 2015年7月1日 下午3:48:21  Exp $
 */
public class RateType extends AbstractEnum implements Serializable{
    /**  */
    private static final long serialVersionUID = 1L;
    
    public static final RateType Percent=new RateType("1","百分比");
    public static final RateType Signal=new RateType("2","单笔");

    protected RateType(){
        ;
    }

    protected RateType(String name,String desc){
        super(name,desc);
    }
    
    /** 
     * @see com.zb.framework.base.AbstractEnum#getEnumType()
     */
    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return RateType.class;
    }

}
