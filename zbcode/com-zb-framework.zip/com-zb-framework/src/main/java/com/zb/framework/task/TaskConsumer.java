/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.task;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 
 * 
 * @author 
 * @version $Id: TaskConsumer.java, v 0.1 2015年2月6日 上午9:54:10  Exp $
 */
public class TaskConsumer {

	private static final Logger logger = LoggerFactory.getLogger(TaskConsumer.class);

	private int poolSize;

	private BlockingQueue<Task<?>> queue;
	
	

	public TaskConsumer(int poolSize, BlockingQueue<Task<?>> queue) {
		this.poolSize = poolSize;
		this.queue = queue;
		logger.info("初始化线程池大小为" + this.poolSize + "......");
	}

	/**
	 * 线程池.
	 */
	private ExecutorService executor;
	


	private void consume() {
		logger.info("初始化线程池......");
		this.executor =Executors.newFixedThreadPool(poolSize);
		TaskExecutor tskExecutor=null;
		for(int i=0;i<poolSize;i++){
		    tskExecutor=new TaskExecutor(queue);
		    executor.execute(tskExecutor);
		}
		logger.info("完成线程池初始化......");
	}
	
	public void start() {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
				consume();
			}
		});
	}
	
	public void destory(){
	    logger.info("开始销毁线程[{}]....",this.getClass().getName());
	    try{
    	    if(executor!=null){
    	        executor.shutdown();
    	    }
	    }catch(Exception e){
	        logger.error("线程销毁异常",e);
	    }
	    
	   
	}
	

}
