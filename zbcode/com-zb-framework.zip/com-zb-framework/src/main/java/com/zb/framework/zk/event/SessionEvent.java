/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.event;

import org.apache.zookeeper.Watcher;

/**
 * Created by  2015/4/28.
 */
public class SessionEvent extends EventObject {
    @Override
    public String toString() {
        return "SessionEvent{} " + super.toString();
    }
}
