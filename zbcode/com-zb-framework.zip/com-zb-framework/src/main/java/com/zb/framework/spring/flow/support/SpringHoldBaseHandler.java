/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.spring.flow.support;

import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.Listener;
import com.zb.framework.framework.flow.enums.PhaseCode;
import com.zb.framework.framework.flow.handler.AbstractUnskippableHandler;
import com.zb.framework.framework.flow.util.FlowContainer;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;

/**
 * Created by  2015/4/24.
 */
public abstract class SpringHoldBaseHandler extends AbstractUnskippableHandler implements Handler, ApplicationContextAware, InitializingBean {
    /**
     * 事务模板类型<br/>
     *
     */
    private TransactionTemplate transactionTemplate = null;

    /**
     * spring容器实例<br/>
     *
     */
    private ApplicationContext applicationContext = null;

    /**
     * 事务管理器<br/>
     *
     */
    private PlatformTransactionManager transactionManager = null;

    /**
     * 是否支持事务<br/>
     *
     */
    private Boolean enableTransaction = null;

    /**
     * 监听器<br/>
     *
     */
    private List<Listener> listeners = null;

    @Override
    protected abstract boolean doHandle(final Context context, AbstractFlowVo callerParam);

    @Override
    public PhaseCode getPhaseCode() {
        return null;
    }

    public TransactionTemplate getTransactionTemplate() {
        return transactionTemplate;
    }

    public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }

    public Boolean getEnableTransaction() {
        return isEnableTransaction()
                || transactionManager != null || transactionTemplate != null;
    }

    public PlatformTransactionManager getTransactionManager() {
        return transactionManager;
    }

    public void setTransactionManager(PlatformTransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }

    public void setEnableTransaction(Boolean enableTransaction) {
        this.enableTransaction = enableTransaction;
    }

    private boolean isEnableTransaction() {
        return (enableTransaction != null && enableTransaction);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    public void setListeners(List<Listener> listeners) {
        this.listeners = listeners;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if(transactionManager != null && transactionTemplate == null) {
            transactionTemplate = createTemplate(transactionManager);
        }

        if(isEnableTransaction() && transactionTemplate == null) {
            try {
                transactionTemplate = applicationContext.getBean(TransactionTemplate.class);
            } catch (BeansException e) {
                transactionTemplate = createTemplate(applicationContext.getBean(PlatformTransactionManager.class));
            }
        }
    }

    private TransactionTemplate createTemplate(PlatformTransactionManager manager) {
        TransactionTemplate transactionTemplate = new TransactionTemplate(manager);
        transactionTemplate.afterPropertiesSet();

        return transactionTemplate;
    }

    @Override
    protected void fillListeners(FlowContainer<Listener> container) {
        super.fillListeners(container);

        // 获取被代理handler的监听器；
        List<Listener> proxyListeners = getProxyListeners();
        for(Listener listener : proxyListeners) {
            container.add(listener);
        }

        if(listeners == null) {
            return;
        }

        for(Listener listener : listeners) {
            container.add(listener);
        }
    }

    /**
     * 代理方法的监听器列表<br/>
     *
     * @return
     */
    protected abstract List<Listener> getProxyListeners();

    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }
}
