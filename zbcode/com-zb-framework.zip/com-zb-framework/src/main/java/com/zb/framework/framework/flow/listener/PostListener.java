package com.zb.framework.framework.flow.listener;

import com.zb.framework.framework.flow.Listener;
import com.zb.framework.framework.flow.OutboundProperty;

/**
 * Handler已经处理完成后监听器<br/>
 *
 * Created by  2014/6/16.
 */
public interface PostListener extends Listener {
    /**
     * 执行后（没有异常的情况下）需要处理的逻辑<br/>
     *
     * @param outboundProperty
     */
    void onExecuted(OutboundProperty outboundProperty);
}
