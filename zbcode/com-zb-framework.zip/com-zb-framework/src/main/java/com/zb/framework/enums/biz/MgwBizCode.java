/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 
 * @author 
 * @version $Id: MgwBizCode.java, v 0.1 2015年5月24日 下午5:22:45  Exp $
 */
public class MgwBizCode extends BizCode implements Serializable{

    /**  */
    private static final long serialVersionUID = -772563438720172844L;
    
    public static final MgwBizCode MGW_CacheRefresh_Fail=new MgwBizCode("MGW_CacheRefresh_Fail",ServiceCode.MGW,"001","缓存刷新失败");
    
    protected MgwBizCode() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    public MgwBizCode(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }

}
