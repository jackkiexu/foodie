package com.zb.framework.enums;



import java.io.Serializable;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

/**
 * 公司提供的服务编码<br/>
 *
 * Created by  2014/12/10.
 */
public final class ServiceCode extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = -8627571253482855889L;

    public static final ServiceCode PHONY = new ServiceCode("PHONY", "000", "默认系统");

    public static final ServiceCode TransCore = new ServiceCode("TransCore", "001", "交易核心");

    public static final ServiceCode Risk = new ServiceCode("Risk", "002", "安全中心");

    public static final ServiceCode BankEngine = new ServiceCode("BankEngine", "003", "银行引擎");

    public static final ServiceCode TATrade = new ServiceCode("TATrade", "004", "TA交易");

    public static final ServiceCode BOSS = new ServiceCode("BOSS", "005", "BOSS系统");
    
    public static final ServiceCode PayCore = new ServiceCode("PayCore", "006", "支付核心");

    public static final ServiceCode AccTrans = new ServiceCode("AccTrans", "007", "账务中心");

    public static final ServiceCode Merchant = new ServiceCode("Merchant", "008", "商户中心");

    public static final ServiceCode Cif = new ServiceCode("Cif", "009", "会员中心");
    
    public static final ServiceCode Cashier = new ServiceCode("Cashier", "010", "收银台");

    public static final ServiceCode Asset = new ServiceCode("Asset", "011", "资产中心");

    public static final ServiceCode Mobile = new ServiceCode("Mobile", "012", "移动");

    public static final ServiceCode Personal = new ServiceCode("Personal", "013", "主站");

    public static final ServiceCode PaymentFeis = new ServiceCode("PaymentFeis", "014", "签约中心");
    
    public static final ServiceCode Fxo = new ServiceCode("Fxo", "015", "资金流出");
    
    public static final ServiceCode Fxi = new ServiceCode("Fxi", "016", "资金流入");

    public static final ServiceCode Accounting = new ServiceCode("Accounting", "017", "会计核算");

    public static final ServiceCode Frecon = new ServiceCode("Frecon", "018", "网关对账");

    public static final ServiceCode Arecon = new ServiceCode("Arecon", "019", "资金对账");
    
    public static final ServiceCode Bcdc = new ServiceCode("Bcdc", "020", "银行签约");
    
    public static final ServiceCode Ccdc = new ServiceCode("Ccdc", "021", "银行卡加解密");
    
    public static final ServiceCode CardBin = new ServiceCode("CardBin", "022", "卡Bin系统");
    
    public static final ServiceCode Fmd = new ServiceCode("Fmd", "023", "主数据系统");
    
    public static final ServiceCode Diamond = new ServiceCode("Diamond", "024", "配置中心");

    public static final ServiceCode Currency = new ServiceCode("Currency", "025", "货币基金支付中心");
    
    public static final ServiceCode BCM = new ServiceCode("BCM", "026", "银行证书管理");
    
    public static final ServiceCode MGW = new ServiceCode("MGW", "027", "报文网关");

    public static final ServiceCode XTS = new ServiceCode("XTS", "028", "分布式事务系统");
    
    public static final ServiceCode Router = new ServiceCode("Router", "029", "渠道路由");
    
    public static final ServiceCode Decision = new ServiceCode("Decision", "030", "支付决策");

    public static final ServiceCode Basic = new ServiceCode("Basic", "031", "沟通平台");

    public static final ServiceCode Bonus = new ServiceCode("Bonus", "032", "红包营销");

    public static final ServiceCode Product = new ServiceCode("Product", "033", "产品中心");

    public static final ServiceCode Charge = new ServiceCode("Charge", "034", "收费中心");

    public static final ServiceCode ProductBook = new ServiceCode("ProductBook", "035", "产品账");

    protected ServiceCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    private ServiceCode(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return ServiceCode.class;
    }
}
