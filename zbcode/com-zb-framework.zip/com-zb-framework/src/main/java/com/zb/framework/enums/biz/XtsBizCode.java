/**
 * 
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 
 * @author 
 * @version $Id: XtsBizCode.java, v 0.1 2015年6月3日 上午10:39:31  Exp $
 */
public class XtsBizCode extends BizCode implements Serializable {

    /**  */
    private static final long      serialVersionUID             = 2258862044493204286L;

    /**db幂等异常*/
    public static final XtsBizCode IDEMPOTENT_ERROR             = new XtsBizCode(
                                                                    "IDEMPOTENT_ERROR",
                                                                    ServiceCode.XTS, "001",
                                                                    "db幂等异常");

    /**找不到主事务*/
    public static final XtsBizCode NO_ACTIVITY                  = new XtsBizCode("NO_ACTIVITY",
                                                                    ServiceCode.XTS, "002",
                                                                    "找不到主事务");

    /**查询不到分支事务*/
    public static final XtsBizCode NO_ACTIONS                   = new XtsBizCode("NO_ACTIONS",
                                                                    ServiceCode.XTS, "003",
                                                                    "查询不到分支事务");

    /**分支事务二阶段失败*/
    public static final XtsBizCode ACTION_TWO_PHASE_ERROR       = new XtsBizCode(
                                                                    "ACTION_TWO_PHASE_ERROR",
                                                                    ServiceCode.XTS, "004",
                                                                    "分支事务二阶段失败");

    /**主事务状态异常*/
    public static final XtsBizCode ACTIVITY_STATE_ERROR         = new XtsBizCode(
                                                                    "ACTIVITY_STATE_ERROR",
                                                                    ServiceCode.XTS, "005",
                                                                    "主事务状态异常");

    /**主事务更新异常*/
    public static final XtsBizCode ACTIVITY_UPDATE_ERROR        = new XtsBizCode(
                                                                    "ACTIVITY_UPDATE_ERROR",
                                                                    ServiceCode.XTS, "006",
                                                                    "主事务更新异常");

    /**分布式事务只能在本地事务中开启*/
    public static final XtsBizCode NO_LOCAL_TRANSACTION         = new XtsBizCode(
                                                                    "NO_LOCAL_TRANSACTION",
                                                                    ServiceCode.XTS, "007",
                                                                    "分布式事务只能在本地事务中开启");

    /**主事务状态不是初始化，无法开启分支事务*/
    public static final XtsBizCode ACTIVITY_STATUS_NOT_INIT     = new XtsBizCode(
                                                                    "ACTIVITY_STATUS_NOT_INIT",
                                                                    ServiceCode.XTS, "008",
                                                                    "主事务状态不是初始化，无法开启分支事务");

    /**参数不能为空*/
    public static final XtsBizCode PARAM_BLANK_ERROR            = new XtsBizCode(
                                                                    "PARAM_BLANK_ERROR",
                                                                    ServiceCode.XTS, "009",
                                                                    "参数不能为空");

    /**事务模板配置为空*/
    public static final XtsBizCode TRANSACTION_TEMPLATE_BLANK   = new XtsBizCode(
                                                                    "TRANSACTION_TEMPLATE_BLANK",
                                                                    ServiceCode.XTS, "010",
                                                                    "事务模板配置为空");

    /**事务模板配置为空*/
    public static final XtsBizCode TRANSACTION_STATUS_NOT_ALLOW = new XtsBizCode(
                                                                    "TRANSACTION_STATUS_NOT_ALLOW",
                                                                    ServiceCode.XTS, "011",
                                                                    "事务状态不是commit/rollback");

    /**系统异常*/
    public static final XtsBizCode SYSTEM_ERROR                 = new XtsBizCode("SYSTEM_ERROR",
                                                                    ServiceCode.XTS, "999", "系统异常");

    /**系统异常*/
    public static final XtsBizCode UNKNOWN                      = new XtsBizCode("UNKNOWN",
                                                                    ServiceCode.XTS, "998", "未知");

    private XtsBizCode(String name, ServiceCode serviceCode, String code, String desc) {
        super(name, serviceCode, code, desc);
    }

    private XtsBizCode() {

    }

}
