package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 证件类型<br/>
 *
 * Created by  2015/1/19.
 */
public final class IdCardType extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = -6941167953534062244L;

    public static final IdCardType I = new IdCardType("I", "身份证");

    public static final IdCardType P = new IdCardType("P", "外国护照");

    public static final IdCardType M = new IdCardType("M", "军官证");

    public static final IdCardType S = new IdCardType("S", "港澳通行证或台胞证");

    public static final IdCardType C = new IdCardType("C", "中国护照");

    public static final IdCardType L = new IdCardType("L", "中国临时身份证");

    public static final IdCardType H = new IdCardType("H", "户口本编号");

    public static final IdCardType B = new IdCardType("B", "士兵证");

    public static final IdCardType J = new IdCardType("J", "警官证");

    public static final IdCardType R = new IdCardType("R", "外国公民永久居留证");

    public static final IdCardType O = new IdCardType("O", "其他");

    protected IdCardType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected IdCardType(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return IdCardType.class;
    }
}
