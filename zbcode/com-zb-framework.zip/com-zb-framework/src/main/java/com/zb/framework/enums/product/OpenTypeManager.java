package com.zb.framework.enums.product;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 业务控制类型枚举<br/>
 *
 */
public class OpenTypeManager extends AbstractCodedEnum implements Serializable {

    public static final OpenTypeManager openNormal = new OpenTypeManager("openNormal","0102", "每日开放");
    public static final OpenTypeManager openSomeDay = new OpenTypeManager("openSomeDay","0101", "定期开放");


    protected OpenTypeManager() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    public OpenTypeManager(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return OpenTypeManager.class;
    }
}
