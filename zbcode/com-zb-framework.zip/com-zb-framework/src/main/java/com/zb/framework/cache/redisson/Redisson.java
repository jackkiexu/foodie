/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson;

import com.zb.framework.cache.redisson.config.MasterSlaveConfig;
import com.zb.framework.cache.redisson.config.SentinelConfig;
import com.zb.framework.cache.redisson.container.MasterSlaveContainer;
import com.zb.framework.cache.redisson.container.RedisNode;
import com.zb.framework.cache.redisson.container.SentinelContainer;
import com.zb.framework.cache.redisson.container.SingleServerContainer;
import com.zb.framework.enums.BizCode;
import com.zb.framework.util.CoreCommonUtils;
import io.netty.util.concurrent.Future;
import org.apache.commons.collections.CollectionUtils;
import org.redisson.Config;
import org.redisson.RedissonClient;
import org.redisson.client.BaseRedisPubSubListener;
import org.redisson.client.RedisClient;
import org.redisson.client.RedisPubSubConnection;
import org.redisson.client.codec.Codec;
import org.redisson.client.codec.StringCodec;
import org.redisson.client.protocol.pubsub.PubSubType;
import org.redisson.core.ClusterNode;
import org.redisson.core.Node;
import org.redisson.core.NodesGroup;
import org.redisson.core.RAtomicLong;
import org.redisson.core.RBatch;
import org.redisson.core.RBlockingQueue;
import org.redisson.core.RBucket;
import org.redisson.core.RCountDownLatch;
import org.redisson.core.RDeque;
import org.redisson.core.RHyperLogLog;
import org.redisson.core.RKeys;
import org.redisson.core.RLexSortedSet;
import org.redisson.core.RList;
import org.redisson.core.RLock;
import org.redisson.core.RMap;
import org.redisson.core.RPatternTopic;
import org.redisson.core.RQueue;
import org.redisson.core.RScoredSortedSet;
import org.redisson.core.RScript;
import org.redisson.core.RSet;
import org.redisson.core.RSortedSet;
import org.redisson.core.RTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Created by  2015/5/6.
 */
public class Redisson implements RedissonClient {
    private static final Logger LOG = LoggerFactory.getLogger(Redisson.class);

    private static final Object LOCK = new Object();

    private static enum ConfigType {MasterSlave, Sentinel}

    private RedissonContainer container = null;

    private ConfigType configType = null;

    private List<MasterSlaveConfig> configs4MS = null;

    private List<SentinelConfig> configs4S = null;

    private ReadWriteLock wr = new ReentrantReadWriteLock();
    private Lock w = wr.writeLock();
    private Lock r = wr.readLock();

    public Redisson() {
        ;
    }

    public void setMasterSlave(MasterSlaveConfig config) {
        notNull(config);

        setMasterSlaves(Arrays.asList(config));
    }

    public void setSentinel(SentinelConfig config) {
        notNull(config);

        setSentinels(Arrays.asList(config));
    }

    public void setMasterSlaves(List<MasterSlaveConfig> configs) {
        notEmpty(configs);

        create4MS(configs);
    }

    public void setSentinels(List<SentinelConfig> configs) {
        notEmpty(configs);

        create4S(configs);
    }

    private void create4MS(List<MasterSlaveConfig> configs) {
        if(container != null) {
            return;
        }

        configs4MS = configs;
        configType = ConfigType.MasterSlave;
        synchronized (LOCK) {
            if(container != null) {
                return;
            }

            try {
                if (configs.size() == 1) {
                    container = create(configs.get(0));
                } else {
                    container = new MasterSlaveContainer(configs);
                }
            } catch (IllegalArgumentException ex) {
                throw ex;
            } catch (Exception ex) {
                // 稍后重试；
                LOG.warn("创建redis异常，稍后重试.", ex);
            }
        }
    }

    private RedissonContainer create(MasterSlaveConfig config) {
        if(CollectionUtils.isEmpty(config.getSlaveAddressList())) {
            return new SingleServerContainer(config);
        }

        return new MasterSlaveContainer(Arrays.asList(config));
    }

    private void create4S(List<SentinelConfig> configs) {
        if(container != null) {
            return;
        }

        configs4S = configs;
        configType = ConfigType.Sentinel;
        synchronized (LOCK) {
            if(container != null) {
                return;
            }

            try {
                container = new SentinelContainer(configs);

                listenerSentinel((SentinelContainer)container);
            } catch (IllegalArgumentException ex) {
                throw ex;
            } catch (Exception ex) {
                // 稍后重试；
                LOG.warn("创建redis异常，稍后重试.", ex);
            }
        }
    }

    private void listenerSentinel(SentinelContainer container) throws Exception {
        final List<RedisNode> nodes = container.getContainer().getAllNodes();
        if(CollectionUtils.isEmpty(nodes)) {
            return;
        }

        for(RedisNode node : nodes) {
            final org.redisson.Redisson $client = node.getClient();
            final NodesGroup<Node> group = $client.getNodesGroup();

            final Field cmField = group.getClass().getDeclaredField("connectionManager");
            cmField.setAccessible(true);
            final Object cm = cmField.get(group);  // connection manager;
            final Field sentinelsFiled = cm.getClass().getDeclaredField("sentinels");
            sentinelsFiled.setAccessible(true);
            final Map<String, RedisClient> sentinels
                    = (Map<String, RedisClient>)sentinelsFiled.get(cm);

            for(RedisClient client : sentinels.values()) {
                final RedisPubSubConnection pubSub = client.connectPubSub();
                pubSub.addListener(new BaseRedisPubSubListener<String>() {

                    @Override
                    public void onMessage(String channel, String msg) {
                        if ("+switch-master".equals(channel)) {
                            shutdown();
                        }
                    }

                    @Override
                    public boolean onStatus(PubSubType type, String channel) {
                        return true;
                    }
                });

                pubSub.subscribe(StringCodec.INSTANCE, "+switch-master", "+sdown", "-sdown", "+slave", "+sentinel");
            }
        }
    }

    private void notNull(Object config) {
        if(config == null) {
            throw new IllegalArgumentException("redisson配置信息不能为null");
        }
    }

    private void notEmpty(List<?> configs) {
        if(configs == null || configs.isEmpty()) {
            throw new IllegalArgumentException("redisson配置列表信息不能为空");
        }
    }

    private void initClient() {
        if(configType == null) {
            throw new IllegalArgumentException("没有设置redis服务器配置信息");
        }

        if(configType == ConfigType.Sentinel) {
            create4S(configs4S);
        } else if(configType == ConfigType.MasterSlave) {
            create4MS(configs4MS);
        }

        if(container == null) {
            throw new IllegalStateException("redis未初始化");
        }
    }

    @Override
    public <V> RBucket<V> getBucket(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getBucket(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RBucket<V> getBucket(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getBucket(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> List<RBucket<V>> getBuckets(String pattern) {
        r.lock();
        try {
            initClient();
            return container.get(pattern).getBuckets(pattern);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RHyperLogLog<V> getHyperLogLog(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getHyperLogLog(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RHyperLogLog<V> getHyperLogLog(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getHyperLogLog(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RList<V> getList(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getList(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RList<V> getList(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getList(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <K, V> RMap<K, V> getMap(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getMap(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <K, V> RMap<K, V> getMap(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getMap(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public RLock getLock(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getLock(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RSet<V> getSet(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getSet(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RSet<V> getSet(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getSet(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RSortedSet<V> getSortedSet(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getSortedSet(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RSortedSet<V> getSortedSet(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getSortedSet(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RScoredSortedSet<V> getScoredSortedSet(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getScoredSortedSet(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RScoredSortedSet<V> getScoredSortedSet(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getScoredSortedSet(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public RLexSortedSet getLexSortedSet(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getLexSortedSet(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <M> RTopic<M> getTopic(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getTopic(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <M> RTopic<M> getTopic(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getTopic(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <M> RPatternTopic<M> getPatternTopic(String pattern) {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public <M> RPatternTopic<M> getPatternTopic(String pattern, Codec codec) {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public <V> RQueue<V> getQueue(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getQueue(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RQueue<V> getQueue(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getQueue(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RBlockingQueue<V> getBlockingQueue(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getBlockingQueue(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RBlockingQueue<V> getBlockingQueue(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getBlockingQueue(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RDeque<V> getDeque(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getDeque(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public <V> RDeque<V> getDeque(String name, Codec codec) {
        r.lock();
        try {
            initClient();
            return container.get(name).getDeque(name, codec);
        } finally {
            r.unlock();
        }
    }

    @Override
    public RAtomicLong getAtomicLong(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getAtomicLong(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public RCountDownLatch getCountDownLatch(String name) {
        r.lock();
        try {
            initClient();
            return container.get(name).getCountDownLatch(name);
        } finally {
            r.unlock();
        }
    }

    @Override
    public RScript getScript() {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public RBatch createBatch() {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public RKeys getKeys() {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    public void shutdown() {
        if(container != null) {
            w.lock();
            try {
                container = null;

                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        container.shutdown();
                    }
                });
            } finally {
                w.unlock();
            }
        }
    }

    @Override
    public Config getConfig() {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public Collection<String> findKeysByPattern(String pattern) {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public Future<Collection<String>> findKeysByPatternAsync(String pattern) {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public long deleteByPattern(String pattern) {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return -1;
    }

    @Override
    public Future<Long> deleteByPatternAsync(String pattern) {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public long delete(String... keys) {
        r.lock();
        try {
            initClient();

            int i = 0;
            for(String key : keys) {
                i += container.get(key).delete(key);
            }
            return 0;
        } finally {
            r.unlock();
        }
    }

    @Override
    public Future<Long> deleteAsync(String... keys) {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public NodesGroup<Node> getNodesGroup() {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public NodesGroup<ClusterNode> getClusterNodesGroup() {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");

        return null;
    }

    @Override
    public void flushdb() {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");
    }

    @Override
    public void flushall() {
        CoreCommonUtils.raiseBizException(
                BizCode.UnsupportedOperation, "不支持没key的操作");
    }
}
