/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * TA编码<br/>
 *
 * Created by  2015/3/23.
 */
public class TaCode extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = 6050596137540022465L;

    public static final TaCode LcRT = new TaCode("RT", "中欧实时TA"); // R -- runtime

    public static final TaCode LcST = new TaCode("60", "中欧自TA");   // S -- self

    public static final TaCode CRT = new TaCode("CRT", "中登TA");   // C R -- CHINA REGISTER

    public static final TaCode ST = new TaCode("ST", "专户TA");   // S -- Special

    protected TaCode(String name, String desc) {
        super(name, desc);
    }

    protected TaCode() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return TaCode.class;
    }
}
