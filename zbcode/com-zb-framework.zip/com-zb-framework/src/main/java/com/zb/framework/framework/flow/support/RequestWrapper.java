/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.framework.flow.support;

import com.zb.framework.base.AbstractRequest;

/**
 * Created by  2015/4/23.
 */
public final class RequestWrapper extends AbstractRequest {
    /**
     * 任意请求参数<br/>
     *
     */
    private Object request = null;

    private RequestWrapper(Object request) {
        this.request = request;
    }

    /**
     * 构造包装对象<br/>
     *
     * @param request
     * @return
     */
    public static RequestWrapper wrap(Object request) {
        return new RequestWrapper(request);
    }

    /**
     * 获取包装对象的实际参数值<br/>
     *
     * @param request
     * @return
     */
    public static Object unwrap(RequestWrapper request) {
        return request.request;
    }
}
