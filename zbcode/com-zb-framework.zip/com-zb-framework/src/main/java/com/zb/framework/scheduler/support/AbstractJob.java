///**
// * 
// *
// * Copyright (c) 2014-2015 All Rights Reserved.
// */
//package com.zb.framework.scheduler.support;
//
//import com.zb.framework.scheduler.Job;
//import com.taobao.pamirs.schedule.IScheduleTaskDealSingle;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
///**
// * Created by  2015/4/21.
// */
//public abstract class AbstractJob<T> extends AbstractJobBase<T> implements Job<T>, IScheduleTaskDealSingle<T> {
//    private static final Logger LOG = LoggerFactory.getLogger(AbstractJob.class);
//
//    @Override
//    public final boolean execute(T task, String ownSign) throws Exception {
//        return process(task, getContext());
//    }
//}
