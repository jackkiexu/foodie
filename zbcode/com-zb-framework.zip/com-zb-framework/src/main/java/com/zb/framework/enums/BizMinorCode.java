package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 次业务编码类型<br/>
 *
 * Created by  2014/12/10.
 */
public final class BizMinorCode extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = 7362528093494500841L;

    public static final BizMinorCode General = new BizMinorCode("General", "00", "通用");

    public static final BizMinorCode Number = new BizMinorCode("Number", "01", "数字相关");

    public static final BizMinorCode String = new BizMinorCode("String", "02", "字符串相关");

    /**
     * 主要用于描述业务数据，例如数据库、调用外部服务查询数据未返回等<br/>
     *
     */
    public static final BizMinorCode Data = new BizMinorCode("Data", "03", "数据相关");

    /**
     * 主要用于描述对外部的连接操作，例如JDBC、Socket等<br/>
     *
     */
    public static final BizMinorCode Connection = new BizMinorCode("Connection", "04", "连接相关");

    /**
     * 主要与JDK相关的一下信息，例如class加载失败，反射错误等等<br/>
     *
     */
    public static final BizMinorCode Platform = new BizMinorCode("Platform", "05", "连接相关");

    public static final BizMinorCode Unknown = new BizMinorCode("Unknown", "99", "未知");

    protected BizMinorCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    private BizMinorCode(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return BizMinorCode.class;
    }
}
