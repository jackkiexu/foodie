package com.zb.framework.framework.flow.util;

import com.zb.framework.framework.flow.vo.AbstractFlowVo;

/**
 * 类型参数辅助函数<br/>
 *
 * Created by  2014/12/12.
 */
public abstract class VoUtils {
    private VoUtils() {
        ; // nothing.
    }

    /**
     * 将给定的Vo类型转换为指定的类型，如果不能进行转换则返回null<br/>
     *
     * @param clazz
     * @param vo
     * @param <T>
     * @return
     */
    public static <T extends AbstractFlowVo> T as(Class<T> clazz, AbstractFlowVo vo) {
        if(clazz == null || vo == null) {
            return null;
        }

        if(clazz.isAssignableFrom(vo.getClass())) {
            return (T) vo;
        }

        return null;
    }
}
