package com.zb.framework.framework.flow.context;

import com.zb.framework.enums.BizCode;
import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.enums.FlowAttribute;
import com.zb.framework.framework.flow.enums.PhaseCode;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;
import com.zb.framework.framework.flow.vo.ResponseAttributes;
import com.zb.framework.util.CoreCommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * pipe line上下文基类<br/>
 *
 * Created by  2014/12/12.
 */
public abstract class AbstractContext implements Context {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractContext.class);

    /**
     * Pipe line的入口参数<br/>
     *
     */
    private AbstractFlowVo callerParam = null;

    /**
     * pipe line运行的起始阶段编码<br/>
     *
     */
    private PhaseCode starting = null;

    /**
     * 节点是否在starting phase节点后面<br/>
     *
     */
    private boolean behindStartingPhase = false;

    /**
     * 响应属性集合<br/>
     *
     */
    private ResponseAttributes responseAttributes = new ResponseAttributes();

    /**
     * 附加对象集合<br/>
     *
     */
    private Map<String, Object> attachObjects = new HashMap<>(4, 1F);

    @Override
    public boolean isAsyncEnvironment() {
        String isAsync = getCallerParam().getExtField(FlowAttribute.IS_ASYNC.name());
        try {
            return isAsync == null || isAsync.isEmpty()
                    ? false : Boolean.valueOf(isAsync);
        } catch (Exception e) {
            CoreCommonUtils.raiseBizException(
                    BizCode.ParamError, "异步执行环境值必须为： true或者false", e);

            // 无法执行的代码；
            return false;
        }
    }

    @Override
    public AbstractFlowVo getCallerParam() {
        if(callerParam == null) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull
                    , "pipe line入口参数不能为null");
        }

        return callerParam;
    }

    /**
     * 设置Pipe line的入口参数<br/>
     *
     * @param callerParam
     */
    public void setCallerParam(AbstractFlowVo callerParam) {
        if(callerParam == null) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull
                    , "pipe line入口参数不能设置为null");
        }

        this.callerParam = callerParam;
    }

    public PhaseCode getStarting() {
        return starting;
    }

    /**
     * 设置pipe line的起始阶段编码<br/>
     *
     * @return
     */
    public void setStarting(PhaseCode starting) {
        this.starting = starting;
    }

    @Override
    public ResponseAttributes getResponseAttributes() {
        return responseAttributes;
    }

    public void setResponseAttributes(ResponseAttributes responseAttributes) {
        this.responseAttributes = responseAttributes;
    }

    public boolean isBehindStartingPhase() {
        return behindStartingPhase;
    }

    public void setBehindStartingPhase(boolean behindStartingPhase) {
        this.behindStartingPhase = behindStartingPhase;
    }

    @Override
    public Object getAttachObject(String key) {
        return attachObjects.get(key);
    }

    public void addAttachObject(String key, Object  obj) {
        attachObjects.put(key, obj);
    }
}
