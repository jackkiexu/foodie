package com.zb.framework.framework.flow.util;

import com.zb.framework.framework.flow.Handler;

/**
 * Created by  2014/12/12.
 */
public class FlowHandlerContainer extends AbstractFlowContainer<Handler> implements FlowContainer<Handler> {
    public FlowHandlerContainer(int capacity) {
        super(capacity);
    }
}
