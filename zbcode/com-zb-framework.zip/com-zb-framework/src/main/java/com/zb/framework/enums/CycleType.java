/**
 * 
 * <p/>
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 周期类型<br/>
 *
 * Created by  2015/12/8.
 */
public final class CycleType extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = 3247138503552978371L;

    public static final CycleType Week = new CycleType("W", "按周");

    public static final CycleType Month = new CycleType("M", "按月");

    public static final CycleType Year = new CycleType("Y", "按年");

    protected CycleType() {
        super();
    }

    protected CycleType(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return CycleType.class;
    }
}
