/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.concurrent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

/**
 * Created by  2015/5/8.
 */
public class ThreadPoolExecutor extends java.util.concurrent.ThreadPoolExecutor {
    private static final Logger LOG = LoggerFactory.getLogger(ThreadPoolExecutor.class);

    private final static Set<CopyKey> cache = new HashSet<>(32, 1F);

    public ThreadPoolExecutor(int corePoolSize, int maximumPoolSize
            , long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
    }

    public ThreadPoolExecutor(int corePoolSize, int maximumPoolSize
            , long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory);
    }

    public ThreadPoolExecutor(int corePoolSize, int maximumPoolSize
            , long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue, RejectedExecutionHandler handler) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, handler);
    }

    public ThreadPoolExecutor(int corePoolSize, int maximumPoolSize
            , long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory, RejectedExecutionHandler handler) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory, handler);
    }

    @Override
    protected <T> RunnableFuture<T> newTaskFor(Runnable runnable, T value) {
        return new WrapperFutureTask(runnable, value);
    }

    @Override
    protected <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
        return new WrapperFutureTask(callable);
    }

    @Override
    public void execute(Runnable command) {
        super.execute(new WrapperRunnable(command));
    }

    @Override
    protected void beforeExecute(Thread t, Runnable r) {
        super.beforeExecute(t, r);

        // copy TLS；
        copyTLS(r);
    }

    private void copyTLS(Runnable r) {
        if(threadLocals == null || !(r instanceof OuterThread)) {
            return;
        }

        try {
            final Thread outerThread = ((OuterThread) r).getOuterThread();
            final Object outerTLS = threadLocals.get(outerThread);
            if(outerTLS == null) {
                return;
            }

            final Object thisTLS = threadLocals.get(Thread.currentThread());
            if(thisTLS == null) {
                return;
            }

            final Map<ThreadLocal, Object> thisAllTls = getAllTLS(Thread.currentThread());
            final Map<ThreadLocal, Object> outerAllTls = ((OuterThread) r).getTls();
            for(Map.Entry<ThreadLocal, Object> entry : outerAllTls.entrySet()) {
                final ThreadLocal key = entry.getKey();
                set.invoke(thisTLS, key, entry.getValue());
                cache.add(new CopyKey(Thread.currentThread(), outerThread, key));
            }
        } catch (Exception e) {
            LOG.warn("copy TLS异常", e);
        }
    }

    public static Map<ThreadLocal, Object> getAllTLS(Thread thread) {
        try {
            if(thread == null) {
                return Collections.emptyMap();
            }

            final Object $tls = threadLocals.get(thread);
            if($tls == null) {
                return Collections.emptyMap();
            }

            Object[] entries = (Object[]) table.get($tls);
            if(entries == null) {
                return Collections.emptyMap();
            }

            final Map<ThreadLocal, Object> mapping = new HashMap<>(entries.length, 1F);
            for(Object entry : entries) {
                if (!(entry instanceof WeakReference)) {
                    continue;
                }

                WeakReference<ThreadLocal> tls = (WeakReference<ThreadLocal>)entry;
                if(tls.get() instanceof InheritableThreadLocal) {
                    mapping.put(tls.get(), value.get(entry));
                }
            }

            return mapping;
        } catch (Exception e) {
            LOG.warn("get TLS异常", e);

            return Collections.emptyMap();
        }
    }

    @Override
    protected void afterExecute(Runnable r, Throwable t) {
        super.afterExecute(r, t);

        // clear TLS；
        clearTLS(r);
    }

    private void clearTLS(Runnable r) {
        if(threadLocals == null || !(r instanceof OuterThread)) {
            return;
        }

        try {
            final Thread outerThread = ((OuterThread) r).getOuterThread();

            final Object thisTLS = threadLocals.get(Thread.currentThread());
            if(thisTLS == null) {
                return;
            }

            Object[] entries = (Object[]) table.get(thisTLS);
            if(entries == null) {
                return;
            }

            for(Object entry : entries) {
                if (!(entry instanceof WeakReference)) {
                    continue;
                }
                WeakReference<ThreadLocal> tls = (WeakReference<ThreadLocal>) entry;

                if (tls != null && tls.get() != null
                        && cache.contains(new CopyKey(Thread.currentThread(), outerThread, tls.get()))) {
                    remove.invoke(thisTLS, tls.get());
                    cache.remove(new CopyKey(Thread.currentThread(), outerThread, tls.get()));
                }
            }
        } catch (Exception e) {
            LOG.warn("clear TLS异常", e);
        }
    }

    // ---------------------------------------------------- static initialize;
    static Field threadLocals = null;
    static Field table = null;
    static Method set = null;
    static Method remove = null;
    static Field value = null;
    static {
        try {
            final Class<Thread> tclass = Thread.class;
            threadLocals = tclass.getDeclaredField("inheritableThreadLocals");
            threadLocals.setAccessible(true);

            final ClassLoader systemClassLoader = ClassLoader.getSystemClassLoader();
            final Class<?> tlmClass = threadLocals.getType();
            table = tlmClass.getDeclaredField("table");
            table.setAccessible(true);

            set = tlmClass.getDeclaredMethod("set", ThreadLocal.class, Object.class);
            set.setAccessible(true);

            remove = tlmClass.getDeclaredMethod("remove", ThreadLocal.class);
            remove.setAccessible(true);

            final Class<?> entryClass = systemClassLoader.loadClass("java.lang.ThreadLocal$ThreadLocalMap$Entry");
            value = entryClass.getDeclaredField("value");
            value.setAccessible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static interface OuterThread {
        Thread getOuterThread();

        Map<ThreadLocal, Object> getTls();
    }

    private static class WrapperFutureTask extends FutureTask implements OuterThread {
        private Thread outerThread = Thread.currentThread();

        private Map<ThreadLocal, Object> tls = getAllTLS(Thread.currentThread());

        public WrapperFutureTask(Callable callable) {
            super(callable);
        }

        public WrapperFutureTask(Runnable runnable, Object result) {
            super(runnable, result);
        }

        public Thread getOuterThread() {
            return outerThread;
        }

        public void setOuterThread(Thread outerThread) {
            this.outerThread = outerThread;
        }

        public Map<ThreadLocal, Object> getTls() {
            return tls;
        }

        public void setTls(Map<ThreadLocal, Object> tls) {
            this.tls = tls;
        }
    }

    private static class WrapperRunnable implements Runnable, OuterThread {
        private Thread outerThread = Thread.currentThread();

        private Runnable runnable = null;

        private Map<ThreadLocal, Object> tls = getAllTLS(Thread.currentThread());

        public WrapperRunnable(Runnable runnable) {
            this.runnable = runnable;
        }

        @Override
        public void run() {
            runnable.run();
        }

        public Thread getOuterThread() {
            return outerThread;
        }

        public void setOuterThread(Thread outerThread) {
            this.outerThread = outerThread;
        }

        @Override
        public Map<ThreadLocal, Object> getTls() {
            return tls;
        }

        public void setTls(Map<ThreadLocal, Object> tls) {
            this.tls = tls;
        }
    }

    private static class CopyKey {
        public Thread thread = null;

        public Thread thisThread = null;

        public Object tls = null;

        public CopyKey(Thread thisThread, Thread thread, Object tls) {
            this.thisThread = thisThread;
            this.thread = thread;
            this.tls = tls;
        }

        @Override
        public int hashCode() {
            return thread.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if(!(obj instanceof CopyKey)) {
                return false;
            }

            CopyKey o = (CopyKey) obj;

            return thread == o.thread && tls == o.tls && thisThread == o.thisThread;
        }
    }
}
