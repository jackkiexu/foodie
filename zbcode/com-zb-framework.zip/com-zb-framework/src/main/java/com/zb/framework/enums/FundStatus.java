package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 基金状态<br/>
 *
 */
public final class FundStatus extends AbstractCodedEnum implements Serializable {
    public static final FundStatus fundPublish = new FundStatus("PUBLISH", "0", "基金发行");

    public static final FundStatus fundSuspend = new FundStatus("SUSPEND", "1", "暂停交易");

    public static final FundStatus fundNormal = new FundStatus("NORMAL", "2", "正常开放");

    public static final FundStatus fundClose = new FundStatus("CLOSE", "3", "基金关闭");


    protected FundStatus() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected FundStatus(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return FundStatus.class;
    }
}
