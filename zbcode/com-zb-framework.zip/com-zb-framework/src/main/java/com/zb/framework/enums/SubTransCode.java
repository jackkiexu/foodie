package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;
import com.zb.framework.util.CoreCommonUtils;

import java.io.Serializable;

/**
 * 自交易码<br/>
 *
 * Created by  2014/12/27.
 */
public final class SubTransCode extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = -3321380835708662453L;

    // ------------------- 申购（purchase）
    public static final SubTransCode GENERAL_PUR
            = new SubTransCode("GENERAL_PUR", "0101", "普通申购", TransCode.PURCHASE);

    public static final SubTransCode PUR_FROZEN
            = new SubTransCode("PUR_FROZEN", "0102", "申购并冻结", TransCode.PURCHASE);

    public static final SubTransCode RES_PUR
            = new SubTransCode("RES_PUR", "0103", "预约申购", TransCode.PURCHASE);

    public static final SubTransCode PUR_BONUS
            = new SubTransCode("PUR_BONUS", "0110", "红包申购", TransCode.PURCHASE);

    public static final SubTransCode BANKING_REFUND_PUR
            = new SubTransCode("BANKING_REFUND_PUR", "0104", "银行卡支付退款申购", TransCode.PURCHASE);  // 货币支付中心专用

    public static final SubTransCode CURR_REFUND_PUR
            = new SubTransCode("CURR_REFUND_PUR", "0105", "货币支付退款申购", TransCode.PURCHASE);       // 货币支付中心专用

    public static final SubTransCode LIQUIDATE_PUR
            = new SubTransCode("LIQUIDATE_PUR", "0106", "清盘申购", TransCode.PURCHASE);                // 货币支付中心专用

    public static final SubTransCode FORCE_PUR
            = new SubTransCode("FORCE_PUR", "0107", "强赎申购", TransCode.PURCHASE);                    // 货币支付中心专用

    public static final SubTransCode MOLEN_PUR
            = new SubTransCode("MOLEN_PUR", "0108", "分红申购", TransCode.PURCHASE);                    // 货币支付中心专用

    public static final SubTransCode Curr_Red_PUR
            = new SubTransCode("Curr_Red_PUR", "0109", "赎回至货币基金申购", TransCode.PURCHASE);        // 货币支付中心专用

    // ------------------- 认购（subscribe）
    @Deprecated
    public static final SubTransCode GENERAL_SUB
            = new SubTransCode("GENERAL_SUB", "0201", "普通认购", TransCode.SUBSCRIBE);

    public static final SubTransCode RES_SUB // reservation
            = new SubTransCode("RES_SUB", "0202", "预约认购", TransCode.SUBSCRIBE);

    // ------------------- 赎回（redeem）
    public static final SubTransCode BANKING_REDEEM
            = new SubTransCode("BANKING_REDEEM", "0301", "赎回至银行卡", TransCode.REDEEM);

    public static final SubTransCode CurrencyFund_REDEEM
            = new SubTransCode("CurrencyFund_REDEEM", "0302", "赎回至货币基金", TransCode.REDEEM);

    public static final SubTransCode Cash_REDEEM
            = new SubTransCode("Cash_REDEEM", "0305", "赎回至余额", TransCode.REDEEM); // 货币支付中心专用

    public static final SubTransCode Fast_Banking_REDEEM
            = new SubTransCode("Fast_Banking_REDEEM", "0303", "快速赎回至银行卡", TransCode.REDEEM);

    public static final SubTransCode UNFROZEN_REDEEM
            = new SubTransCode("UNFROZEN_REDEEM", "0304", "解冻并赎回至余额", TransCode.REDEEM);

    // ------------------- 撤单（cancel）
    public static final SubTransCode GENERAL_CANCEL
            = new SubTransCode("GENERAL_CANCEL", "0801", "普通撤单", TransCode.CANCEL);

    public static final SubTransCode Curr_CANCEL
            = new SubTransCode("Curr_CANCEL", "0803", "货币基金撤单", TransCode.CANCEL);

    public static final SubTransCode REVERSE
            = new SubTransCode("REVERSE", "0802", "冲正", TransCode.CANCEL);

    // ------------------- 分红（melon）
    public static final SubTransCode SET_MELON
            = new SubTransCode("SET_MELON", "0901", "修改分红方式", TransCode.MELON);

    public static final SubTransCode REINVESTMENT_MELON
            = new SubTransCode("REINVESTMENT_MELON", "0902", "分红再投", TransCode.MELON);

    public static final SubTransCode CASH_MELON
            = new SubTransCode("CASH_MELON", "0903", "现金分红", TransCode.MELON);

    // ------------------- 自动后台交易（auto）
    public static final SubTransCode LIQUIDATE
            = new SubTransCode("LIQUIDATE", "1001", "清盘", TransCode.AUTO);

    public static final SubTransCode FORCE_ADD
            = new SubTransCode("FORCE_ADD", "1002", "强增", TransCode.AUTO);

    public static final SubTransCode FORCE_REDUCE
            = new SubTransCode("FORCE_REDUCE", "1003", "强减", TransCode.AUTO);

    public static final SubTransCode FORCE_REDEEM
            = new SubTransCode("FORCE_REDEEM", "1004", "强赎", TransCode.AUTO);

    public static final SubTransCode AUTO_EXCHANGE_IN
            = new SubTransCode("AUTO_EXCHANGE_IN", "1005", "非交易过户转入（他人）", TransCode.AUTO);

    public static final SubTransCode AUTO_CONVERT_IN
            = new SubTransCode("AUTO_CONVERT_IN", "1006", "转托管转入（本人）", TransCode.AUTO);

    // ------------------- 控制类交易（manipulate）
    public static final SubTransCode FROZEN
            = new SubTransCode("FROZEN", "1101", "冻结", TransCode.MANIPULATE);

    public static final SubTransCode UNFROZEN
            = new SubTransCode("UNFROZEN", "1102", "解冻", TransCode.MANIPULATE);

    // ------------------- 转换（convert）
    public static final SubTransCode GENERAL_CONVERT
            = new SubTransCode("GENERAL_CONVERT", "0601", "普通转换", TransCode.CONVERT);

    // ------------------- 支付（pay）
    public static final SubTransCode Refund
            = new SubTransCode("Refund", "0501", "多单", TransCode.PAY);

    public static final SubTransCode Merchant_Refund
            = new SubTransCode("Merchant_Refund", "0502", "商户发起退款", TransCode.PAY);

    public static final SubTransCode Sub_Refund
            = new SubTransCode("Sub_Refund", "0503", "认购超时", TransCode.PAY);

    public static final SubTransCode Cancel_Refund
            = new SubTransCode("Cancel_Refund", "0504", "撤单退款", TransCode.PAY);

    public static final SubTransCode Expired_Refund
            = new SubTransCode("Expired_Refund", "0505", "申购过期", TransCode.PAY);

    // ------------------- 定投（automatic investment plan）
    public static final SubTransCode GENERAL_AIP
            = new SubTransCode("GENERAL_AIP", "1201", "普通定投", TransCode.AIP);


    /**
     * 交易码，自交易码所属大类<br/>
     *
     */
    private TransCode parent = null;

    protected SubTransCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    public SubTransCode(String name, String code, String desc, TransCode parent) {
        super(name, code, desc);

        if(parent == null) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "交易所属大类不能为null");
        }

        this.parent = parent;
    }

    /**
     * 获取自交易码所属大类<br/>
     *
     * @return
     */
    public TransCode parent() {
        return this.parent;
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return SubTransCode.class;
    }
}
