/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.kernel;

import com.zb.framework.enums.BizCode;
import com.zb.framework.zk.event.EventObject;
import com.zb.framework.zk.event.NodeChangeEvent;
import com.zb.framework.zk.event.SessionEvent;
import com.zb.framework.zk.event.SessionListener;
import com.zb.framework.zk.util.ZooKeeperException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.ACL;
import org.apache.zookeeper.data.Id;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/**
 * zoo keeper初始化管理器<br/>
 *
 * Created by  2015/4/28.
 */
public final class ZooKeeperInitializer implements Watcher {
    private static final Logger LOG = LoggerFactory.getLogger(ZooKeeperInitializer.class);

    /**
     * 事件管理器<br/>
     *
     */
    EventMulticaster multicaster = null;

    /**
     * zk实例<br/>
     *
     */
    ZooKeeper zk = null;

    SafeZooKeeper szk = null;

    ZkConfig config = null;

    List<ACL> acl = new ArrayList<ACL>();

    private ZooKeeperInitializer(ZkConfig config) {
        multicaster = new EventMulticaster(this);

        this.config = config;
    }

    /**
     * 初始化zk<br/>
     *
     * @param config
     * @return
     */
    public static com.zb.framework.zk.SafeZooKeeper initialize(ZkConfig config) throws ZooKeeperException {
        return initialize(config, null);
    }

    /**
     * 初始化zk<br/>
     *
     * @param config
     * @param listener
     * @return
     */
    public static com.zb.framework.zk.SafeZooKeeper initialize(ZkConfig config, SessionListener listener) throws ZooKeeperException {
        final ZooKeeperInitializer initializer = new ZooKeeperInitializer(config);

        SafeZooKeeper zooKeeper = new SafeZooKeeper(initializer);
        initializer.multicaster.addSessionListener(zooKeeper);
        if(listener != null) {
            initializer.multicaster.addSessionListener(listener);
        }

        // 进行初始化；
        initializer.szk = zooKeeper;
        initializer.connect(config);

        return zooKeeper;
    }

    void connect(ZkConfig config) throws ZooKeeperException {
        LOG.info("初始化zk： " + config);

        try {
            zk = new ZooKeeper(config.getConnection(), config.getSessionTimeout(), this);

            String authString = (config.getUserName() == null ? "" : config.getUserName())
                    + ":"+ (config.getPassword() == null ? "" : config.getPassword());
            zk.addAuthInfo("digest", authString.getBytes());

            acl.add(new ACL(ZooDefs.Perms.ALL, new Id("digest",
                    generateDigest(authString))));

            acl.add(new ACL(ZooDefs.Perms.READ, ZooDefs.Ids.ANYONE_ID_UNSAFE));

            LOG.info("初始化zk成功.");
        } catch (IOException e) {
            throw new ZooKeeperException(BizCode.IO_Error, e);
        } catch (NoSuchAlgorithmException e) {
            throw new ZooKeeperException(BizCode.UnsupportedOperation, e);
        }
    }

    void reConnect() throws ZooKeeperException {
        if (zk != null) {
            try {
                zk.close();
            } catch (InterruptedException e) {
                throw new ZooKeeperException(BizCode.IO_Error, e);
            } finally {
                zk = null;
            }
        }

        connect(config);
    }

    @Override
    public void process(WatchedEvent event) {
        if(LOG.isDebugEnabled()) {
            LOG.info("接收到zk事件： " + event);
        }

        EventObject $event = null;
        if(StringUtils.isEmpty(event.getPath())
                && (event.getState() == Event.KeeperState.SyncConnected)) {
            $event = new SessionEvent();
            $event.setState(event.getState());
            $event.setZooKeeper(szk);

            // 因为在zk session timeout比较小的情况下；
            // 可能还没有来得及接收connect事件，已经发起新的connect了；
            szk.writeLockHandler.unlock();
        } else if(StringUtils.isEmpty(event.getPath())
                && (event.getState() == Event.KeeperState.Disconnected)) {
            $event = new SessionEvent();
            $event.setState(event.getState());
            $event.setZooKeeper(szk);

            szk.writeLockHandler.lock(); // 在重新connected后会解锁；
        } else if(StringUtils.isEmpty(event.getPath())
                && event.getState() == Event.KeeperState.Expired) {
            $event = new SessionEvent();
            $event.setState(Event.KeeperState.Expired);
            $event.setZooKeeper(szk);

            // 重新连接；
            try {
                szk.writeLockHandler.lock();
                reConnect();
            } catch (ZooKeeperException e) {
                LOG.warn("连接zk异常", e);
            }
        }
        // 发布session事件；
        multicaster.publish($event);

        // 处理节点变动状态；
        $event = null;
        if(event.getType() == Event.EventType.NodeChildrenChanged
                || event.getType() == Event.EventType.NodeDeleted
                || event.getType() == Event.EventType.NodeDataChanged
                || event.getType() == Event.EventType.NodeCreated) {
            $event = new NodeChangeEvent();
            $event.setZooKeeper(szk);
            $event.setState(event.getState());
            ((NodeChangeEvent)$event).setPath(event.getPath());
            ((NodeChangeEvent)$event).setType(event.getType());
        }
        // 发布节点变化事件；
        multicaster.publish($event);
    }

    static public String generateDigest(String idPassword) throws NoSuchAlgorithmException {
        String parts[] = idPassword.split(":", 2);
        final byte[] bytes = DigestUtils.sha1(idPassword.getBytes());
        return parts[0] + ":" + Base64.encodeBase64String(bytes);
    }
}
