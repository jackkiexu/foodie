package com.zb.framework.framework.flow.listener;

import com.zb.framework.framework.flow.Listener;
import com.zb.framework.framework.flow.OutboundProperty;

/**
 * Handler开始处理前监听器<br/>
 *
 * Created by  2014/6/16.
 */
public interface PreListener extends Listener {
    /**
     * 执行之前需要处理的逻辑<br/>
     *
     * @param outboundProperty
     */
    void onGoing(OutboundProperty outboundProperty);
}
