package com.zb.framework.mq.rocketmq.consumer;

import com.zb.framework.mq.rocketmq.vo.MessageVo;

import java.io.Serializable;

/**
 * 消费消息监听器<br/>
 *
 * Created by  2015/1/14.
 */
public interface MessageListener <T extends Serializable> {
    /**
     * 消费一个broker消息<br/>
     *
     * @param message
     */
    void consume(MessageVo<T> message);
}
