
package com.zb.framework.framework.pigeon.config.spring.schema;

import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

import com.zb.framework.framework.pigeon.extension.ExtensionBean;
import com.zb.framework.framework.pigeon.template.TemplateBean;

/**
 * 
 * 
 * @author 
 * @version $Id: PigeonNamespaceHandler.java, v 0.1 2013-6-24 下午10:16:41
 *           Exp $
 */
public class PigeonNamespaceHandler extends NamespaceHandlerSupport {

    public void init() {
        
        registerBeanDefinitionParser("extension",
                new PigeonBeanDefinitionParser(ExtensionBean.class, false));
        registerBeanDefinitionParser("template",
        		new PigeonBeanDefinitionParser(TemplateBean.class, false));
    }

}