package com.zb.framework.enums;



import java.io.Serializable;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

/**
 * 业务编码，主要用于业务流程中提示操作码，例如验证异常、网络异常、数据库异常等.<br/>
 * <p/>
 * <pre>
 *     如果需要增加服务特有的业务码，则可以通过继承{@link com.zb.framework.enums.BizCode}实现.
 * </pre>
 * <p/>
 * Created by  2014/12/10.
 */
public class BizCode extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = -6584286222918369706L;

    public static final BizCode Success = new BizCode("Success", ServiceCode.PHONY, "000", "成功");

    public static final BizCode Unknown = new BizCode("Unknown", ServiceCode.PHONY, "999", "未知错误");

    // --------------------------- 参数验证类
    public static final BizCode ParamNotNull
            = new BizCode("ParamNotNull", ServiceCode.PHONY, "001", "参数不能为null值");

    public static final BizCode ParamIsNull
            = new BizCode("ParamIsNull", ServiceCode.PHONY, "002", "参数必须为null值");

    public static final BizCode ParamNotEqual
            = new BizCode("ParamNotEqual", ServiceCode.PHONY, "003", "参数不能与特殊值相等");

    public static final BizCode ParamIsEqual
            = new BizCode("ParamIsEqual", ServiceCode.PHONY, "004", "参数必须与特殊值相等");

    public static final BizCode ParamTypeError
            = new BizCode("ParamTypeError", ServiceCode.PHONY, "005", "参数类型不正确");

    public static final BizCode ParamGE0
            = new BizCode("ParamGE0", ServiceCode.PHONY, "006", "参数必须大于等于0");

    public static final BizCode ParamGT0
            = new BizCode("ParamGT0", ServiceCode.PHONY, "007", "参数必须大于0");

    public static final BizCode ParamTooLitter
            = new BizCode("ParamTooLitter", ServiceCode.PHONY, "008", "参数值太小");

    public static final BizCode ParamTooGreater
            = new BizCode("ParamTooGreater", ServiceCode.PHONY, "009", "参数值太大");

    public static final BizCode ParamNumberError
            = new BizCode("ParamNumberError", ServiceCode.PHONY, "010", "参数不合法");

    public static final BizCode ParamNotEmpty
            = new BizCode("ParamNotEmpty", ServiceCode.PHONY, "011", "参数不能为空");

    public static final BizCode ParamNotBlank
            = new BizCode("ParamNotBlank", ServiceCode.PHONY, "012", "参数不能为空白");

    public static final BizCode ParamLenError
            = new BizCode("ParamLenError", ServiceCode.PHONY, "013", "参数长度错误");

    public static final BizCode ParamIsEmpty
            = new BizCode("ParamIsEmpty", ServiceCode.PHONY, "014", "参数必须为空");

    public static final BizCode ParamIsBlank
            = new BizCode("ParamIsBlank", ServiceCode.PHONY, "015", "参数必须为空白");

    public static final BizCode ParamStringLenError
            = new BizCode("ParamStringLenError", ServiceCode.PHONY, "016", "参数长度不合法");

    public static final BizCode ParamStringError
            = new BizCode("ParamStringError", ServiceCode.PHONY, "017", "参数不合法");

    public static final BizCode ParamError
            = new BizCode("ParamError", ServiceCode.PHONY, "018", "参数不合法");

    public static final BizCode ParamCollectionError
            = new BizCode("ParamCollectionError", ServiceCode.PHONY, "030", "容器元素不合法");

    // --------------------------- 业务验证类
    public static final BizCode BizDataNotExists
            = new BizCode("BizDataNotExists", ServiceCode.PHONY, "019", "数据不存在");

    public static final BizCode ConcurrentOperation
            = new BizCode("ConcurrentOperation", ServiceCode.PHONY, "020", "并发操作");

    public static final BizCode UnsupportedOperation
            = new BizCode("UnsupportedOperation", ServiceCode.PHONY, "022", "不支持的操作");

    public static final BizCode DuplicatedError
            = new BizCode("DuplicatedError", ServiceCode.PHONY, "026", "数据重复");

    // --------------------------- 网络验证类
    public static final BizCode NetworkTimeout
            = new BizCode("NetworkTimeout", ServiceCode.PHONY, "023", "网络超时");

    public static final BizCode TransCoreTimeout
            = new BizCode("TransCoreTimeout", ServiceCode.TransCore, "T99", "调用Transcore网络超时");

    public static final BizCode RiskTimeout
            = new BizCode("RiskTimeout", ServiceCode.Risk, "T99", "调用Risk网络超时");

    public static final BizCode BankEngineTimeout
            = new BizCode("BankEngineTimeout", ServiceCode.BankEngine, "T99", "调用BankEngine网络超时");

    public static final BizCode TATradeTimeout
            = new BizCode("TATradeTimeout", ServiceCode.TATrade, "T99", "调用TATrade网络超时");

    public static final BizCode BOSSTimeout
            = new BizCode("BOSSTimeout", ServiceCode.BOSS, "T99", "调用BOSS网络超时");

    public static final BizCode PayCoreTimeout
            = new BizCode("PayCoreTimeout", ServiceCode.PayCore, "T99", "调用PayCore网络超时");

    public static final BizCode AccTransTimeout
            = new BizCode("AccTransTimeout", ServiceCode.AccTrans, "T99", "调用AccTrans网络超时");

    public static final BizCode MerchantTimeout
            = new BizCode("MerchantTimeout", ServiceCode.Merchant, "T99", "调用Merchant网络超时");

    public static final BizCode CifTimeout
            = new BizCode("CifTimeout", ServiceCode.Cif, "T99", "调用Cif网络超时");

    public static final BizCode CashierTimeout
            = new BizCode("CashierTimeout", ServiceCode.Cashier, "T99", "调用Cashier网络超时");

    public static final BizCode AssetTimeout
            = new BizCode("AssetTimeout", ServiceCode.Asset, "T99", "调用Asset网络超时");

    public static final BizCode MobileTimeout
            = new BizCode("MobileTimeout", ServiceCode.Mobile, "T99", "调用Mobile网络超时");

    public static final BizCode PersonalTimeout
            = new BizCode("PersonalTimeout", ServiceCode.Personal, "T99", "调用Personal网络超时");

    public static final BizCode PaymentFeisTimeout
            = new BizCode("PaymentFeisTimeout", ServiceCode.PaymentFeis, "T99", "调用PaymentFeis网络超时");

    public static final BizCode FxoTimeout
            = new BizCode("FxoTimeout", ServiceCode.Fxo, "T99", "调用Fxo网络超时");

    public static final BizCode FxiTimeout
            = new BizCode("FxiTimeout", ServiceCode.Fxi, "T99", "调用Fxi网络超时");

    public static final BizCode AccountingTimeout
            = new BizCode("AccountingTimeout", ServiceCode.Accounting, "T99", "调用Accounting网络超时");

    public static final BizCode FreconTimeout
            = new BizCode("FreconTimeout", ServiceCode.Frecon, "T99", "调用Frecon网络超时");

    public static final BizCode AreconTimeout
            = new BizCode("AreconTimeout", ServiceCode.Arecon, "T99", "调用Arecon网络超时");

    // --------------------------- 平台相关类
    public static final BizCode ClassOrInstanceError
            = new BizCode("ClassOrInstanceError", ServiceCode.PHONY, "024", "clas或者新建实例相关");

    public static final BizCode IO_Error
            = new BizCode("IO_Error", ServiceCode.PHONY, "025", "IO操作异常");
    
 
    public static final BizCode LoginSuccess
            = new BizCode("LoginSuccess",ServiceCode.PHONY,"027","登录成功");

    public static final BizCode LoginFail
            = new BizCode("LoginFail",ServiceCode.PHONY,"028","登录失败");

    public static final BizCode LogoutStatus
            = new BizCode("logoutStatus",ServiceCode.PHONY,"029","未登录");


    // --------------------------- 属性
    private ServiceCode service = null; // 服务编码

    protected BizCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    public BizCode(String name, ServiceCode service, String code, String desc) {
        super(service.code() + name, service.code() + code, desc);

        validateCode(code);

        this.service = service;
    }

    private void validateCode(String code) {
        if(code == null || code.isEmpty()) {
            throw new IllegalArgumentException("code不能为空");
        }

        if(code.length() != 3) {
            throw new IllegalArgumentException("code长度必须为3");
        }
    }

    @Override
    protected final Class<? extends AbstractEnum> getEnumType() {
        return BizCode.class;
    }

    public final ServiceCode service() {
        return service;
    }
}
