/**
 * 
 * <p/>
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 匹配类型<br/>
 *
 * Created by  2015/12/30.
 */
public class MatchType extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = -6044821533007872406L;

    public static final MatchType Similar = new MatchType("S", "相似（兼容）");

    public static final MatchType Identical = new MatchType("I", "完全一致");

    public static final MatchType NotMatch = new MatchType("N", "不匹配");

    protected MatchType() {
        super();
    }

    protected MatchType(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return MatchType.class;
    }
}
