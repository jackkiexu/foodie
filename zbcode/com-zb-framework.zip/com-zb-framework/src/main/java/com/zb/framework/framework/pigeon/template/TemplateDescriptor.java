package com.zb.framework.framework.pigeon.template;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.zb.framework.framework.pigeon.xmap.annotation.XNode;
import com.zb.framework.framework.pigeon.xmap.annotation.XNodeList;
import com.zb.framework.framework.pigeon.xmap.annotation.XObject;

@XObject(value = "template")
public class TemplateDescriptor {

	@XNodeList(value = "process", type = ArrayList.class, componentType = ProcessDescriptor.class)
	private List<ProcessDescriptor> process;
	
	@XNode("@name")
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ProcessDescriptor> getProcess() {
		return process;
	}

	public void setProcess(List<ProcessDescriptor> process) {
		this.process = process;
	}

	 public String toString() {
	        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	    }

}
