package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 基金等级<br/>
 *
 * Created by  2015/1/9.
 */
public final class FundClass extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = -2116260157532612299L;

    public static final FundClass A = new FundClass("A", "A等级");

    public static final FundClass B = new FundClass("B", "B等级");

    public static final FundClass C = new FundClass("C", "C等级");

    public static final FundClass D = new FundClass("D", "D等级");

    public static final FundClass E = new FundClass("E", "E等级");

    public static final FundClass F = new FundClass("F", "F等级");

    protected FundClass() {
        ;// 解决反序列化无法构造新实例的问题！！
    }

    public FundClass(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return FundClass.class;
    }
}
