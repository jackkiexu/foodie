/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import java.io.Serializable;

import com.zb.framework.base.AbstractEnum;

/**
 * 支付工具
 * @author 
 * @version $Id: PayTool.java, v 0.1 2015年1月20日 下午4:34:50  Exp $
 */
public final class PayTool extends AbstractEnum implements Serializable{
    

    /**  */
    private static final long serialVersionUID = -1910519748719458817L;
    
    public static final  PayTool BANKCARDPAY=new PayTool("11","银行卡支付");
    public static final  PayTool MONEYFUNDPAY=new PayTool("12","货币基金支付");
    public static final  PayTool MONEYFUNDFROZEN=new PayTool("13","货币基金冻结");
    public static final  PayTool LUCKYMONEYPAY=new PayTool("14","红包支付");
    public static final  PayTool COUPONPAY=new PayTool("15","优惠券支付");
    
    public static final  PayTool ACCTTRANSFER=new PayTool("21","转账");
    
    public static final  PayTool WITHDRAW=new PayTool("31","提现");
    public static final  PayTool REFUND=new PayTool("32","退款");
    public static final  PayTool WDC2MFUND=new PayTool("33","提现到货币");
    public static final  PayTool MFUNDUNFROZEN=new PayTool("34","货币基金解冻");
    public static final  PayTool MFUNDUNREVOKE=new PayTool("35","货币撤单");
    public static final  PayTool WDC2LMONEY=new PayTool("36","红包提现");
    public static final  PayTool COUPONREVOKE=new PayTool("37","优惠券回退");
    
    
    
    
    protected PayTool(){
        ;
    }

    protected PayTool(String name,String desc){
        super(name,desc);
    }
    
    /** 
     * @see com.zb.framework.base.AbstractEnum#getEnumType()
     */
    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return PayTool.class;
    }
    

}
