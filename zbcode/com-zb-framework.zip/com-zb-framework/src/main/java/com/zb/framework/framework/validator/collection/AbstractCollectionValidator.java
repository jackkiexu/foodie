/**
 * 
 * <p/>
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.framework.validator.collection;

import com.zb.framework.enums.BizCode;
import com.zb.framework.framework.validator.Validator;
import com.zb.framework.framework.validator.base.AbstractValidator;
import com.zb.framework.util.CoreCommonUtils;

import java.util.Arrays;
import java.util.Collection;

/**
 * 容器相关的基类验证器<br/>
 *
 * Created by  2015/12/10.
 */
public abstract class AbstractCollectionValidator extends AbstractValidator implements Validator {
    public AbstractCollectionValidator(Object referObject) {
        super(referObject);

        if(!isCollection(referObject) && !isArray(referObject)) {
            CoreCommonUtils.raiseValidateException(BizCode.ParamError
                    , "参数必须是容器（实现Collection接口或者是array）");
        }

        if(isArray(referObject)) {
            setReferObject(Arrays.asList((Object[])referObject));
        }
    }

    protected boolean isCollection(Object referObject) {
        return referObject instanceof Collection;
    }

    protected boolean isArray(Object referObject) {
        return referObject != null && referObject.getClass().isArray();
    }
}
