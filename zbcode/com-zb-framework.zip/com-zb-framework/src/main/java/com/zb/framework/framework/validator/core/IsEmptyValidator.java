package com.zb.framework.framework.validator.core;

import com.zb.framework.framework.validator.Validator;
import com.zb.framework.framework.validator.base.AbstractValidator;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;

/**
 * Created by  2014/12/15.
 */
public class IsEmptyValidator extends AbstractValidator implements Validator {
    public IsEmptyValidator() {
        super(null);
    }

    @Override
    public boolean doValidate(Object target) {
        return target == null
                || ((target instanceof CharSequence)
                        && ((CharSequence) target).length() == 0)
                || ((target.getClass().isArray())
                        && (Array.getLength(target) <= 0))
                || ((target instanceof Collection)
                        && ((Collection) target).isEmpty())
                || ((target instanceof Map)
                        && ((Map) target).isEmpty());
    }
}
