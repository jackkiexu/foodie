package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 主业务编码类型<br/>
 *
 * Created by  2014/12/10.
 */
public final class BizMajorCode extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = 7362528093494500841L;

    public static final BizMajorCode General = new BizMajorCode("General", "00", "通用");

    public static final BizMajorCode Param = new BizMajorCode("Param", "01", "参数类相关");

    public static final BizMajorCode Biz = new BizMajorCode("Biz", "02", "业务验证相关");

    public static final BizMajorCode Network = new BizMajorCode("Network", "03", "网络相关");

    public static final BizMajorCode Unknown = new BizMajorCode("Unknown", "99", "未知");

    protected BizMajorCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    private BizMajorCode(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return BizMajorCode.class;
    }
}
