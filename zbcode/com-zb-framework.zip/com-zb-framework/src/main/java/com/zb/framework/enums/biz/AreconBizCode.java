/**
 * 
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 
 * @author 
 * @version $Id: ResultCode.java, v 0.1 2015年3月20日 下午1:59:38  Exp $
 */
public class AreconBizCode extends BizCode implements Serializable {

    /**
     * @Fields serialVersionUID :
     */
    private static final long serialVersionUID = 442530149296451246L;

    /** 返回码组成3位系统编码+3位编码 */
    /** 1开头的警告级别的错误 */
    /** 2开头的业务级别的错误 */
    /** 8开头的数据库级别的错误 */
    /** 9开头的系统级别的错误 */
    
    /** 2开头的业务级别的错误 */
    public static final AreconBizCode ARECON_QRY_PARAM_NULL = new AreconBizCode(
        "ARECON_QRY_PARAM_NULL", ServiceCode.Arecon, "200", "查询对账参数表数据为空");
    
    public static final AreconBizCode ARECON_INSERT_CONTROL_FAIL = new AreconBizCode(
        "ARECON_INSERT_CONTROL_FAIL", ServiceCode.Arecon, "201", "登记对账总控表失败");
    
    public static final AreconBizCode ARECON_UPD_CONTROL_FAIL = new AreconBizCode(
        "ARECON_UPD_CONTROL_FAIL", ServiceCode.Arecon, "202", "更新对账总控表失败");
    
    public static final AreconBizCode ARECON_UPD_NETCHK_FAIL = new AreconBizCode(
        "ARECON_UPD_NETCHK_FAIL", ServiceCode.Arecon, "203", "更新网关交易对账表失败");
    
    public static final AreconBizCode ARECON_CHK_PUSHDATE_FAIL = new AreconBizCode(
        "ARECON_CHK_PUSHDATE_FAIL", ServiceCode.Arecon, "204", "检查网关推送的数据是否到达失败");
    
    public static final AreconBizCode ARECON_BLEND_JNL_FAIL = new AreconBizCode(
        "ARECON_BLEND_JNL_FAIL", ServiceCode.Arecon, "205", "勾兑支付核心和银行网关的流水失败");
    
    public static final AreconBizCode ARECON_CALL_ACCTRANS_FAIL = new AreconBizCode(
        "ARECON_CALL_ACCTRANS_FAIL", ServiceCode.Arecon, "206", "调用账务记账失败");
    
    public static final AreconBizCode ARECON_GET_ACTDAT_FAIL = new AreconBizCode(
        "ARECON_GET_ACTDAT_FAIL", ServiceCode.Arecon, "207", "获取会计日期失败");
    
    
    /** 8开头的数据库级别的错误 */
    /** db幂等异常 */
    public static final AreconBizCode ARECON_DB_SYSTEM_ERROR = new AreconBizCode(
            "ARECON_DB_SYSTEM_ERROR", ServiceCode.Arecon, "899", "db幂等异常");

    /** 9开头的系统级别的错误 */
    /** 类转换失败 */
    public static final AreconBizCode ARECON_SYSTEM_CLASS_CONVERT_ERROR = new AreconBizCode(
            "ARECON_SYSTEM_CLASS_CONVERT_ERROR", ServiceCode.Arecon, "901",
            "类转换失败");

    /** 未知错误 */
    public static final AreconBizCode ARECON_UN_KNOWN = new AreconBizCode(
            "ARECON_UN_KNOWN", ServiceCode.Arecon, "998", "未知错误");

    /** 系统异常 */
    public static final AreconBizCode ARECON_SYSTEM_ERROR = new AreconBizCode(
            "ARECON_SYSTEM_ERROR", ServiceCode.Arecon, "999", "系统异常");

    private AreconBizCode(String name, ServiceCode serviceCode, String code,
            String desc) {
        super(name, serviceCode, code, desc);
    }
    
    private AreconBizCode() {

    }

}
