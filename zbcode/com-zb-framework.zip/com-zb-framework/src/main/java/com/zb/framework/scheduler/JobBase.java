/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.scheduler;

import java.util.Comparator;
import java.util.List;

/**
 * 任务调度器<br/>
 *
 * Created by  2015/4/21.
 */
public interface JobBase<T /*数据类型*/> {
    /**
     * 读取需要处理的任务数据<br/>
     *
     * @return
     */
    List<T> read(JobContext context);

    /**
     * 数据比较器<br/>
     *
     * @return
     */
    Comparator<T> getComparator();
}
