package com.zb.framework.framework.flow.vo;

import com.zb.framework.base.AbstractRequest;

import java.io.Serializable;

/**
 * 工作流参数基类<br/>
 *
 * Created by  2014/12/11.
 */
public abstract class AbstractFlowVo extends AbstractRequest implements Serializable {
    private static final long serialVersionUID = 2158531563595181141L;

}
