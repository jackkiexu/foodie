package com.zb.framework.mq.rocketmq.producer;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 消息发送状态<br/>
 *
 * Created by  2015/1/15.
 */
public final class SendStatus extends AbstractEnum implements Serializable {

    private static final long serialVersionUID = 3653309924978502419L;

    public static final SendStatus Success = new SendStatus("Success", "发送成功");

    public static final SendStatus Fail = new SendStatus("Fail", "发送失败");

    public static final SendStatus Unknown = new SendStatus("Unknown", "发送状态未知");

    protected SendStatus(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return SendStatus.class;
    }
}
