/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.event;

import org.apache.zookeeper.Watcher;

/**
 * Created by  2015/4/28.
 */
public class NodeChangeEvent extends EventObject {
    /**
     * 路径信息<br/>
     *
     */
    private String path = null;

    /**
     * 节点变化类型<br/>
     *
     */
    private Watcher.Event.EventType type = null;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Watcher.Event.EventType getType() {
        return type;
    }

    public void setType(Watcher.Event.EventType type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "NodeChangeEvent{" +
                "path='" + path + '\'' +
                ", type=" + type +
                "} " + super.toString();
    }
}
