/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 银行返回码映射
 * 
 * @author 
 * @version $Id: BankBizCode.java, v 0.1 2015年4月7日 上午10:05:06  Exp $
 */
public class BankBizCode  extends BizCode implements Serializable{

    /**  */
    private static final long serialVersionUID = 8629923963104798010L;
    
    public static final BankBizCode BankPending=new BankBizCode("BankPending",ServiceCode.BankEngine,"001","交易处理中");
    
    public static final BankBizCode UserNameError=new BankBizCode("UserNameError",ServiceCode.BankEngine,"A01","姓名不正确");
    
    public static final BankBizCode IdCardTypeError=new BankBizCode("IdCardTypeError",ServiceCode.BankEngine,"A02","证件类型不正确，或暂不支持该类型");
    
    public static final BankBizCode IdCardError=new BankBizCode("IdCardError",ServiceCode.BankEngine,"A03","证件号码不正确");
    
    public static final BankBizCode MobileError=new BankBizCode("MobileError",ServiceCode.BankEngine,"A04","银行预留手机号不正确，或未登记该手机号");
    
    public static final BankBizCode AcctVerifyTryOverLimit=new BankBizCode("AcctVerifyTryOverLimit",ServiceCode.BankEngine,"A08","该账号认证数量超限");
    
    public static final BankBizCode AcctTypeError=new BankBizCode("AcctTypeError",ServiceCode.BankEngine,"A11","银行卡/帐户类型不正确，或暂不支持该类型");
    
    public static final BankBizCode AcctNoError=new BankBizCode("AcctNoError",ServiceCode.BankEngine,"A15","银行卡/帐户不正确，或不存在");
    
    public static final BankBizCode AcctNoInValid=new BankBizCode("AcctNoInValid",ServiceCode.BankEngine,"A16","无效银行卡/帐户");
    
    public static final BankBizCode Cvv2Error=new BankBizCode("Cvv2Error",ServiceCode.BankEngine,"A17","银行卡CVV2不正确");
    
    public static final BankBizCode VerifyTimeOut=new BankBizCode("VerifyTimeOut",ServiceCode.BankEngine,"A18","验证超时无效");
    
    public static final BankBizCode AmtError=new BankBizCode("AmtError",ServiceCode.BankEngine,"A22","用户金额输入不正确");
    
    public static final BankBizCode AmtShort=new BankBizCode("AmtShort",ServiceCode.BankEngine,"A23","用户支付金额不足");
    
    public static final BankBizCode PasswordError=new BankBizCode("PasswordError",ServiceCode.BankEngine,"A27","密码不正确");
    
    public static final BankBizCode PasswordTryOverLimit=new BankBizCode("PasswordTryOverLimit",ServiceCode.BankEngine,"A28","密码尝试超过限制");
    
    public static final BankBizCode QueryPasswordError=new BankBizCode("QueryPasswordError",ServiceCode.BankEngine,"A29","查询密码不正确");
    
    public static final BankBizCode QueryPasswordryOverLimit=new BankBizCode("QueryPasswordryOverLimit",ServiceCode.BankEngine,"A30","查询密码尝试超过限制");
    
    public static final BankBizCode PayAmtOverLimit=new BankBizCode("PayAmtOverLimit",ServiceCode.BankEngine,"A31","支付总金额超限");
    
    public static final BankBizCode PayTimeOverLimit=new BankBizCode("PayTimeOverLimit",ServiceCode.BankEngine,"A32","支付次数超限");
    
    public static final BankBizCode NotOpenWebAccount=new BankBizCode("NotOpenWebAccount",ServiceCode.BankEngine,"A33","用户未开通电话/网上/手机支付，无法完成交易");
    
    public static final BankBizCode TradeTermTypeError=new BankBizCode("TradeTermTypeError",ServiceCode.BankEngine,"A34","交易终端类型限制");
    
    public static final BankBizCode AcctRegisted=new BankBizCode("AcctRegisted",ServiceCode.BankEngine,"A35","注册帐户已经申请，不允许重复申请");
    
    public static final BankBizCode NotOpenPayService=new BankBizCode("NotOpenPayService",ServiceCode.BankEngine,"A36","用户未开通支付服务");
    
    public static final BankBizCode NotOpenUnionPay=new BankBizCode("NotOpenUnionPay",ServiceCode.BankEngine,"A37","尚未开通银联在线，无法完成交易");
    
    public static final BankBizCode VerifyOverLimit=new BankBizCode("VerifyOverLimit",ServiceCode.BankEngine,"A39","验证次数超限");
    
    public static final BankBizCode TradeNotExist=new BankBizCode("TradeNotExist",ServiceCode.BankEngine,"A40","无此交易");
    
    public static final BankBizCode CommunicationError=new BankBizCode("CommunicationError",ServiceCode.BankEngine,"A43","Comm通信报文错误");
    
    public static final BankBizCode CommunicationSignError=new BankBizCode("CommunicationSignError",ServiceCode.BankEngine,"A44","Comm通信签名/密钥类错误/文件检验");
    
    public static final BankBizCode BankServerOverload=new BankBizCode("BankServerOverload",ServiceCode.BankEngine,"A46","Bank服务过载");
    
    public static final BankBizCode BankServerMaintain=new BankBizCode("BankServerMaintain",ServiceCode.BankEngine,"A47","Bank服务维护中");
    
    public static final BankBizCode BankAgreeNoError=new BankBizCode("BankAgreeNoError",ServiceCode.BankEngine,"A54","签约协议号不正确，交易失败");
    
    public static final BankBizCode CardNoRecognition=new BankBizCode("CardNoRecognition",ServiceCode.BankEngine,"A56","卡号无法识别");
    
    public static final BankBizCode SignalPayOverLimit=new BankBizCode("SignalPayOverLimit",ServiceCode.BankEngine,"A58","支付单笔金额超限");
    
    public static final BankBizCode CardNotSupport=new BankBizCode("CardNotSupport",ServiceCode.BankEngine,"A59","该银行卡不支持该商户，请换其他银行卡支付");
    
    public static final BankBizCode InCardNoError=new BankBizCode("InCardNoError",ServiceCode.BankEngine,"A60","转入的帐户/银行卡号不正确");
    
    public static final BankBizCode CurrencyError=new BankBizCode("CurrencyError",ServiceCode.BankEngine,"A62","用户支付币种不正确");
    
    public static final BankBizCode AcctQueryOverTime=new BankBizCode("AcctQueryOverTime",ServiceCode.BankEngine,"A63","帐户状态查询次数超限");
    
    public static final BankBizCode SmsSendError=new BankBizCode("SmsSendError",ServiceCode.BankEngine,"A64","短信发送失败，稍后再试");
    
    public static final BankBizCode PayOverDayLimit=new BankBizCode("PayOverDayLimit",ServiceCode.BankEngine,"A65","支付金额超过每日限额");
    
    public static final BankBizCode CardStateUnusual=new BankBizCode("CardStateUnusual",ServiceCode.BankEngine,"A66","银行卡/帐户状态异常或受限");
    
    public static final BankBizCode PayOverMonthLimit=new BankBizCode("PayOverMonthLimit",ServiceCode.BankEngine,"A67","支付金额超过每月限额");
    
    public static final BankBizCode CardStateInvalid=new BankBizCode("CardStateInvalid",ServiceCode.BankEngine,"A70","银行卡/帐户过期，或有效期无效");
    
    public static final BankBizCode ReserveNoEnough=new BankBizCode("ReserveNoEnough",ServiceCode.BankEngine,"A74","备付金余额不足");
    
    public static final BankBizCode F2PCardBindOverLimit=new BankBizCode("F2PCardBindOverLimit",ServiceCode.BankEngine,"A75","该银行卡绑定的快捷数量超限");
    
    public static final BankBizCode F2PCardUnBindFail=new BankBizCode("F2PCardUnBindFail",ServiceCode.BankEngine,"A79","解约失败");
    
    public static final BankBizCode AcctStateExcption=new BankBizCode("AcctStateExcption",ServiceCode.BankEngine,"A80","已签约的帐户状态异常，交易失败");
    
    public static final BankBizCode IdCardReSign=new BankBizCode("IdCardReSign",ServiceCode.BankEngine,"A81","该身份证件已被签约，不允许重复签约");
    
    public static final BankBizCode AgeNotOver18=new BankBizCode("AgeNotOver18",ServiceCode.BankEngine,"A82","年龄未满法定要求，不允许签约");
    
    public static final BankBizCode EmailError =new BankBizCode("EmailError",ServiceCode.BankEngine,"A83","Email不正确");
    
    public static final BankBizCode RegistOrSignFail =new BankBizCode("RegistOrSignFail",ServiceCode.BankEngine,"A84","注册/签约失败");
    
    public static final BankBizCode CardNoSigned =new BankBizCode("CardNoSigned",ServiceCode.BankEngine,"A85","该账号已经成功签约");
    
    public static final BankBizCode VerifyInfoError =new BankBizCode("VerifyInfoError",ServiceCode.BankEngine,"A93","验证信息不正确");
    
    public static final BankBizCode SmsVerifyError =new BankBizCode("SmsVerifyError",ServiceCode.BankEngine,"A94","短信验证码错误");
    
    public static final BankBizCode SignInfoError =new BankBizCode("SignInfoError",ServiceCode.BankEngine,"C01","卡号/密码/姓名输入错误");
    
    public static final BankBizCode IdCardInfoError =new BankBizCode("IdCardInfoError",ServiceCode.BankEngine,"C02","证件类型/证件号输入错误");
    
    public static final BankBizCode IdentityVerifyError =new BankBizCode("IdentityVerifyError",ServiceCode.BankEngine,"C03","身份验证错误（姓名/证件/证件类型等）");
    
    public static final BankBizCode IdentityVerifyErrorOrNotOpenUnionPay =new BankBizCode("IdentityVerifyErrorOrNotOpenUnionPay",ServiceCode.BankEngine,"C06","身份验证错误或请开通银联在线");
    
    public static final BankBizCode PayAmtOrTradeTimeOverLimit =new BankBizCode("PayAmtOrTradeTimeOverLimit",ServiceCode.BankEngine,"C07","支付金额或交易次数超限");
    
    public static final BankBizCode UserNameAndAcctNotMatch =new BankBizCode("UserNameAndAcctNotMatch",ServiceCode.BankEngine,"C08","用户姓名与帐户不匹配");
    
    public static final BankBizCode CardNoAndTypeNotMatch =new BankBizCode("CardNoAndTypeNotMatch",ServiceCode.BankEngine,"C09","卡号/帐户号与类型不匹配");
    
    public static final BankBizCode EmailAndMobileNotMatch =new BankBizCode("EmailAndMobileNotMatch",ServiceCode.BankEngine,"C10","Email或手机号不正确");
    
    public static final BankBizCode UserInfoInputError =new BankBizCode("UserInfoInputError",ServiceCode.BankEngine,"T01","用户信息输入错误");
    
    public static final BankBizCode MerchantInfoInputError =new BankBizCode("MerchantInfoInputError",ServiceCode.BankEngine,"T04","商户信息错误");
    
    public static final BankBizCode TradeFail =new BankBizCode("TradeFail",ServiceCode.BankEngine,"T05","交易失败");
    
    public static final BankBizCode TradeParamError =new BankBizCode("TradeParamError",ServiceCode.BankEngine,"T06","交易参数无效");
    
    public static final BankBizCode TradeLimit =new BankBizCode("TradeLimit",ServiceCode.BankEngine,"T07","交易受限");
    
    public static final BankBizCode TradeQueryError =new BankBizCode("TradeQueryError",ServiceCode.BankEngine,"T08","交易查询错误");
    
    public static final BankBizCode TradeRefundError =new BankBizCode("TradeRefundError",ServiceCode.BankEngine,"T09","交易退款错误");
    
    public static final BankBizCode PreAuthError =new BankBizCode("PreAuthError",ServiceCode.BankEngine,"T10","交易预授权错误");
    
    public static final BankBizCode CommError =new BankBizCode("CommError",ServiceCode.BankEngine,"T12","Comm错误");
    
    public static final BankBizCode BankServiceNotNormal =new BankBizCode("BankServiceNotNormal",ServiceCode.BankEngine,"T13","Bank服务不正常");
    
    public static final BankBizCode TradeTimeOut =new BankBizCode("TradeTimeOut",ServiceCode.BankEngine,"T15","交易超时");
    
    public static final BankBizCode RspCodeMapUnkown =new BankBizCode("RspCodeMapUnkown",ServiceCode.BankEngine,"999","银行返加码映射未知");
    
    
    
    protected BankBizCode() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    public BankBizCode(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }

}
