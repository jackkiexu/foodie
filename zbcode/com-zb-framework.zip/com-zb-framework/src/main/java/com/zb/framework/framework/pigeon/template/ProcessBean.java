package com.zb.framework.framework.pigeon.template;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ProcessBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3332849366872479140L;

	private String id;

	private Map<String, Object> actionsMap = new HashMap<String, Object>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Map<String, Object> getActionsMap() {
		return actionsMap;
	}

	public void setActionsMap(Map<String, Object> actionsMap) {
		this.actionsMap = actionsMap;
	}

	public Object getActionById(String id) {
		return this.actionsMap.get(id);
	}
}
