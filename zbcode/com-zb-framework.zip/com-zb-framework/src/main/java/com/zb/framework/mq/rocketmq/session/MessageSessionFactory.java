package com.zb.framework.mq.rocketmq.session;

/**
 * 创建RocketMQ客户端实例<br/>
 *
 * Created by  2015/1/15.
 */
public class MessageSessionFactory {
}
