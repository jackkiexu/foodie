package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 收费方式<br/>
 *
 * Created by  2015/1/9.
 */
public final class FeeType extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = -2415659030651322796L;

    public static final FeeType Pre = new FeeType("Pre", "0", "前收费");

    public static final FeeType Post = new FeeType("Post", "1", "后收费");

    public static final FeeType All = new FeeType("All", "2", "全部");

    protected FeeType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected FeeType(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return FeeType.class;
    }
}
