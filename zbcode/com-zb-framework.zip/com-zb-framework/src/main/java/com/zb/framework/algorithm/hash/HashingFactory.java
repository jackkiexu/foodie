
package com.zb.framework.algorithm.hash;
public abstract class HashingFactory {
    private HashingFactory() {
        ;
    }

    /**
     * Ketama算法<br/>
     *
     * @return
     */
    public static Hashing ketama() {
        return KetamaHashing.INSTANCE;
    }
}
