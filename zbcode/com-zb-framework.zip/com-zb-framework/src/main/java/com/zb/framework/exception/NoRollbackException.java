/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.exception;

import com.zb.framework.enums.BizCode;

import java.io.Serializable;

/**
 * 不需要事务回滚的异常<br/>
 *
 * Created by  2015/6/3.
 */
public class NoRollbackException extends BizException implements Serializable {
    private static final long serialVersionUID = -8575364767343264266L;

    public NoRollbackException() {
        super();
    }

    public NoRollbackException(BizCode code, String message) {
        super(code, message);
    }

    public NoRollbackException(BizCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public NoRollbackException(BizCode code, Throwable cause) {
        super(code, cause);
    }

    public NoRollbackException(boolean ignoreStackTrace) {
        super(ignoreStackTrace);
    }

    public NoRollbackException(BizCode code, String message, boolean ignoreStackTrace) {
        super(code, message, ignoreStackTrace);
    }

    public NoRollbackException(BizCode code, String message, Throwable cause, boolean ignoreStackTrace) {
        super(code, message, cause, ignoreStackTrace);
    }

    public NoRollbackException(BizCode code, Throwable cause, boolean ignoreStackTrace) {
        super(code, cause, ignoreStackTrace);
    }
}
