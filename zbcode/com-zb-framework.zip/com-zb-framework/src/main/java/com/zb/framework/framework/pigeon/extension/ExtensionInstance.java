
package com.zb.framework.framework.pigeon.extension;

public interface ExtensionInstance extends Extensible {

    Object getInstance();

    ExtensionName getName();

    int getStartLevel() throws Exception;
}
