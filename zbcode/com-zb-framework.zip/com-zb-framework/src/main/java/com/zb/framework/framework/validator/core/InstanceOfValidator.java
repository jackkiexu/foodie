package com.zb.framework.framework.validator.core;

import com.zb.framework.framework.validator.base.AbstractValidator;

/**
 * instance of验证器<br/>
 *
 * Created by  2014/12/15.
 */
public class InstanceOfValidator extends AbstractValidator {
    public InstanceOfValidator(Object referObject) {
        super(referObject);
    }

    @Override
    public boolean doValidate(Object target) {
        return ((Class<?>)getReferObject()).isInstance(target);
    }
}
