/**
 * 
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * @ClassName: ResultCode
 * @Description:
 * @author 
 * @date 2015年1月5日 下午2:32:38
 * @version V1.0
 */
public class AcctransBizCode extends BizCode implements Serializable {

	/**
	 * @Fields serialVersionUID :
	 */
	private static final long serialVersionUID = 442530149296451246L;

	/** 返回码组成3位系统编码+3位编码 */
	/** 1开头的警告级别的错误 */
	/** 2开头的业务级别的错误 */
	/** 8开头的数据库级别的错误 */
	/** 9开头的系统级别的错误 */

	// public static final ResultCode ACT_SUCCESS = new ResultCode("SUCCESS",
	// "000000", "交易成功");

	/** 1开头的警告级别的错误 */
	/** 记录不存在 */
	public static final AcctransBizCode ACT_WARN_NOT_EXIST_RECORD = new AcctransBizCode(
			"ACT_WARN_NOT_EXIST_RECORD", ServiceCode.AccTrans, "100",
			"记录不存在");

	/** 数据类型转换失败 */
	public static final AcctransBizCode ACT_DATA_TYPE_SWITCH_ERROR = new AcctransBizCode(
			"ACT_DATA_TYPE_SWITCH_ERROR", ServiceCode.AccTrans, "101",
			"数据类型转换失败");

	/** 交易码未定义 */
	public static final AcctransBizCode ACT_TXCD_NOT_DEF = new AcctransBizCode(
			"ACT_TXCD_NOT_DEF", ServiceCode.AccTrans, "102", "交易码未定义");

	/** 交易功能未开通 */
	public static final AcctransBizCode ACT_TXCD_CLOSE = new AcctransBizCode(
			"ACT_TXCD_CLOSE", ServiceCode.AccTrans, "103", "交易功能未开通");

	/** 返回结果为空 */
	public static final AcctransBizCode ACT_RESULT_CODE_NULL = new AcctransBizCode(
			"ACT_RESULT_CODE_NULL", ServiceCode.AccTrans, "104", "返回结果为空");

	/** 事务被锁定中 */
	public static final AcctransBizCode ACT_TXID_STATUS_LOC = new AcctransBizCode(
			"ACT_TXID_STATUS_LOC", ServiceCode.AccTrans, "105", "事务被锁定中");

	/** 交易的借贷金额不平 */
	public static final AcctransBizCode ACT_DEBIT_CREDIT_UNEQUAL = new AcctransBizCode(
			"ACT_DEBIT_CREDIT_UNEQUAL", ServiceCode.AccTrans, "106",
			"交易的借贷金额不平");

	/** 事务ID不存在 */
	public static final AcctransBizCode ACT_TXID_NOT_EXIST = new AcctransBizCode(
			"ACT_TXID_NOT_EXIST", ServiceCode.AccTrans, "107", "事务ID不存在");

	/** 事务ID处理中 */
	public static final AcctransBizCode ACT_TXID_PROCESSED = new AcctransBizCode(
			"ACT_TXID_PROCESSED", ServiceCode.AccTrans, "108", "事务ID处理中");

	/** 事务ID业务逻辑错误 */
	public static final AcctransBizCode ACT_TXID_BUS_ERROR = new AcctransBizCode(
			"ACT_TXID_BUS_ERROR", ServiceCode.AccTrans, "109", "事务ID业务逻辑错误");

	/** 2开头的业务级别的错误 */
	/** 关键字段不能为空 */
	public static final AcctransBizCode ACT_FIELD_NOT_NULL = new AcctransBizCode(
			"ACT_FIELD_NOT_NULL", ServiceCode.AccTrans, "201", "关键字段不能为空");

	/** 账户已存在 */
	public static final AcctransBizCode ACT_ACCOUNT_IS_EXIST = new AcctransBizCode(
			"ACT_ACCOUNT_IS_EXIST", ServiceCode.AccTrans, "202", "账户已存在");

	/** 账户类型未定义 */
	public static final AcctransBizCode ACT_ACT_TYP_NOT_DEF = new AcctransBizCode(
			"ACT_ACT_TYP_NOT_DEF", ServiceCode.AccTrans, "203", "账户类型未定义");

	/** 主账户余额信息已存在 */
	public static final AcctransBizCode ACT_ACCOUNT_BALLANCE_IS_EXIST = new AcctransBizCode(
			"ACT_ACCOUNT_BALLANCE_IS_EXIST", ServiceCode.AccTrans, "204",
			"主账户余额信息已存在");

	/** 主账户信息不存在 */
	public static final AcctransBizCode ACT_ACCOUNT_NOT_EXIST = new AcctransBizCode(
			"ACT_ACCOUNT_NOT_EXIST", ServiceCode.AccTrans, "205", "主账户信息不存在");

	/** 主账户信息已注销 */
	public static final AcctransBizCode ACT_ACCOUNT_CANCEL = new AcctransBizCode(
			"ACT_ACCOUNT_CANCEL", ServiceCode.AccTrans, "206", "主账户信息已注销");

	/** 主账户信息被冻结 */
	public static final AcctransBizCode ACT_ACCOUNT_HOLD = new AcctransBizCode(
			"ACT_ACCOUNT_HOLD", ServiceCode.AccTrans, "207", "主账户信息被冻结");

	/** 创建主账户余额信息失败 */
	public static final AcctransBizCode ACT_ACCOUNT_CRTBAL_FAIL = new AcctransBizCode(
			"ACT_ACCOUNT_CRTBAL_FAIL", ServiceCode.AccTrans, "208",
			"创建主账户余额信息失败");

	/** 账户余额金额值非法 */
	public static final AcctransBizCode ACT_ACCOUNT_CURBAL_ILLEGAL = new AcctransBizCode(
			"ACT_ACCOUNT_CURBAL_ILLEGAL", ServiceCode.AccTrans, "209",
			"账户余额金额值非法");

	/** 交易金额非法 */
	public static final AcctransBizCode ACT_ACCOUNT_TXAMT_ILLEGAL = new AcctransBizCode(
			"ACT_ACCOUNT_TXAMT_ILLEGAL", ServiceCode.AccTrans, "210",
			"交易金额非法");

	/** 更新主账户余额失败 */
	public static final AcctransBizCode ACT_ACCOUNT_UPDBAL_FAIL = new AcctransBizCode(
			"ACT_ACCOUNT_UPDBAL_FAIL", ServiceCode.AccTrans, "211",
			"更新主账户余额失败");

	/** 是否更新余额标志非法 */
	public static final AcctransBizCode ACT_ACCOUNT_UPDBAL_FLAG = new AcctransBizCode(
			"ACT_ACCOUNT_UPDBAL_FLAG", ServiceCode.AccTrans, "212",
			"是否更新余额标志非法");

	/** 创建内部账户余额信息失败 */
	public static final AcctransBizCode ACT_INNER_ACCOUNT_CRTBAL_FAIL = new AcctransBizCode(
			"ACT_INNER_ACCOUNT_CRTBAL_FAIL", ServiceCode.AccTrans, "213",
			"创建内部账户余额信息失败");

	/** 内部账户余额不足 */
	public static final AcctransBizCode ACT_INNER_ACCOUNT_BAL_NOMUCH = new AcctransBizCode(
			"ACT_INNER_ACCOUNT_BAL_NOMUCH", ServiceCode.AccTrans, "214",
			"内部账户余额不足");

	/** 更新内部账户余额失败 */
	public static final AcctransBizCode ACT_INNER_ACCOUNT_UPDBAL_FAIL = new AcctransBizCode(
			"ACT_INNER_ACCOUNT_UPDBAL_FAIL", ServiceCode.AccTrans, "215",
			"更新内部账户余额失败");

	/** 主账户余额信息不存在 */
	public static final AcctransBizCode ACT_ACCOUNT_BAL_NOT_EXIST = new AcctransBizCode(
			"ACT_ACCOUNT_BAL_NOT_EXIST", ServiceCode.AccTrans, "216",
			"主账户余额信息不存在");

	/** 主账户余额不足 */
	public static final AcctransBizCode ACT_ACCOUNT_BAL_NOMUCH = new AcctransBizCode(
			"ACT_ACCOUNT_BAL_NOMUCH", ServiceCode.AccTrans, "217", "主账户余额不足");

	/** 同冻结编号下追加的冻结账户必须一致 */
	public static final AcctransBizCode ACT_ACCOUNT_HOLD_ACCOUNTDIFF = new AcctransBizCode(
			"ACT_ACCOUNT_HOLD_ACCOUNTDIFF", ServiceCode.AccTrans, "218",
			"同冻结编号下追加的冻结账户必须一致");

	/** 不存在该冻结编号信息 */
	public static final AcctransBizCode ACT_ACCOUNT_NOT_EXIST_HOLD = new AcctransBizCode(
			"ACT_ACCOUNT_NOT_EXIST_HOLD", ServiceCode.AccTrans, "219",
			"不存在该冻结编号信息");

	/** 解冻金额大于原始冻结金额 */
	public static final AcctransBizCode ACT_ACCOUNT_UNHOLDAMT_FAIL = new AcctransBizCode(
			"ACT_ACCOUNT_UNHOLDAMT_FAIL", ServiceCode.AccTrans, "220",
			"解冻金额大于原始冻结金额");

	/** 内部账户信息不存在 */
	public static final AcctransBizCode ACT_INNER_ACCOUNT_NOT_EXIST = new AcctransBizCode(
			"ACT_INNER_ACCOUNT_NOT_EXIST", ServiceCode.AccTrans, "221",
			"内部账户信息不存在");

	/** 借贷标志非法 */
	public static final AcctransBizCode ACT_DCFLAG_ILLEGAL = new AcctransBizCode(
			"ACT_DCFLAG_ILLEGAL", ServiceCode.AccTrans, "222", "借贷标志非法");

	/** 冻结编号不存在 */
	public static final AcctransBizCode ACT_ACCOUNT_HOLDNO_NOT_EXIST = new AcctransBizCode(
			"ACT_ACCOUNT_HOLDNO_NOT_EXIST", ServiceCode.AccTrans, "223",
			"冻结编号不存在");
	
	/** 主账户系统占用余额非法*/
	public static final AcctransBizCode ACT_ACCOUNT_SYSBAL_ILLEGAL = new AcctransBizCode(
			"ACT_ACCOUNT_SYSBAL_ILLEGAL", ServiceCode.AccTrans, "224", "主账户系统占用余额非法");
	
	/** 主账户系统占用余额非法*/
    public static final AcctransBizCode ACT_REG_INNER_DTL_FAIL = new AcctransBizCode(
            "ACT_REG_INNER_DTL_FAIL", ServiceCode.AccTrans, "225", "登记内部账户收支明细失败");
    
    /** 交易流水不存在 */
    public static final AcctransBizCode ACT_TRANS_JNL_NOT_EXIST = new AcctransBizCode(
            "ACT_TRANS_JNL_NOT_EXIST", ServiceCode.AccTrans, "226", "交易流水不存在");
    
    /** 该交易为赎回类交易FROM必须为商户 */
    public static final AcctransBizCode ACT_REDMEET_ATRR_ERROR = new AcctransBizCode(
            "ACT_REDMEET_ATRR_ERROR", ServiceCode.AccTrans, "227", "该交易为赎回类交易FROM必须为商户");
    
    /** 调用会计核算系统失败 */
    public static final AcctransBizCode ACT_CALL_ACCOUNTING_FAIL = new AcctransBizCode(
            "ACT_CALL_ACCOUNTING_FAIL", ServiceCode.AccTrans, "228", "调用会计核算系统失败");
    
    /** 获取会计日期失败 */
    public static final AcctransBizCode ACT_GET_ACTDAT_FAIL = new AcctransBizCode(
            "ACT_GET_ACTDAT_FAIL", ServiceCode.AccTrans, "229", "获取会计日期失败");
    
    /** 登记主账户收支明细信息失败 */
    public static final AcctransBizCode ACT_REG_MAIN_DTL_FAIL = new AcctransBizCode(
            "ACT_REG_MAIN_DTL_FAIL", ServiceCode.AccTrans, "230", "登记主账户收支明细信息失败");
	
    /** 普通赎回或者快赎的垫资内部户不存在 */
    public static final AcctransBizCode ACT_REDEEM_TMPACTNO_NOT_EXIST = new AcctransBizCode(
            "ACT_REDEEM_TMPACTNO_NOT_EXIST", ServiceCode.AccTrans, "231", "普通赎回或者快赎的垫资内部户不存在");
    
    /** 更新综合记账流水表失败 */
    public static final AcctransBizCode ACT_ACC_JNL_UPD_FAIL = new AcctransBizCode(
            "ACT_ACC_JNL_UPD_FAIL", ServiceCode.AccTrans, "232", "更新综合记账流水表失败");
    
    /** 更新记账流水表失败 */
    public static final AcctransBizCode ACT_TRANS_JNL_UPD_FAIL = new AcctransBizCode(
            "ACT_TRANS_JNL_UPD_FAIL", ServiceCode.AccTrans, "233", "更新记账流水表失败");



	/** 该账户的头寸记录不存在 */
	public static final AcctransBizCode ACT_POS_ACTNO_NOT_EXIST = new AcctransBizCode(
			"ACT_POS_ACTNO_NOT_EXIST", ServiceCode.AccTrans, "301", "该账户的头寸记录不存在");

	/** 该账户的头寸额度不足 */
	public static final AcctransBizCode ACT_POS_ACTNO_NOMUCH = new AcctransBizCode(
			"ACT_POS_ACTNO_NOMUCH", ServiceCode.AccTrans, "302", "该账户的头寸额度不足");

	/** 该账户的头寸额度小于单笔上限额度 */
	public static final AcctransBizCode ACT_POS_ACTNO_LESS_SIGL = new AcctransBizCode(
			"ACT_POS_ACTNO_LESS_SIGL", ServiceCode.AccTrans, "303", "该账户的头寸额度小于单笔上限额度");

	/** 更新银行备付金账户头寸管理表失败 */
	public static final AcctransBizCode ACT_UPD_POS_MNG_FAIL = new AcctransBizCode(
			"ACT_UPD_POS_MNG_FAIL", ServiceCode.AccTrans, "304", "更新银行备付金账户头寸管理表失败");

	/** 该头寸的流水记录不存在 */
	public static final AcctransBizCode ACT_POS_JNL_NOT_EXIST = new AcctransBizCode(
			"ACT_POS_JNL_NOT_EXIST", ServiceCode.AccTrans, "305", "该头寸的流水记录不存在");

	/** 更新银行备付金账户头寸调整流水失败 */
	public static final AcctransBizCode ACT_UPD_POS_JNL_FAIL = new AcctransBizCode(
			"ACT_UPD_POS_JNL_FAIL", ServiceCode.AccTrans, "306", "更新银行备付金账户头寸调整流水失败");

	/** 头寸的冻结编号不存在 */
	public static final AcctransBizCode ACT_POS_HOLD_NOT_EXIST = new AcctransBizCode(
			"ACT_POS_HOLD_NOT_EXIST", ServiceCode.AccTrans, "307", "头寸的冻结编号不存在");

	/** 更新快取冻结表失败 */
	public static final AcctransBizCode ACT_UPD_POS_HOLD_FAIL = new AcctransBizCode(
			"ACT_UPD_POS_HOLD_FAIL", ServiceCode.AccTrans, "308", "更新快取冻结表失败");

	/** 头寸管理流水预登记 */
	public static final AcctransBizCode ACT_POS_JNL_PRE_REG = new AcctransBizCode(
			"ACT_POS_JNL_PRE_REG", ServiceCode.AccTrans, "309", "头寸管理流水预登记");


	/** 8开头的数据库级别的错误 */
	/** db幂等异常 */
	public static final AcctransBizCode ACT_DB_SYSTEM_ERROR = new AcctransBizCode(
			"ACT_DB_SYSTEM_ERROR", ServiceCode.AccTrans, "899", "db幂等异常");

	/** 9开头的系统级别的错误 */
	/** 类转换失败 */
	public static final AcctransBizCode ACT_SYSTEM_CLASS_CONVERT_ERROR = new AcctransBizCode(
			"ACT_SYSTEM_CLASS_CONVERT_ERROR", ServiceCode.AccTrans, "901",
			"类转换失败");

	/** 未知错误 */
	public static final AcctransBizCode ACT_UN_KNOWN = new AcctransBizCode(
			"ACT_UN_KNOWN", ServiceCode.AccTrans, "998", "未知错误");

	/** 系统异常 */
	public static final AcctransBizCode ACT_SYSTEM_ERROR = new AcctransBizCode(
			"ACT_SYSTEM_ERROR", ServiceCode.AccTrans, "999", "系统异常");

	private AcctransBizCode(String name, ServiceCode serviceCode, String code,
			String desc) {
		super(name, serviceCode, code, desc);
	}
	
	private AcctransBizCode() {

	}

}
