package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 交易状态<br/>
 *
 * Created by  2015/1/19.
 */
public class TransStatus extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = -9068986287708216465L;

    public static final TransStatus Initial = new TransStatus("N", "未处理");

    public static final TransStatus Closed = new TransStatus("C", "关闭");

    public static final TransStatus PayPending = new TransStatus("PI", "支付中");

    public static final TransStatus PayPartial = new TransStatus("PP", "部分支付");

    public static final TransStatus PaySuccess = new TransStatus("PY", "支付成功");

    public static final TransStatus PayFail = new TransStatus("PF", "支付失败");

    public static final TransStatus TAPending = new TransStatus("TI", "份额处理中");

    public static final TransStatus TAPartial= new TransStatus("TP", "份额部分处理中");

    public static final TransStatus TASuccess = new TransStatus("TY", "份额处理成功");

    public static final TransStatus TAFail = new TransStatus("TF", "份额处理失败");

    public static final TransStatus Success = new TransStatus("Y", "成功");

    public static final TransStatus Fail = new TransStatus("F", "失败");

    protected TransStatus() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected TransStatus(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected final Class<? extends AbstractEnum> getEnumType() {
        return TransStatus.class;
    }
}
