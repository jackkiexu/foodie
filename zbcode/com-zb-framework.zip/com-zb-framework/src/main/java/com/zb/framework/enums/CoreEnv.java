package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 环境状态<br/>
 *
 *
 */
public final class CoreEnv extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = 239777752289079524L;

    public static final CoreEnv PRE_ENV = new CoreEnv("PRE_ENV", "PRE_ENV", "预发环境");

    public static final CoreEnv PRD_ENV = new CoreEnv("PRD_ENV", "PRD_ENV", "生产环境");


    protected CoreEnv() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected CoreEnv(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return CoreEnv.class;
    }
}
