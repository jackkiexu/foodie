/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.event;

/**
 * Created by  2015/4/28.
 */
public interface SessionListener {
    /**
     * 当服务与zk服务器已经断开连接时发出的事件<br/>
     *
     * @param event
     */
    void onDisconnected(SessionEvent event);

    /**
     * 当服务与zk服务器已经建立连接时发出的事件<br/>
     *
     * @param event
     */
    void onConnected(SessionEvent event);

    /**
     * 当服务与zk服务器seesion超时时发出的事件<br/>
     *
     * @param event
     */
    void onExpired(SessionEvent event);
}
