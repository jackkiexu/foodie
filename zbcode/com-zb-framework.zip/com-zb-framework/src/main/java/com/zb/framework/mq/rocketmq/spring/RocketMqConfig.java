package com.zb.framework.mq.rocketmq.spring;

import com.zb.framework.enums.BizCode;
import com.zb.framework.util.CoreCommonUtils;
import org.springframework.beans.factory.InitializingBean;

/**
 * RocketMQ客户端配置<br/>
 *
 * Created by  2015/1/14.
 */
public class RocketMqConfig implements InitializingBean {
    /**
     * Name Server服务器地址结合，格式：ip:port[;ip:port]<br/>
     *
     */
    private String namesrvAddressSet = null;

    /**
     * Netty异步执行回调的线程数<br/>
     *
     */
    private int nettyAsyncExecutorThreads = Runtime.getRuntime().availableProcessors();

    /**
     * 从Name Server上同步路由信息的时间隔<br/>
     *
     */
    private int syncRouteInfoInterval = 1000 * 30;

    /**
     * 客户端与Broker保持心跳的时间隔<br/>
     *
     */
    private int heartbeat4BrokerInterval = 1000 * 30;

    /**
     * 客户端持久化消费进度的时间隔<br/>
     *
     */
    private int persistOffsetInterval = 1000 * 5;

    /**
     * 发送消息超时时间，默认1秒<br/>
     *
     */
    private int sendMessageTimeout = 1000;

    /**
     * 发送失败后重试次数<br/>
     *
     */
    private int retryTimes = 1;

    public String getNamesrvAddressSet() {
        return namesrvAddressSet;
    }

    public void setNamesrvAddressSet(String namesrvAddressSet) {
        this.namesrvAddressSet = namesrvAddressSet;
    }

    public int getNettyAsyncExecutorThreads() {
        return nettyAsyncExecutorThreads;
    }

    public void setNettyAsyncExecutorThreads(int nettyAsyncExecutorThreads) {
        this.nettyAsyncExecutorThreads = nettyAsyncExecutorThreads;
    }

    public int getSyncRouteInfoInterval() {
        return syncRouteInfoInterval;
    }

    public void setSyncRouteInfoInterval(int syncRouteInfoInterval) {
        this.syncRouteInfoInterval = syncRouteInfoInterval;
    }

    public int getHeartbeat4BrokerInterval() {
        return heartbeat4BrokerInterval;
    }

    public void setHeartbeat4BrokerInterval(int heartbeat4BrokerInterval) {
        this.heartbeat4BrokerInterval = heartbeat4BrokerInterval;
    }

    public int getPersistOffsetInterval() {
        return persistOffsetInterval;
    }

    public void setPersistOffsetInterval(int persistOffsetInterval) {
        this.persistOffsetInterval = persistOffsetInterval;
    }

    public int getSendMessageTimeout() {
        return sendMessageTimeout;
    }

    public void setSendMessageTimeout(int sendMessageTimeout) {
        this.sendMessageTimeout = sendMessageTimeout;
    }

    public int getRetryTimes() {
        return retryTimes;
    }

    public void setRetryTimes(int retryTimes) {
        this.retryTimes = retryTimes;
    }

    @Override
    public String toString() {
        return "RocketMqConfig{" +
                "namesrvAddressSet='" + namesrvAddressSet + '\'' +
                ", nettyAsyncExecutorThreads=" + nettyAsyncExecutorThreads +
                ", syncRouteInfoInterval=" + syncRouteInfoInterval +
                ", heartbeat4BrokerInterval=" + heartbeat4BrokerInterval +
                ", persistOffsetInterval=" + persistOffsetInterval +
                '}';
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if(namesrvAddressSet == null || namesrvAddressSet.isEmpty()) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "RocketMQ NameServer服务器列表不能为空");
        }
    }
}
