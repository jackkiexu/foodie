/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * 
 * @author 
 * @version $Id: Task.java, v 0.1 2015年2月6日 上午9:53:55  Exp $
 */

public abstract class Task<T> implements Runnable {

	protected static Logger logger = LoggerFactory.getLogger("Task");

	protected Task() {
	}

	protected Task(T task) {
		this.task = task;
	}

	private T task;

	public String taskId;

	public String getTaskId() {
		return this.taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public T getTask() {
		return task;
	}

	public void setTask(T task) {
		this.task = task;
	}

}
