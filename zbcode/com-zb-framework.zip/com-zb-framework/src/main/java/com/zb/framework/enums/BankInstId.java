package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 银行机构号（简称）<br/>
 *
 * Created by  2015/1/19.
 */
public final class BankInstId extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = -1432658340823140508L;

    public static final BankInstId ICBC = new BankInstId("ICBC", "工商银行");

    public static final BankInstId ABC = new BankInstId("ABC", "农业银行");

    public static final BankInstId BOC = new BankInstId("BOC", "中国银行");

    public static final BankInstId CCB = new BankInstId("CCB", "建设银行");

    public static final BankInstId BCM = new BankInstId("BCM", "交通银行");

    public static final BankInstId CMB = new BankInstId("CMB", "招商银行");

    public static final BankInstId CMBC = new BankInstId("CMBC", "民生银行");

    public static final BankInstId PSBC = new BankInstId("PSBC", "邮储银行");

    public static final BankInstId GDB = new BankInstId("GDB", "广发银行");

    public static final BankInstId PAB = new BankInstId("PAB", "平安银行");

    public static final BankInstId CITIC = new BankInstId("CITIC", "中信银行");

    public static final BankInstId SPDB = new BankInstId("SPDB", "浦发银行");

    public static final BankInstId CEB = new BankInstId("CEB", "光大银行");
    
    public static final BankInstId HXB = new BankInstId("HXB", "华夏银行");
    
    public static final BankInstId BOS = new BankInstId("BOS", "上海银行");
    
    public static final BankInstId CIB = new BankInstId("CIB", "兴业银行");
    
    public static final BankInstId HSBC = new BankInstId("HSBC", "汇丰银行");
    
    public static final BankInstId BOFD = new BankInstId("BOFD", "富滇银行");
    
    public static final BankInstId CSCB = new BankInstId("CSCB", "长沙银行");
    
    public static final BankInstId NJCB = new BankInstId("NJCB", "南京银行");
    
    public static final BankInstId BOLJ = new BankInstId("BOLJ", "龙江银行");
    
    public static final BankInstId BOHB = new BankInstId("BOHB", "湖北银行");
    
    public static final BankInstId BOGS = new BankInstId("BOGS", "甘肃银行");
    
    public static final BankInstId CZCCB = new BankInstId("CZCCB", "长治银行");
    
    public static final BankInstId SRCB = new BankInstId("SRCB", "上海农商行");
    
    public static final BankInstId BOTJ = new BankInstId("BOTJ", "天津银行");
    
    public static final BankInstId BOWZ = new BankInstId("BOWZ", "温州银行");
    
    public static final BankInstId GRCB = new BankInstId("GRCB", "广州农村商业银行");
    
    public static final BankInstId BOHZ = new BankInstId("BOHZ", "杭州银行");
    
    public static final BankInstId BOYT = new BankInstId("BOYT", "烟台银行");
    
    public static final BankInstId BOCZ = new BankInstId("BOCZ", "浙商银行");
    
    public static final BankInstId BONB = new BankInstId("BONB", "宁波银行");
    
    public static final BankInstId BOHS = new BankInstId("BOHS", "徽商银行");
    
    public static final BankInstId SCB = new BankInstId("SCB", "渣打银行");
    
    public static final BankInstId BOCQ = new BankInstId("BOCQ", "重庆银行");
    
    public static final BankInstId BODL = new BankInstId("BODL", "大连银行");
    
    public static final BankInstId BOJS = new BankInstId("BOJS", "江苏银行");
    
    public static final BankInstId QDB = new BankInstId("QDB", "青岛银行");
    
    public static final BankInstId HKB = new BankInstId("HKB", "汉口银行");
    
    public static final BankInstId MTB = new BankInstId("MTB", "浙江民泰");
    
    public static final BankInstId TZB = new BankInstId("TZB", "台州银行");
    
    public static final BankInstId BOLZ = new BankInstId("BOLZ", "兰州银行");
    
    public static final BankInstId CZRCB = new BankInstId("CZRCB", "长治农商银行");
    
    public static final BankInstId XZRCB = new BankInstId("XZRCB", "新政农村商业银行");
    
    public static final BankInstId BOBJ = new BankInstId("BOBJ", "北京银行");
    
    public static final BankInstId BSB = new BankInstId("BSB", "包商银行");
    
    public static final BankInstId GDNYB = new BankInstId("GDNYB", "广东南粤银行");
    
    public static final BankInstId HEBBANK = new BankInstId("HEBBANK", "河北银行");
    
    public static final BankInstId OTHER = new BankInstId("OTHER", "支付宝");
    
    
    
    
    

    protected BankInstId() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected BankInstId(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return BankInstId.class;
    }
}
