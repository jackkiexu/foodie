/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import java.io.Serializable;

import com.zb.framework.base.AbstractEnum;

/**
 * 支付类型
 * @author 
 * @version $Id: PayTypeCode.java, v 0.1 2015年1月22日 下午4:43:34  Exp $
 */
public  final class PayTypeCode extends AbstractEnum implements Serializable{

    
    /**  */
    private static final long serialVersionUID = -189819046574563661L;
    
    public static final  PayTypeCode PURE_RECHARGE=new PayTypeCode("10","电子账户充值");
    public static final  PayTypeCode CONSUMER_RECHARGE=new PayTypeCode("11","消费账户充值");
    public static final  PayTypeCode ACCOUNT_TRANSTER=new PayTypeCode("20","转账");
    public static final  PayTypeCode REFUND=new PayTypeCode("30","退款");
    public static final  PayTypeCode WITHDRAW=new PayTypeCode("31","提现");
    public static final  PayTypeCode INSURANCE_IN=new PayTypeCode("40","保险入账");
    public static final  PayTypeCode INSURANCE_OUT=new PayTypeCode("41","保险出账");
    

    protected PayTypeCode(){
        ;
    }

    protected PayTypeCode(String name,String desc){
        super(name,desc);
    }
    
    /** 
     * @see com.zb.framework.base.AbstractEnum#getEnumType()
     */
    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return PayTypeCode.class;
    }

}
