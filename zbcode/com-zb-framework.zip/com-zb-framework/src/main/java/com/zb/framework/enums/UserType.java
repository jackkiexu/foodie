package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 用户类型<br/>
 *
 * Created by  2015/1/19.
 */
public final class UserType extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = -5197412258026511036L;

    public static final UserType Individual = new UserType("Individual", "0", "个人");

    public static final UserType Merchant = new UserType("Merchant", "1", "商户");

    public static final UserType Internal = new UserType("Internal", "2", "内部户");

    protected UserType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected UserType(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return UserType.class;
    }
}
