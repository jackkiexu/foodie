package com.zb.framework.framework.flow.listener;

import com.zb.framework.framework.flow.Listener;
import com.zb.framework.framework.flow.OutboundProperty;

/**
 * Handler异常监听器<br/>
 *
 * Created by  2014/6/16.
 */
public interface ExceptionListener extends Listener {
    /**
     * 当异常发生时的回调逻辑<br/>
     *
     * @param outboundProperty
     * @param ex
     */
    void onCaught(OutboundProperty outboundProperty, Exception ex);
}
