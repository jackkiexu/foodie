package com.zb.framework.exception;

import com.zb.framework.base.BaseCheckedException;
import com.zb.framework.enums.BizCode;

import java.io.Serializable;

/**
 * 用于跨服务调用运行时异常<br/>
 *
 * Created by  2014/12/10.
 */
public class RemoteCheckedException extends BaseCheckedException implements Serializable {
    private static final long serialVersionUID = 4350868573071491642L;

    public RemoteCheckedException() {
        super();
    }

    public RemoteCheckedException(BizCode code, String message) {
        super(code, message);
    }

    public RemoteCheckedException(BizCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public RemoteCheckedException(BizCode code, Throwable cause) {
        super(code, cause);
    }

    public RemoteCheckedException(boolean ignoreStackTrace) {
        super(ignoreStackTrace);
    }

    public RemoteCheckedException(BizCode code, String message, Throwable cause, boolean ignoreStackTrace) {
        super(code, message, cause, ignoreStackTrace);
    }

    public RemoteCheckedException(BizCode code, String message, boolean ignoreStackTrace) {
        super(code, message, ignoreStackTrace);
    }

    public RemoteCheckedException(BizCode code, Throwable cause, boolean ignoreStackTrace) {
        super(code, cause, ignoreStackTrace);
    }
}
