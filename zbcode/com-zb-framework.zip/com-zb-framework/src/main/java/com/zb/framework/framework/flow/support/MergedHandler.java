/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.framework.flow.support;

import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.enums.PhaseCode;
import com.zb.framework.framework.flow.handler.AbstractUnskippableHandler;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;

import java.util.ArrayList;
import java.util.List;

/**
 * 将多个节点合并为一个独立的节点，主要用于复用<br/>
 *
 * Created by  2015/4/23.
 */
public class MergedHandler extends AbstractUnskippableHandler implements Handler {
    @Override
    public boolean isAsync() {
        return false;
    }

    @Override
    protected boolean doHandle(Context context, AbstractFlowVo callerParam) {
        for(Handler handler : handlers) {
            final boolean result = handler.handle(context);

            // 如果有停止的处理请求，则返回；
            if(!result) {
                return result;
            }
        }
        return true;
    }

    @Override
    public PhaseCode getPhaseCode() {
        return null;
    }

    // ----------------------------------- properties;
    private List<Handler> handlers = new ArrayList<>(4);

    public List<Handler> getHandlers() {
        return handlers;
    }

    public void setHandlers(List<Handler> handlers) {
        this.handlers = handlers;
    }
}
