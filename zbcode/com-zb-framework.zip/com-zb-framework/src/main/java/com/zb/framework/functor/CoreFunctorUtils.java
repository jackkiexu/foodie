/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.functor;

/**
 * Created by  2015/8/18.
 */
public class CoreFunctorUtils {
    private CoreFunctorUtils() {
        ;
    }

    /**
     * 不进行转换的函数实现<br/>
     *
     * @param <T>
     * @return
     */
    public static <T> Transformer<T, T> nopTransform() {
        return new NopTransformer<>();
    }

    // --------------------------------- inner class
    private static class NopTransformer<T, F extends T> implements Transformer<F, T> {
        @Override
        public T transform(F f) {
            return f;
        }
    }
}
