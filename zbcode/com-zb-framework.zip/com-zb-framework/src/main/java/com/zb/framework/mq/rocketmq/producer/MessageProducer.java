package com.zb.framework.mq.rocketmq.producer;

/**
 * 消息生产者接口<br/>
 *
 * Created by  2015/1/14.
 */
public interface MessageProducer {
    /**
     * 同步发送消息<br/>
     *
     * @param builder
     */
    SendResult send(MessageBuilder builder);
}
