package com.zb.framework.framework.flow.listener;

import com.zb.framework.framework.flow.OutboundProperty;

/**
 * Handler的方法监听器<br/>
 *
 * Created by  2014/8/26.
 */
public interface AroundListener extends ExceptionListener {
    /**
     * 在进入try block时的回调函数<br/>
     *
     * @param outboundProperty
     */
    void onTry(OutboundProperty outboundProperty);

    /**
     * 在进入catch时的回调函数<br/>
     *
     * @param outboundProperty
     * @param ex
     */
    void onCaught(OutboundProperty outboundProperty, Exception ex);

    /**
     * 在进入finally block时的回调函数<br/>
     *
     * @param outboundProperty
     */
    void onFinally(OutboundProperty outboundProperty);
}
