
package com.zb.framework.algorithm.hash.consistent;

/**
 * Created by  2015/5/6.
 */
public interface BucketNode {
    /**
     * 当前阶段的关键字<br/>
     *
     * @return
     */
    public String getBucketKey();
}
