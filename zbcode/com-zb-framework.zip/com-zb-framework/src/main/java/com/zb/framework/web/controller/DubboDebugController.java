package com.zb.framework.web.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.zb.framework.enums.BizCode;
import com.zb.framework.util.CoreCommonUtils;
import com.zb.framework.web.vo.DubboInvokeResultVo;
import com.zb.framework.web.vo.DubboInvokeVo;
import net.sf.ezmorph.MorphUtils;
import net.sf.ezmorph.MorpherRegistry;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Controller;
import org.springframework.util.ClassUtils;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by  2014/9/23.
 */
@Controller
@RequestMapping("/dubbo-debug")
public class DubboDebugController implements ApplicationContextAware {
    private static final Logger LOG = LoggerFactory.getLogger(DubboDebugController.class);

    private MorpherRegistry morpher = new MorpherRegistry();

    private ApplicationContext applicationContext = null;

    /**
     * Spring Bean的缓存<br/>
     *
     */
    private Map<String, Object> beanCache = new ConcurrentHashMap<String, Object>(8, 1F);

    /**
     * Method的缓存<br/>
     *
     */
    private Map<String, Method> methodCache = new ConcurrentHashMap<String, Method>(8, 1F);

    public DubboDebugController() {
        MorphUtils.registerStandardMorphers(morpher);
    }

    @RequestMapping(value = "invoke.form", method = RequestMethod.POST)
    @ResponseBody
    public DubboInvokeResultVo invoke(@RequestParam(value = "interfaceName", required = true)String interfaceName
            , @RequestParam(value = "methodName", required = true)String methodName
            , @RequestParam(value = "parameters", required = true)String parameters // 一律按照json格式传递
            , @RequestParam(value = "parameterNum", required = false, defaultValue = "-1")int parameterNum
            , @RequestParam(value = "parameterTypes", required = false)String[] parameterTypes) {
        DubboInvokeVo vo = new DubboInvokeVo();
        vo.setInterfaceName(interfaceName);
        vo.setMethodName(methodName);
        vo.setParameters(parameters);
        vo.setParameterNum(parameterNum);
        vo.setParameterTypes(parameterTypes);
        initVo(vo);

        try {
            return innerInvoke(vo);
        } catch (Exception e) {
            LOG.warn("调用dubbo接口异常", e);

            return new DubboInvokeResultVo(ExceptionUtils.getStackTrace(e));
        }
    }

    private void initVo(DubboInvokeVo vo) {
        vo.setParametersArray(toArray(vo.getParameters()));

        // 如果未设置参数个数，则设置为参数值的个数
        if(vo.getParameterNum() == -1) {
            vo.setParameterNum(vo.getParametersArray().length);
        }

        // 如果参数值的个数与参数个数的设置不一致，则提示错误
        if(vo.getParameterNum() != vo.getParametersArray().length) {
            throw new RuntimeException("parameterNum的值必须与参数parameters的个数一致.");
        }

        // 参数的个数必须与类型设置一致 (如果设置的情况下，默认是未设置的)
        int types = ArrayUtils.getLength(vo.getParameterTypes());
        if(types > 0 && types > vo.getParameterNum()) { // 类型的个数必须小于等于参数个数！！
            throw new RuntimeException("参数类型的个数必须小于等于参数个数");
        }

        // 生成md5值
        String key = vo.getInterfaceName() + vo.getMethodName()
                + vo.getParametersArray().length + StringUtils.join(vo.getParameterTypes(), ",");
        vo.setMd5(DigestUtils.md5DigestAsHex(key.getBytes()));
    }

    public DubboInvokeResultVo innerInvoke(DubboInvokeVo vo) throws Exception {
        Object bean = getDubboBean(vo);

        Method method = getMethod(bean, vo);

        Object result = invoke(bean, method, vo.getParametersArray());

        return new DubboInvokeResultVo(result);
    }

    private Object invoke(Object bean, Method method, String[] parameters) throws Exception {
        Class<?>[] types = method.getParameterTypes();

        return method.invoke(bean, genParameters(types, parameters));
    }

    private Object[] genParameters(Class<?>[] types, String[] parameters) {
        if(types.length != parameters.length) {
            CoreCommonUtils.raiseBizException(BizCode.Unknown
                    , "调用方法的参数个数与实际方法不一致.");
        }

        Object params[] = new Object[types.length];
        for(int i = 0; i < types.length; i++) {
            String param = parameters[i];
            param = StringUtils.trim(param);

            // 检查嵌套的json；
            if(param.startsWith("{") && !(types[i].equals(String.class))) {
                GsonBuilder gb = new GsonBuilder();
                Gson g = gb.create();

                params[i] = g.fromJson(param, types[i]);
            } else {
                params[i] = morpher.morph(types[i], param);
            }
        }

        return params;
    }

    /**
     * 将json格式参数转换为数组参数，顺序为调用方法的参数顺序<br/>
     *
     * @param parameters
     * @return
     */
    private String[] toArray(String parameters) {
        if(StringUtils.isEmpty(parameters)) {
            return new String[0];
        }

        GsonBuilder gb = new GsonBuilder();
        Gson g = gb.create();
        Map<String,String> map = g.fromJson(
                parameters, new TypeToken<Map<String,String>>(){}.getType());


        String[] array = new String[map.size()];
        for(Map.Entry<String,String> entry : map.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            try {
                int index = Integer.parseInt(key);
                array[index-1] = value;
            } catch (Exception e) {
                throw new RuntimeException(
                        "参数的key必须是数字，按照方法的定义从左往右为： 1 2 3 ... n", e);
            }
        }
        return array;
    }

    /**
     * 找到调用的目标方法<br/>
     *
     * @param bean
     * @param vo
     * @return
     */
    private Method getMethod(Object bean, DubboInvokeVo vo) {
        Method cached = methodCache.get(vo.getMd5());
        if(cached != null) {
            return cached;
        }
        String methodName = vo.getMethodName();

        List<Method> possibleMethods = new ArrayList<Method>(10);
        Method[] methods = bean.getClass().getMethods();
        for(Method method : methods) {
            if(method.getName().equals(methodName)) { // 首先必须保证方法名称一致
                // 如果设置了参数个数
                if(vo.getParameterNum() != -1
                        && method.getParameterTypes().length != vo.getParameterNum()) {
                    continue; // 设置了参数个数但是与当前方法不匹配，则忽略！
                }

                // 如果当前方法没有参数，但是调用设置了参数，则忽略
                // 注意：调用参数类型为空但是当前函数不为空的情况下我们不需要验证，有可能用户调用的方法没有重载版本，不需要使用类型区别！！
                if(ArrayUtils.isEmpty(method.getParameterTypes())
                        && !ArrayUtils.isEmpty(vo.getParameterTypes())) {
                    continue;
                }

                // 如果设置了参数类型
                // 这种情况下，用户明确期望调用知道类型参数的方法，必须进行参数验证
                if(!ArrayUtils.isEmpty(vo.getParameterTypes())
                        && !equals(method.getParameterTypes(), vo.getParameterTypes())) {
                    continue;
                }

                possibleMethods.add(method);
            }
        }

        if(CollectionUtils.isEmpty(possibleMethods)) {
            CoreCommonUtils.raiseBizException(BizCode.BizDataNotExists
                    , bean.getClass() + " 没有对应的方法： " + methodName);
        }

        // 如果没有重载方法，则直接方法
        if(CollectionUtils.size(possibleMethods) == 1) {
            Method method = possibleMethods.get(0);
            methodCache.put(vo.getMd5(), method);

            return method;
        }

        CoreCommonUtils.raiseBizException(BizCode.Unknown
                , bean.getClass() + " 仍然存在重载方法无法确定，请明确调用类型, methodName = " + methodName);

        // 不会运行到这里！！
        return null;
    }

    /**
     * 判断调用方法的参数与当前扫描到的参数类型是否一致
     * <pre>
     *     一致的算法是：以用户指定的为准，如果一一对应的参数一致，则方法true，否则为false；
     *
     *     注意：不要求用户输入的参数与当前方法的参数个数一致，因为在某些情况下，只需要指定前面几个参数就可以区分重载版本；
     * </pre>
     * @param parameterTypes
     * @param parameterTypesArr
     * @return
     */
    private boolean equals(Class<?>[] parameterTypes, String[] parameterTypesArr) {
        for(int i = 0 ; i < parameterTypesArr.length; ++i) {
            // 如果类型支持别名，则别名相同就OK
            String aliasName = aliasName(parameterTypes[i]);
            if(StringUtils.isNotEmpty(aliasName)
                    && aliasName.equals(parameterTypesArr[i])) {
                continue;
            }

            // 如果没有别名，则使用full qualified name进行比较
            if(!parameterTypes[i].getName().equals(parameterTypesArr[i])) {
                return false;
            }
        }

        return true;
    }

    /**
     * 支持别名，方便用户调用<br/>
     *
     * @param clzz
     * @return
     */
    private String aliasName(Class<?> clzz) {
        if(clzz.equals(String.class)) {
            return "string";
        } else if(clzz.equals(Boolean.class) || clzz.equals(boolean.class)) {
            return "boolean";
        } else if(clzz.equals(Character.class) || clzz.equals(char.class)) {
            return "char";
        } else if(clzz.equals(Byte.class) || clzz.equals(byte.class)) {
            return "byte";
        } else if(clzz.equals(Short.class) || clzz.equals(short.class)) {
            return "short";
        } else if(clzz.equals(Integer.class) || clzz.equals(int.class)) {
            return "int";
        } else if(clzz.equals(Long.class) || clzz.equals(long.class)) {
            return "long";
        } else if(clzz.equals(Float.class) || clzz.equals(float.class)) {
            return "float";
        } else if(clzz.equals(Double.class) || clzz.equals(double.class)) {
            return "double";
        } else if(clzz.equals(BigInteger.class)) {
            return "bi";
        } else if(clzz.equals(BigDecimal.class)) {
            return "bd";
        }

        return null;
    }

    /**
     * 获取需要调用的Dubbo接口Bean实例<br/>
     *
     * @param vo
     * @return
     */
    private Object getDubboBean(DubboInvokeVo vo) throws Exception {
        Object cached = beanCache.get(vo.getMd5());
        if(cached != null) {
            return cached;
        }

        // 使用Spring Id查找
        String shortName = ClassUtils.getShortName(vo.getInterfaceName());
        Object bean = null;
        try {
            bean = applicationContext.getBean(shortName);
        } catch (Exception e) {
            ;
        }

        if(bean == null) {
            try {
                ClassLoader loader = Thread.currentThread().getContextClassLoader();
                Class<?> clazz = loader.loadClass(vo.getInterfaceName());
                bean = applicationContext.getBean(clazz);
            } catch (Exception e) {
                ;
            }
        }

        if(bean == null) {
            CoreCommonUtils.raiseBizException(BizCode.BizDataNotExists
                    , "通过接口名称无法找到Spring Bean实例： " + vo.getInterfaceName());
        }

        beanCache.put(vo.getMd5(), bean);
        return bean;
    }

    // ---------------------------------- Spring IoC
    @Override
    public void setApplicationContext(
            ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
