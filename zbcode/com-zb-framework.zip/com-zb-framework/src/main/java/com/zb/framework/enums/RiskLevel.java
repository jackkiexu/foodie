package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 风险等级<br/>
 *
 */
public final class RiskLevel extends AbstractCodedEnum implements Serializable {
    public static final RiskLevel HighRisk = new RiskLevel("HIGH", "1", "高风险");

    public static final RiskLevel MiddleRisk = new RiskLevel("MIDDLE", "2", "中风险");

    public static final RiskLevel LowRisk = new RiskLevel("LOW", "3", "低风险");



    protected RiskLevel() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected RiskLevel(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return RiskLevel.class;
    }
}
