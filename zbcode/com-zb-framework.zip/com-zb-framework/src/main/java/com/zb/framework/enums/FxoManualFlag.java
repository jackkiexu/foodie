/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import java.io.Serializable;

import com.zb.framework.base.AbstractEnum;

/**
 * 
 * @author 
 * @version $Id: FxoManualFlag.java, v 0.1 2015年7月21日 上午11:52:57  Exp $
 */
public class FxoManualFlag extends AbstractEnum implements Serializable{

    /**  */
    private static final long serialVersionUID = 4878224168258526763L;
    
    public static final FxoManualFlag R=new FxoManualFlag("R","信息重置");
    
    public  static final FxoManualFlag O=new FxoManualFlag("O","线下处理");
    
    public static final FxoManualFlag S=new FxoManualFlag("S","线下处理成功");
    
    
    protected FxoManualFlag() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected FxoManualFlag(String name, String desc) {
        super(name, desc);
    }

    /** 
     * @see com.zb.framework.base.AbstractEnum#getEnumType()
     */
    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return FxoManualFlag.class;
    }

}
