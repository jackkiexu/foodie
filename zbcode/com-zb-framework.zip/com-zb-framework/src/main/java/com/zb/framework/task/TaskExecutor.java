/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.task;

import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author 
 * @version $Id: TaskExecutor.java, v 0.1 2015年4月13日 上午11:52:40  Exp $
 */
public class TaskExecutor implements Runnable{
    
    private static final Logger logger = LoggerFactory.getLogger(TaskExecutor.class);
    
    private  BlockingQueue<Task<?>>  queue;
    
    
    public TaskExecutor(BlockingQueue<Task<?>> queue){
        this.queue=queue;
    }

    /** 
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        logger.info("开始执行线程："+Thread.currentThread().getName());
        try {
            while(true){
                  Task<?> task=queue.take();
                  try{
                      task.run();
                  }catch(Exception e){
                      logger.error("任务执行异常",e);
                  }
            }
        } catch (InterruptedException e) {
            logger.error("任务消费者被中断", e);
        }
    }

}
