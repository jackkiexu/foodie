package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 来源编码<br/>
 *
 * Created by  2014/12/27.
 */
public final class SourceCode extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = -3695015770589231605L;

    public static final SourceCode INTERNET = new SourceCode("INTERNET", "I", "因特网（PC）");

    public static final SourceCode MOBILE = new SourceCode("MOBILE", "M", "移动");

    public static final SourceCode ANDROID = new SourceCode("ANDROID", "A", "移动(android)");

    public static final SourceCode IOS = new SourceCode("IOS", "O", "移动(ios)");

    public static final SourceCode H5 = new SourceCode("H5", "H", "移动(h5)");

    public static final SourceCode INSTITUTION = new SourceCode("INSTITUTION", "P", "机构（专业版）");

    public static final SourceCode BACKGROUND = new SourceCode("BACKGROUND", "B", "钱滚滚后台");

    public static final SourceCode ZOZX = new SourceCode("ZOZX", "Z", "中欧直销");

    protected SourceCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected SourceCode(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return SourceCode.class;
    }
}
