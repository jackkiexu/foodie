///**
// * 
// *
// * Copyright (c) 2014-2015 All Rights Reserved.
// */
//package com.zb.framework.scheduler.factory;
//
//import com.taobao.pamirs.schedule.strategy.TBScheduleManagerFactory;
//import org.springframework.beans.factory.InitializingBean;
//
//import java.util.Map;
//
///**
// * Created by  2015/4/21.
// */
//public class ScheduleManagerFactory extends TBScheduleManagerFactory implements InitializingBean {
//    public static final String ROOT_PATH = "/qiangungun/scheduler/kernel";
//
//    public static final String KEY_ROOT_PATH = "rootPath";
//
//    public static final String SESSION_TIMEOUT = Integer.toString(30 * 60 * 1000); // 30分钟；
//
//    public static final String KEY_SESSION_TIMEOUT = "zkSessionTimeout";
//
//    public static final String CHECK_PARENT_PATH = Boolean.TRUE.toString();
//
//    public static final String KEY_CHECK_PARENT_PATH = "isCheckParentPath";
//
//    public static final String ALIAS_CHECK_PARENT_PATH = "checkParentPath";
//
//    @Override
//    public void init() throws Exception {
//        super.init();
//    }
//
//    @Override
//    public void setZkConfig(Map<String, String> zkConfig) {
//        if(!zkConfig.containsKey(KEY_ROOT_PATH)) {
//            zkConfig.put(KEY_ROOT_PATH, ROOT_PATH);
//        }
//
//        if(!zkConfig.containsKey(KEY_SESSION_TIMEOUT)) {
//            zkConfig.put(KEY_SESSION_TIMEOUT, SESSION_TIMEOUT);
//        }
//
//        if(zkConfig.containsKey(ALIAS_CHECK_PARENT_PATH)) {
//            zkConfig.put(KEY_CHECK_PARENT_PATH, zkConfig.get(ALIAS_CHECK_PARENT_PATH));
//        }
//
//        if(!zkConfig.containsKey(KEY_CHECK_PARENT_PATH)) {
//            zkConfig.put(KEY_CHECK_PARENT_PATH, CHECK_PARENT_PATH);
//        }
//
//        super.setZkConfig(zkConfig);
//    }
//
//    @Override
//    public void afterPropertiesSet() throws Exception {
//        super.init();
//    }
//}
