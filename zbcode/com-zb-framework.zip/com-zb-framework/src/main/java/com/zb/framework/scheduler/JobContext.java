/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.scheduler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 任务上下文<br/>
 *
 * Created by  2015/4/21.
 */
public class JobContext {
    /**
     * 执行环境，例如开发环境、测试环境、线上环境等等<br/>
     *
     */
    private String env = null;

    /**
     * 每次获取数据的总条目数量<br/>
     *
     */
    private Integer pageSize = null;

    /**
     * 任务自定义参数<br/>
     *
     */
    private Map<String, Object> parameters = new HashMap<>(4, 1F);

    /**
     * 整个集群中运行的任务条目总数量，大于等于当前任务条目的数量<br/>
     *
     */
    private Integer totalTaskItems = null;

    /**
     * 当前允许任务所处理的任务条目集合<br/>
     *
     */
    private List<TaskItem> items = new ArrayList<>(4);

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }

    public List<TaskItem> getItems() {
        return items;
    }

    public void setItems(List<TaskItem> items) {
        this.items = items;
    }

    public Integer getTotalTaskItems() {
        return totalTaskItems;
    }

    public void setTotalTaskItems(Integer totalTaskItems) {
        this.totalTaskItems = totalTaskItems;
    }

    @Override
    public String toString() {
        return "JobContext{" +
                "env='" + env + '\'' +
                ", pageSize=" + pageSize +
                ", parameters=" + parameters +
                ", totalTaskItems=" + totalTaskItems +
                ", items=" + items +
                '}';
    }
}
