/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 分红方式<br/>
 *
 * Created by  2015/5/4.
 */
public class MelonType extends AbstractEnum implements Serializable {
    public static final MelonType Cash = new MelonType("1", "现金分红");

    public static final MelonType Reinvestment = new MelonType("0", "红利再投");

    protected MelonType() {
        super();
    }

    protected MelonType(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return MelonType.class;
    }
}
