package com.zb.framework.util;

public class Main {
    static boolean ch;
 public static void main(String[] args) {
     System.out.println(ch);
 }
}
