package com.zb.framework.framework.flow.template;

import com.zb.framework.base.AbstractRequest;
import com.zb.framework.base.AbstractResponse;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.OutboundInvoker;
import com.zb.framework.framework.flow.Pipeline;
import com.zb.framework.framework.flow.PipelineTemplate;
import com.zb.framework.framework.flow.context.AbstractContext;
import com.zb.framework.framework.flow.converter.AbstractConverter;
import com.zb.framework.framework.flow.pipeline.DefaultPipeline;
import com.zb.framework.framework.flow.util.FlowContainer;
import com.zb.framework.framework.flow.util.FlowHandlerContainer;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;

import java.util.List;

/**
 * pipe line模板基类<br/>
 *
 * Created by  2014/12/12.
 */
public abstract class AbstractPipelineTemplate<TReq extends AbstractRequest> implements PipelineTemplate<TReq> {
    @Override
    public final OutboundInvoker create(TReq request) {
        // 实例化转换器
        AbstractConverter<? extends AbstractContext, TReq
                , ? extends AbstractResponse, ? extends AbstractFlowVo> converter = createConverter();

        // 转换调用方cans
        AbstractContext context = converter.toContext(request);

        // 实例化pipe line容器
        Pipeline pipeline = createPipeline();
        pipeline.setConverter(converter);
        pipeline.setContext(context);

        // 填充handler
        FlowContainer<Handler> container = createContainer();
        fillHandlers(container);
        List<Handler> handlers = container.toList();
        pipeline.append(handlers.toArray(new Handler[handlers.size()]));

        return pipeline;
    }

    /**
     * 填充当前pipe line的处理器列表<br/>
     *
     * @param container
     */
    protected abstract void fillHandlers(FlowContainer<Handler> container);

    /**
     * 实例化pipe line类型转换器<br/>
     *
     * @return
     */
    protected abstract
    AbstractConverter<? extends AbstractContext, TReq
            , ? extends AbstractResponse, ? extends AbstractFlowVo> createConverter();

    protected Pipeline createPipeline() {
        return new DefaultPipeline();
    }

    /**
     * 返回容纳处理器的容器实例<br/>
     *
     * @return
     */
    protected FlowContainer<Handler> createContainer() {
        return new FlowHandlerContainer(5);
    }
}
