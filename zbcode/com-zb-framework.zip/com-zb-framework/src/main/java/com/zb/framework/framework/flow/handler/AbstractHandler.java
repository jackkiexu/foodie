package com.zb.framework.framework.flow.handler;

import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.Listener;
import com.zb.framework.framework.flow.context.AbstractContext;
import com.zb.framework.framework.flow.enums.PhaseCode;
import com.zb.framework.framework.flow.util.FlowContainer;
import com.zb.framework.framework.flow.util.FlowListenerContainer;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;

import java.util.List;

/**
 * Created by  2014/12/12.
 */
public abstract class AbstractHandler implements Handler {

    /**
     * handler可以定义一个自己的名称<br/>
     *
     */
    private String name = null;

    @Override
    public boolean isAsync() {
        return false;
    }

    @Override
    public boolean isSkippable(Context context) {
        // 默认情况下在异步执行环境下才需要跳过；
        return context.isAsyncEnvironment()
                // 仅仅跳过start phase前面的节点
                && !context.isBehindStartingPhase()
                && context.getStarting() != null
                && context.getStarting() != getPhaseCode();
    }

    @Override
    public boolean handle(Context context) {
        // 如果当前节点可以跳过，则进行数据修复并跳过执行当前节点业务；
        boolean result = true;
        if(isSkippable(context)) {
            recover(context);
        } else {
            // 执行具体业务
            result = doHandle(context, context.getCallerParam());
        }

        // 如果当前节点是starting phase节点，则后面的节点不需要跳过
        if(context.isAsyncEnvironment() && context.getStarting() != null
                && context.getStarting() == getPhaseCode()) {
            ((AbstractContext)context).setBehindStartingPhase(true);
        }

        return result;
    }

    /**
     * 执行具体的业务<br/>
     *
     * @param context
     * @return
     */
    protected abstract boolean doHandle(final Context context,final AbstractFlowVo callerParam);

    @Override
    public final void recover(Context context) {
        // 公共逻辑

        // 具体数据恢复逻辑
        doRecover(context);
    }

    /**
     * 进行实际的修复工作<br/>
     *
     * @param context
     */
    protected void doRecover(Context context) {
        ; // nothing.
    }

    @Override
    public final List<Listener> getListeners() {
        FlowContainer<Listener> container = new FlowListenerContainer(2);

        // 填充监听器
        fillListeners(container);

        return container.toList();
    }

    /**
     * 填充当前节点需要的监听器<br/>
     *
     * @param container
     */
    protected void fillListeners(FlowContainer<Listener> container) {
        ; // 默认情况下没有监听器
    }

    @Override
    public abstract PhaseCode getPhaseCode();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
