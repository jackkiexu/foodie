/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.lock.vo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.Serializable;

/**
 * curator 客户端配置信息
 * Created by  on 2015/8/5.
 */
public class CuratorConfig implements Serializable{
    private static final long serialVersionUID = 8201032234170107707L;
    /**
     * zk服务器列表<br/>
     *
     */
    @Value("#{systemProperties['common.lock.server.zk.connection']}")
    private String connection = null;

    /**
     * zk 连接超时时间<br/>
     *
     */
    @Value("#{systemProperties['common.lock.server.zk.connectTimeout']}")
    private Integer connectTimeout = null;

    /**
     * zk session超时时间<br/>
     *
     */
    @Value("#{systemProperties['common.lock.server.zk.sessionTimeout']}")
    private Integer sessionTimeout = null;

    /**
     * 用户名<br/>
     *
     */
    @Value("#{systemProperties['common.lock.server.zk.userName']}")
    private String userName = null;

    /**
     * 密码<br/>
     *
     */
    @Value("#{systemProperties['common.lock.server.zk.password']}")
    private String password = null;

    /**
     * 客户端命名空间
     */
    @Value("#{systemProperties['common.lock.server.zk.namespace']}")
    private String namespace = null;


    public String getConnection() {
        return connection;
    }

    public void setConnection(String connection) {
        this.connection = connection;
    }

    public Integer getSessionTimeout() {
        return sessionTimeout;
    }

    public void setSessionTimeout(Integer sessionTimeout) {
        this.sessionTimeout = sessionTimeout;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getConnectTimeout() {
        return connectTimeout;
    }

    public void setConnectTimeout(Integer connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    @Override
    public String toString() {
        return "CuratorConfig{" +
                "connection='" + connection + '\'' +
                ", connectTimeout=" + connectTimeout +
                ", sessionTimeout=" + sessionTimeout +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", namespace='" + namespace + '\'' +
                '}';
    }
}
