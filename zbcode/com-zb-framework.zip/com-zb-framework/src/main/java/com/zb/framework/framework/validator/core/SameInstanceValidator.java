package com.zb.framework.framework.validator.core;

import com.zb.framework.framework.validator.Validator;
import com.zb.framework.framework.validator.base.AbstractValidator;

/**
 * ==验证器<br/>
 *
 * Created by  2014/12/15.
 */
public class SameInstanceValidator extends AbstractValidator implements Validator {
    public SameInstanceValidator(Object referObject) {
        super(referObject);
    }

    @Override
    public boolean doValidate(Object target) {
        return getReferObject() == target;
    }
}
