package com.zb.framework.framework.flow.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 工作流附加参数属性值<br/>
 *
 * Created by  2014/12/11.
 */
public class FlowAttribute extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = -9103383338428831277L;

    public static final FlowAttribute IS_ASYNC
            = new FlowAttribute("FLOW_IS_ASYNC", "是否为异步执行环境");

    public static final FlowAttribute STARTING_PHASE
            = new FlowAttribute("STARTING_PHASE", "执行的起始节点");

    protected FlowAttribute() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    public FlowAttribute(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected final Class<? extends AbstractEnum> getEnumType() {
        return FlowAttribute.class;
    }
}
