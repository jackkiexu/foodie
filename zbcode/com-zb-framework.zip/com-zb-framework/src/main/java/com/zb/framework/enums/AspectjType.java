package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 拦截器type枚举<br/>
 *
 */
public final class AspectjType extends AbstractCodedEnum implements Serializable {
    public static final AspectjType DAL = new AspectjType("DAL", "DAL", "数据库");

    public static final AspectjType REMOTE = new AspectjType("REMOTE", "REMOTE", "远程服务");

    public static final AspectjType SERVICE = new AspectjType("SERVICE", "SERVICE", "service服务");




    protected AspectjType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected AspectjType(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return AspectjType.class;
    }
}
