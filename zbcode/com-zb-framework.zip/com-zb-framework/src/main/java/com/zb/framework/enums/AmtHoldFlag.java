/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import java.io.Serializable;

import com.zb.framework.base.AbstractEnum;

/**
 * 资金冻结解冻标识
 * @author 
 * @version $Id: AmtHoldFlag.java, v 0.1 2015年1月20日 下午3:14:12  Exp $
 */
public final class AmtHoldFlag extends AbstractEnum implements Serializable{

    
    /**  */
    private static final long serialVersionUID = -9008028747336495526L;
    
    public static final AmtHoldFlag HOLD=new AmtHoldFlag("1","冻结标识");
    public static final AmtHoldFlag UNHOLD=new AmtHoldFlag("2","解冻标识");

    protected AmtHoldFlag() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected AmtHoldFlag(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return AmtHoldFlag.class;
    }
}
