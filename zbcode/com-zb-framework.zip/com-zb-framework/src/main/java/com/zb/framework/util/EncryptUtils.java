/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.lang3.StringUtils;

/**
 * 通用加解密码工具
 * @author 
 * @version $Id: EncryptUtils.java, v 0.1 2015年1月28日 下午2:05:38  Exp $
 */
public final class EncryptUtils {

    /**
     * SHA（Secure Hash Algorithm，安全散列算法）
     * 
     * @param salt
     * @param plainText
     * @return
     */
    public static String genEncryptWithSHA512(String plainText,String salt) {

        StringBuilder sb = new StringBuilder();
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            md.update(salt.getBytes());
            byte[] bytes = md.digest(plainText.getBytes());
            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
        } catch (Exception e) {

        }

        return sb.toString();
    }
    
    /**
     * 对字符串进行MD5进行加密处理
     * @param msg 待加密的字符串
     * @return 加密后字符串
     */
    public static String encryptMD5(String msg){
        return encrypt(msg, null);
    }
    
    /**
     * 盐值的原理非常简单，就是先把密码和盐值指定的内容合并在一起，再使用md5对合并后的内容进行演算，
     * 这样一来，就算密码是一个很常见的字符串，再加上用户名，最后算出来的md5值就没那么容易猜出来了。
     * 因为攻击者不知道盐值的值，也很难反算出密码原文。
     * @param msg
     * @return
     */
    public static String encryptMD5WithSalt(String msg,String salt) {
        return encrypt(msg, salt);
    }

    /**
     * 基本加密处理
     * @param msg
     * @param typt
     * @return
     */
    private static String encrypt(String msg, String type) {
        MessageDigest md;
        StringBuilder password = new StringBuilder();

        try {
            md = MessageDigest.getInstance("MD5");

            if (StringUtils.isNoneBlank(type)) {
                md.update(type.getBytes());
            } 
            md.update(msg.getBytes());
            byte[] bytes = md.digest();
            for (int i = 0; i < bytes.length; i++) {
                String param = Integer.toString((bytes[i] & 0xff) + 0x100, 16);
                password.append(param.substring(1));
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return password.toString();
    }
    
    
}
