package com.zb.framework.framework.flow.converter;

import com.zb.framework.base.AbstractRequest;
import com.zb.framework.base.AbstractResponse;
import com.zb.framework.enums.BizCode;
import com.zb.framework.framework.flow.Converter;
import com.zb.framework.framework.flow.context.AbstractContext;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;
import com.zb.framework.util.CoreCommonUtils;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * 转换器基类<br/>
 *
 * Created by  2014/12/11.
 */
public abstract class AbstractConverter<TContext extends AbstractContext, TIn extends AbstractRequest
        , TOut extends AbstractResponse, TFlowVo extends AbstractFlowVo> implements Converter<TContext, TIn, TOut> {
    private Class<? extends AbstractContext> contextClass = null;

    private Class<? extends AbstractRequest> requestClass = null;

    private Class<? extends AbstractResponse> responseClass = null;

    private Class<? extends AbstractFlowVo> flowVoClass = null;

    public AbstractConverter() {
        // 解析泛型参数类型， 简化实例构造；
        ParameterizedType type = (ParameterizedType) this.getClass().getGenericSuperclass();
        Type[] argumentTypes = type.getActualTypeArguments();

        contextClass = (Class<? extends AbstractContext>)argumentTypes[0];
        requestClass = (Class<? extends AbstractRequest>)argumentTypes[1];
        responseClass = (Class<? extends AbstractResponse>)argumentTypes[2];
        flowVoClass = (Class<? extends AbstractFlowVo>)argumentTypes[3];
    }

    @Override
    public TContext toContext(TIn request) {
        final TContext context = newFlowContext();
        final TFlowVo vo = newFlowVo();

        // 设置上下文；
        context.setCallerParam(vo);

        // 复制扩展参数
        vo.copy(request.extFields());

        // 进行参数转换
        doConvert(context, request, vo);

        return context;
    }

    /**
     * 将服务调用参数转换为内部pipe line入口参数<br/>
     *
     * @param context
     * @param fromVo
     * @param toVo
     */
    protected abstract void doConvert(TContext context
            , TIn fromVo, TFlowVo toVo);

    /**
     * 返回当前上下文实例<br/>
     *
     * @return
     */
    protected TContext newFlowContext() {
        try {
            return (TContext)contextClass.newInstance();
        } catch (Exception e) {
            CoreCommonUtils.raiseBizException(BizCode.ClassOrInstanceError, "创建实例失败", e);
        }

        return null;
    }

    /**
     * 返回当前上下文入口参数类型实例<br/>
     *
     * @return
     */
    protected TFlowVo newFlowVo() {
        try {
            return (TFlowVo)flowVoClass.newInstance();
        } catch (Exception e) {
            CoreCommonUtils.raiseBizException(BizCode.ClassOrInstanceError, "创建实例失败", e);
        }

        return null;
    }

    @Override
    public TOut toResponse(AbstractContext context) {
        TOut response = newResponseVo();

        // 转换返回值
        convert((TContext)context, (TFlowVo)context.getCallerParam(), response);

        return response;
    }

    /**
     * 将pipe line入口参数转换为服务调用返回值<br/>
     *
     * @param context
     * @param callerParam
     * @param response
     */
    protected void convert(TContext context, TFlowVo callerParam, TOut response) {
        response.setCode(BizCode.Success);
        response.setMessage(BizCode.Success.desc());

        doConvert(context, callerParam, response);

        // 复制附加属性
        response.copy(context.getResponseAttributes().attributes());
    }

    /**
     * 将pipe line入口参数转换为服务调用返回值<br/>
     *
     * @param context
     * @param fromVo
     * @param toVo
     */
    protected abstract void doConvert(TContext context
            , TFlowVo fromVo, TOut toVo);

    /**
     * 返回一个服务调用返回值类型实例<br/>
     *
     * @return
     */
    protected TOut newResponseVo() {
        try {
            return (TOut)responseClass.newInstance();
        } catch (Exception e) {
            CoreCommonUtils.raiseBizException(BizCode.ClassOrInstanceError, "创建实例失败", e);
        }

        return null;
    }
}
