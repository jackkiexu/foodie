package com.zb.framework.enums.product;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 业务控制类型枚举<br/>
 *
 */
public class ProductSaveType extends AbstractCodedEnum implements Serializable {

    public static final ProductSaveType baseSave = new ProductSaveType("baseSave","baseSave", "基础产品");
    public static final ProductSaveType transLimitSave = new ProductSaveType("transLimitSave","transLimitSave", "交易限额");
    public static final ProductSaveType marketingSave = new ProductSaveType("marketingSave","marketingSave", "营销信息");
    public static final ProductSaveType otherSave = new ProductSaveType("otherSave","otherSave", "其他信息");

    public static final ProductSaveType deleteSave = new ProductSaveType("deleteSave","deleteSave", "删除产品");

    public static final ProductSaveType cancelProductCheck = new ProductSaveType("cancelProductCheck","cancelProductCheck", "产品复核退回");
    public static final ProductSaveType okProductCheck = new ProductSaveType("okProductCheck","okProductCheck", "产品复核通过");

    public static final ProductSaveType addBusiControl = new ProductSaveType("addBusiControl","addBusiControl", "添加产品业务控制");
    public static final ProductSaveType updateBusiControl = new ProductSaveType("updateBusiControl","updateBusiControl", "更新产品业务控制");
    public static final ProductSaveType removeBusiControl = new ProductSaveType("removeBusiControl","removeBusiControl", "删除产品业务控制");

    protected ProductSaveType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    public ProductSaveType(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return ProductSaveType.class;
    }
}
