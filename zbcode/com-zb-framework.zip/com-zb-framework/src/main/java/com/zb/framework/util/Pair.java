package com.zb.framework.util;

/**
 * 可以存储两个值得Tuple；<br/>
 *
 * Created by  14-1-21.
 */
public class Pair<V1, V2> {
    private V1 value1 = null;

    private V2 value2 = null;

    public Pair() {
        ;
    }

    public Pair(V1 value1, V2 value2) {
        setValue1(value1);
        setValue2(value2);
    }

    public V1 getValue1() {
        return value1;
    }

    public void setValue1(V1 value1) {
        this.value1 = value1;
    }

    public V2 getValue2() {
        return value2;
    }

    public void setValue2(V2 value2) {
        this.value2 = value2;
    }
}
