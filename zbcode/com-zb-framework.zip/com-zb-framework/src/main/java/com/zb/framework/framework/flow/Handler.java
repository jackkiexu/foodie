package com.zb.framework.framework.flow;

import com.zb.framework.framework.flow.enums.PhaseCode;

import java.util.List;

/**
 * Pipe line中独立的工作节点<br/>
 *
 * <pre>
 *     Note：异步执行环境（Async Environment），用于支持pipe line的多次执行，一般情况下是外部异步返回要求pipeline再次执行，
 *     例如银行异步返回、TA异步返回等等，是与同步执行环境（Sync Environment）区别的，同步调用环境指的是外部服务第一次调用pipe line业务。
 *
 *     Note：异步执行（isAsync），表示当前节点执行的方式，是同步执行还是异步执行，与执行环境无关。
 * </pre>
 *
 * Created by  2014/12/10.
 */
public interface Handler {
    /**
     * 是否可以异步处理当前业务<br/>
     *
     * @return
     */
    boolean isAsync();

    /**
     * 是否可以跳过<br/>
     *
     * <pre>
     *     Note： 一般是在异步执行环境（Async Environment）的情况下，同步执行的节点可以跳过，但是跳过的节点需要将本节点创建的结果恢复，
     *     这样就可以将同步和异步执行使用一套pipe line.
     * </pre>
     *
     * @param context
     * @return
     */
    boolean isSkippable(Context context);

    /**
     * 执行业务逻辑<br/>
     *
     * @param context
     * @return true表示继续执行后续的业务逻辑， false表示停止执行后续逻辑
     */
    boolean handle(Context context);

    /**
     * 恢复当前节点执行结果，主要用于支持异步执行环境（Async Environment），一般是在跳过（{@link #isSkippable()}）的情况下需要当前节点进行信息修复<br/>
     *
     * @param context
     */
    void recover(Context context);

    /**
     * 获取处理器上的所有监听器<br/>
     *
     * @return
     */
    List<Listener> getListeners();

    /**
     * 当前节点所属的阶段<br/>
     *
     * @return
     */
    PhaseCode getPhaseCode();
}
