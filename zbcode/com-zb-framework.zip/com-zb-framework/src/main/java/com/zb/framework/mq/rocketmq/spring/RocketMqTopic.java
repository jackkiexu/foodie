package com.zb.framework.mq.rocketmq.spring;

import com.zb.framework.enums.BizCode;
import com.zb.framework.util.CoreCommonUtils;
import org.springframework.beans.factory.InitializingBean;

/**
 * RocketMQ消息配置<br/>
 *
 * Created by  2015/1/14.
 */
public class RocketMqTopic implements InitializingBean {
    /**
     * 订阅消息逻辑组<br/>
     *
     */
    private String group = null;

    /**
     * 订阅消息名称<br/>
     *
     */
    private String topic = null;

    /**
     * 过滤标签集合<br/>
     */
    private String tags = null;

    /**
     * 消费线程池最小线程数<br/>
     *
     */
    private int consumeThreadMin = 10;

    /**
     * 消费线程池最大线程数<br/>
     *
     */
    private int consumeThreadMax = 50;

    /**
     * 每次Listener批量消费的消息数量，默认为1<br/>
     *
     */
    private int consumeMessageBatchSize = 1;

    @Override
    public void afterPropertiesSet() throws Exception {
        if(tags != null && tags.isEmpty()) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotEmpty, "tags的内容不能为空字符串");
        }

        if(topic == null || topic.isEmpty()) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotEmpty, "topic不能为空");
        }

        if(group == null || group.isEmpty()) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotEmpty, "group不能为空");
        }
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public int getConsumeThreadMin() {
        return consumeThreadMin;
    }

    public void setConsumeThreadMin(int consumeThreadMin) {
        this.consumeThreadMin = consumeThreadMin;
    }

    public int getConsumeThreadMax() {
        return consumeThreadMax;
    }

    public void setConsumeThreadMax(int consumeThreadMax) {
        this.consumeThreadMax = consumeThreadMax;
    }

    public int getConsumeMessageBatchSize() {
        return consumeMessageBatchSize;
    }

    public void setConsumeMessageBatchSize(int consumeMessageBatchSize) {
        this.consumeMessageBatchSize = consumeMessageBatchSize;
    }

    @Override
    public String toString() {
        return "RocketMqTopic{" +
                "group='" + group + '\'' +
                ", topic='" + topic + '\'' +
                ", tags='" + tags + '\'' +
                ", consumeThreadMin=" + consumeThreadMin +
                ", consumeThreadMax=" + consumeThreadMax +
                ", consumeMessageBatchSize=" + consumeMessageBatchSize +
                '}';
    }

    @Override
    public int hashCode() {
        int hashCode = 31 * this.getGroup().hashCode() + this.getTopic().hashCode();
        if(tags != null) {
            hashCode = 31 * hashCode + tags.hashCode();
        }

        return hashCode;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj == null || !(obj instanceof RocketMqTopic)) {
            return false;
        }

        RocketMqTopic other = (RocketMqTopic) obj;

        return this.getGroup().equals(other.getGroup())
                && this.getTopic().equals(other.getTopic())
                && (this.getTags() == null && other.getTags() == null
                        || this.getTags().equals(other.getTags()));
    }
}
