package com.zb.framework.enums.biz;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

import java.io.Serializable;

/**
 * 交易核心业务码<br/>
 *
 * Created by  2015/1/29.
 */
public class TransBizCode extends BizCode implements Serializable {
    private static final long serialVersionUID = -7220477233050361766L;

    // 支付相关
    public static final TransBizCode PayFail
            = new TransBizCode("PayFail", ServiceCode.TransCore, "001", "Paycore支付失败");

    public static final TransBizCode PayPending
            = new TransBizCode("PayPending", ServiceCode.TransCore, "002", "Paycore支付中");

    public static final TransBizCode PayException
            = new TransBizCode("PayException", ServiceCode.TransCore, "003", "Paycore支付异常");

    // 商户相关
    public static final TransBizCode TaFail
            = new TransBizCode("TaFail", ServiceCode.TransCore, "004", "Merchant支付失败");

    public static final TransBizCode TaPending
            = new TransBizCode("TaPending", ServiceCode.TransCore, "005", "Merchant支付中");

    public static final TransBizCode TaException
            = new TransBizCode("TaException", ServiceCode.TransCore, "006", "Merchant支付异常");

    // 撤单
    public static final TransBizCode DupCancel
            = new TransBizCode("DupCancel", ServiceCode.TransCore, "007", "重复撤单");

    // 分红设置
    public static final TransBizCode DupMelonSet
            = new TransBizCode("DupMelonSet", ServiceCode.TransCore, "010", "重复设置分红方式");

    // 转换限制
    public static final TransBizCode ConvertLimited
            = new TransBizCode("ConvertLimited", ServiceCode.TransCore, "012", "转换限制");

    // 解绑银行卡
    public static final TransBizCode UnbindAssetG0
            = new TransBizCode("UnbindAssetG0", ServiceCode.TransCore, "008", "资产不为0");

    public static final TransBizCode UnbindTransitG0
            = new TransBizCode("UnbindTransitG0", ServiceCode.TransCore, "009", "在途资产不为0");

    public static final TransBizCode UnbindRefundG0
            = new TransBizCode("UnbindRefundG0", ServiceCode.TransCore, "011", "退款金额不为0");

    public static final TransBizCode UnbindHasAip
            = new TransBizCode("UnbindHasAip", ServiceCode.TransCore, "013", "存在定投计划");

    // 其他
    public static final TransBizCode OperationPending
            = new TransBizCode("OperationPending", ServiceCode.TransCore, "901", "等待后续操作");

    public static final TransBizCode BizDataError
            = new TransBizCode("BizDataError", ServiceCode.TransCore, "902", "业务数据错误");

    protected TransBizCode() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    public TransBizCode(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }
}
