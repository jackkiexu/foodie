/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums.product;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 产品分红记录分红方式
 */
public class ProductMelonType extends AbstractEnum implements Serializable {
    public static final ProductMelonType Cash = new ProductMelonType("1", "现金分红");

    protected ProductMelonType() {
        super();
    }

    protected ProductMelonType(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return ProductMelonType.class;
    }
}
