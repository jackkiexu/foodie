package com.zb.framework.enums.product;


import java.io.Serializable;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

/**
 * 业务控制类型枚举<br/>
 *
 */
public class InnerControlBusiDeatil extends AbstractCodedEnum implements Serializable {

    public static final InnerControlBusiDeatil OpenRegularly = new InnerControlBusiDeatil("0101","0101", "定期开放");
    public static final InnerControlBusiDeatil OpenDaily = new InnerControlBusiDeatil("0102","0102", "每日开放");
    public static final InnerControlBusiDeatil PurchaseLimit = new InnerControlBusiDeatil("0201","0201", "申购");
    public static final InnerControlBusiDeatil InvestmentLimit = new InnerControlBusiDeatil("0202","0202", "定投");
    public static final InnerControlBusiDeatil SwitchLimit = new InnerControlBusiDeatil("0203","0203", "转入");
    public static final InnerControlBusiDeatil PausePurchase = new InnerControlBusiDeatil("0301","0301", "暂停申购");
    public static final InnerControlBusiDeatil PauseRedeem = new InnerControlBusiDeatil("0302","0302", "暂停赎回");
    public static final InnerControlBusiDeatil PauseConvert = new InnerControlBusiDeatil("0303","0303", "暂停转换入");
    public static final InnerControlBusiDeatil PauseFixed = new InnerControlBusiDeatil("0304","0304", "暂停定投");

    public static final InnerControlBusiDeatil PauseFastRedeem = new InnerControlBusiDeatil("0305","0305", "暂停快取");


    //前端特殊组合类型
    public static final InnerControlBusiDeatil PauseBuy = new InnerControlBusiDeatil("0909","0909", "暂停购买");


    protected InnerControlBusiDeatil() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    public InnerControlBusiDeatil(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return InnerControlBusiDeatil.class;
    }
}
