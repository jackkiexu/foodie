/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.spring.flow.support;

import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.Listener;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.mvel2.MVEL;
import org.mvel2.ParserContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContextAware;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by  2015/4/24.
 */
public class SpringHoldFragment extends SpringHoldBaseHandler  implements Handler, ApplicationContextAware, InitializingBean {
    private static final Logger LOG = LoggerFactory.getLogger(SpringHoldFragment.class);

    /**
     * 被代理的处理器<br/>
     *
     */
    private List<Handler> holdHandlers = null;

    /**
     * 表达式<br/>
     *
     */
    private String booleanExpression = null;

    private Serializable compiledExpr = null;

    public List<Handler> getHoldHandlers() {
        return holdHandlers;
    }

    public void setHoldHandlers(List<Handler> holdHandlers) {
        this.holdHandlers = holdHandlers;
    }

    public String getBooleanExpression() {
        return booleanExpression;
    }

    public void setBooleanExpression(String booleanExpression) {
        this.booleanExpression = booleanExpression;
    }

    @Override
    protected boolean doHandle(final Context context, final AbstractFlowVo callerParam) {
        final Object result = compiledExpr == null ? true : MVEL.executeExpression(compiledExpr, newMap(context));
        if(result != null && (result instanceof Boolean) && !(Boolean)result) {
            LOG.info("fragment执行判断的表达式为false，跳过当前fragment节点"
                    + (StringUtils.isNotEmpty(getName()) ? "(" + getName() + ")" : StringUtils.EMPTY));

            return true; // 继续后续节点，但是当前节点跳过；
        }

        if(!(result instanceof Boolean)) {
            LOG.warn((StringUtils.isNotEmpty(getName()) ? "(" + getName() + ")" : StringUtils.EMPTY)
                    + "fragment表达式执行结果不是boolean： " + result.getClass());
        }

        if(!getEnableTransaction()) {
            return doHandlers(context, callerParam);
        } else {
            return getTransactionTemplate().execute(new TransactionCallback<Boolean>() {
                @Override
                public Boolean doInTransaction(TransactionStatus status) {
                    return doHandlers(context, callerParam);
                }
            });
        }
    }

    private Map newMap(Context context) {
        Map params = new HashMap(2, 1F);
        params.put("ctx", context);

        return params;
    }

    private boolean doHandlers(Context context, AbstractFlowVo callerParam) {
        for(Handler handler : holdHandlers) {
            final boolean result = handler.handle(context);
            if(!result) {
                return result;
            }
        }

        return true;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        super.afterPropertiesSet();

        if(booleanExpression != null) {
            // 编译mvel；
            final ParserContext ctx = new ParserContext();
            ctx.addVariable("ctx", Context.class);
            compiledExpr = MVEL.compileExpression(booleanExpression, ctx);
        }
    }

    @Override
    protected List<Listener> getProxyListeners() {
        List<Listener> result = new ArrayList<>(10);
        for(Handler handler : holdHandlers) {
            final List<Listener> list = handler.getListeners();
            if(CollectionUtils.isNotEmpty(list)) {
                result.addAll(list);
            }
        }

        return result;
    }
}
