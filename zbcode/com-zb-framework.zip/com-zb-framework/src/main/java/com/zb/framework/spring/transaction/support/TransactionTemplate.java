/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.spring.transaction.support;

import com.zb.framework.exception.NoRollbackException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.transaction.interceptor.NoRollbackRuleAttribute;
import org.springframework.transaction.interceptor.RollbackRuleAttribute;
import org.springframework.transaction.support.CallbackPreferringPlatformTransactionManager;
import org.springframework.transaction.support.TransactionCallback;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 支持异常特殊处理的事务模板<br/>
 *
 * Created by  2015/6/2.
 */
public class TransactionTemplate extends org.springframework.transaction.support.TransactionTemplate {
    private static final List<String> EmptyStringList = Collections.emptyList();

    private static final List<Class<? extends Throwable>> EmptyClassList = Collections.emptyList();
    /**
     * 进行回滚的异常类型<br/>
     *
     */
    private List<Class<? extends Throwable>> rollbackFor = null;

    /**
     * 进行回滚的异常类型名称（Qualified-class name）<br/>
     *
     */
    private List<String> rollbackForClassName = null;

    /**
     * 不需要回滚的异常类型<br/>
     *
     */
    private List<Class<? extends Throwable>> noRollbackFor = null;

    /**
     * 不需要回滚的异常类型名称（Qualified-class name）<br/>
     *
     */
    private List<String> noRollbackForClassName = null;

    /**
     * 回滚规则集合<br/>
     *
     */
    private ArrayList<RollbackRuleAttribute> rollBackRules = new ArrayList<RollbackRuleAttribute>();

    public TransactionTemplate() {
        super();
    }

    public TransactionTemplate(PlatformTransactionManager transactionManager) {
        super(transactionManager);
    }

    public TransactionTemplate(PlatformTransactionManager transactionManager, TransactionDefinition transactionDefinition) {
        super(transactionManager, transactionDefinition);
    }

    public List<Class<? extends Throwable>> getRollbackFor() {
        return rollbackFor == null ? EmptyClassList : rollbackFor;
    }

    public void setRollbackFor(List<Class<? extends Throwable>> rollbackFor) {
        this.rollbackFor = rollbackFor;
    }

    public List<String> getRollbackForClassName() {
        return rollbackForClassName == null ? EmptyStringList : rollbackForClassName;
    }

    public void setRollbackForClassName(List<String> rollbackForClassName) {
        this.rollbackForClassName = rollbackForClassName;
    }

    public List<Class<? extends Throwable>> getNoRollbackFor() {
        return noRollbackFor == null ? EmptyClassList : noRollbackFor;
    }

    public void setNoRollbackFor(List<Class<? extends Throwable>> noRollbackFor) {
        this.noRollbackFor = noRollbackFor;
    }

    public List<String> getNoRollbackForClassName() {
        return noRollbackForClassName == null ? EmptyStringList : noRollbackForClassName;
    }

    public void setNoRollbackForClassName(List<String> noRollbackForClassName) {
        this.noRollbackForClassName = noRollbackForClassName;
    }

    public ArrayList<RollbackRuleAttribute> getRollBackRules() {
        return rollBackRules;
    }

    public void setRollBackRules(ArrayList<RollbackRuleAttribute> rollBackRules) {
        this.rollBackRules = rollBackRules;
    }

    @Override
    public <T> T execute(TransactionCallback<T> action) throws TransactionException {
        if (getTransactionManager() instanceof CallbackPreferringPlatformTransactionManager) {
            return executeInPreferringManager(action);
        } else {
            TransactionStatus status = getTransactionManager().getTransaction(this);
            T result = null;
            try {
                result = action.doInTransaction(status);
            } catch (Throwable ex) {
                // target invocation exception
                completeTransactionAfterThrowing(status, ex);
                throw ex;
            }

            getTransactionManager().commit(status);
            return result;
        }
    }

    private <T> T executeInPreferringManager(final TransactionCallback<T> action) {
        // It's a CallbackPreferringPlatformTransactionManager: pass a TransactionCallback in.
        try {
            Object result = ((CallbackPreferringPlatformTransactionManager) getTransactionManager()).execute(this,
                    new TransactionCallback<Object>() {
                        public Object doInTransaction(TransactionStatus status) {
                            try {
                                return action.doInTransaction(status);
                            } catch (Throwable ex) {
                                if (rollbackOn(ex)) {
                                    // A RuntimeException: will lead to a rollback.
                                    if (ex instanceof RuntimeException) {
                                        throw (RuntimeException) ex;
                                    } else {
                                        throw new ThrowableHolderException(ex);
                                    }
                                } else {
                                    // A normal return value: will lead to a commit.
                                    return new ThrowableHolder(ex);
                                }
                            }
                        }
                    });

            // Check result: It might indicate a Throwable to rethrow.
            if (result instanceof ThrowableHolder) {
                throw new RuntimeException(((ThrowableHolder) result).getThrowable());
            } else {
                return (T) result;
            }
        } catch (ThrowableHolderException ex) {
            throw new RuntimeException(ex.getCause());
        }
    }

    @Override
    public void afterPropertiesSet() {
        super.afterPropertiesSet();

        final List<String> $rollbackForClassName = getRollbackForClassName();
        final List<Class<? extends Throwable>> $rollbackFor = getRollbackFor();

        final List<Class<? extends Throwable>> $noRollbackFor = getNoRollbackFor();
        final List<String> $noRollbackForClassName = getNoRollbackForClassName();

        int len = $rollbackForClassName.size() + $rollbackFor.size()
                + $noRollbackFor.size() + $noRollbackForClassName.size() + 1/*默认异常*/;
        ArrayList<RollbackRuleAttribute> rollBackRules = new ArrayList<RollbackRuleAttribute>(len);

        for (Class rbRule : $rollbackFor) {
            RollbackRuleAttribute rule = new RollbackRuleAttribute(rbRule);
            rollBackRules.add(rule);
        }

        for (String rbRule : $rollbackForClassName) {
            RollbackRuleAttribute rule = new RollbackRuleAttribute(rbRule);
            rollBackRules.add(rule);
        }

        for (Class rbRule : $noRollbackFor) {
            NoRollbackRuleAttribute rule = new NoRollbackRuleAttribute(rbRule);
            rollBackRules.add(rule);
        }
        // 默认添加不需要回滚的异常基类；
        NoRollbackRuleAttribute defRule = new NoRollbackRuleAttribute(NoRollbackException.class);
        rollBackRules.add(defRule);

        for (String rbRule : $noRollbackForClassName) {
            NoRollbackRuleAttribute rule = new NoRollbackRuleAttribute(rbRule);
            rollBackRules.add(rule);
        }

        this.rollBackRules.addAll(rollBackRules);
    }

    protected void completeTransactionAfterThrowing(TransactionStatus status, Throwable ex) {
        if (rollbackOn(ex)) {
            try {
                getTransactionManager().rollback(status);
            } catch (TransactionSystemException ex2) {
                logger.error("Application exception overridden by rollback exception", ex);
                ex2.initApplicationException(ex);
                throw ex2;
            } catch (RuntimeException ex2) {
                logger.error("Application exception overridden by rollback exception", ex);
                throw ex2;
            } catch (Error err) {
                logger.error("Application exception overridden by rollback error", ex);
                throw err;
            }
        } else {
            // We don't roll back on this exception.
            // Will still roll back if TransactionStatus.isRollbackOnly() is true.
            try {
                getTransactionManager().commit(status);
            } catch (TransactionSystemException ex2) {
                logger.error("Application exception overridden by commit exception", ex);
                ex2.initApplicationException(ex);
                throw ex2;
            } catch (RuntimeException ex2) {
                logger.error("Application exception overridden by commit exception", ex);
                throw ex2;
            } catch (Error err) {
                logger.error("Application exception overridden by commit error", ex);
                throw err;
            }
        }
    }

    public boolean rollbackOn(Throwable ex) {
        RollbackRuleAttribute winner = null;

        int deepest = Integer.MAX_VALUE;
        if (this.rollBackRules != null) {
            for (RollbackRuleAttribute rule : this.rollBackRules) {
                int depth = rule.getDepth(ex);
                if (depth >= 0 && depth < deepest) {
                    deepest = depth;
                    winner = rule;
                }
            }
        }

        // User superclass behavior (rollback on unchecked) if no rule matches.
        if (winner == null) {
            return (ex instanceof RuntimeException || ex instanceof Error);
        }

        return !(winner instanceof NoRollbackRuleAttribute);
    }

    private static class ThrowableHolder {

        private final Throwable throwable;

        public ThrowableHolder(Throwable throwable) {
            this.throwable = throwable;
        }

        public final Throwable getThrowable() {
            return this.throwable;
        }
    }

    private static class ThrowableHolderException extends RuntimeException {

        public ThrowableHolderException(Throwable throwable) {
            super(throwable);
        }

        @Override
        public String toString() {
            return getCause().toString();
        }
    }
}
