package com.zb.framework.serialize;

import com.caucho.hessian.io.AbstractHessianInput;
import com.caucho.hessian.io.AbstractHessianOutput;
import com.caucho.hessian.io.AbstractSerializerFactory;
import com.caucho.hessian.io.BigDecimalDeserializer;
import com.caucho.hessian.io.Deserializer;
import com.caucho.hessian.io.Hessian2Input;
import com.caucho.hessian.io.Hessian2Output;
import com.caucho.hessian.io.HessianProtocolException;
import com.caucho.hessian.io.JavaDeserializer;
import com.caucho.hessian.io.JavaSerializer;
import com.caucho.hessian.io.LocaleSerializer;
import com.caucho.hessian.io.SerializerFactory;
import com.caucho.hessian.io.StringValueSerializer;
import com.zb.framework.enums.BizCode;
import com.zb.framework.util.CoreCommonUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Locale;

/**
 * 序列化与反序列化的hessian实现<br/>
 *
 * Created by  2015/1/13.
 */
public class HessianSerializer extends AbstractSerializer implements Serializer {
    public static final String QIANGUNGUN_CLASS = "com.qiangungun";

    private static AbstractSerializerFactory customFactory = new AbstractSerializerFactory() {
        @Override
        public com.caucho.hessian.io.Serializer getSerializer(Class aClass) throws HessianProtocolException {
            if(BigDecimal.class.equals(aClass)) {
                return new StringValueSerializer();
            } else if(aClass.getName().startsWith(QIANGUNGUN_CLASS)) {
                return new JavaSerializer(aClass);
            } else if(Locale.class.isAssignableFrom(aClass)) {
                return new LocaleSerializer();
            }

            return null;
        }

        @Override
        public Deserializer getDeserializer(Class aClass) throws HessianProtocolException {
            if(BigDecimal.class.equals(aClass)) {
                return new BigDecimalDeserializer();
            } else if(aClass.getName().startsWith(QIANGUNGUN_CLASS)) {
                return new JavaDeserializer(aClass);
            }

            return null;
        }
    };

    // 使用统一的serializer factory；
    private SerializerFactory factory = null;

    public HessianSerializer() {
        this(CoreCommonUtils.getClassLoader(HessianSerializer.class));
    }

    public HessianSerializer(ClassLoader classLoader) {
        factory = new SerializerFactory(classLoader);

        factory.addFactory(customFactory);
    }

    @Override
    protected byte[] doSerialize(Serializable object) {
        Hessian2Output out = null;
        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(128);
            out = new Hessian2Output(buffer);
            /*SerializerFactory factory = SerializerFactory.createDefault();
            factory.addFactory(customFactory);*/
            out.setSerializerFactory(factory);

            out.writeObject(object);
            out.flush();
            out.close();

            byte[] bytes = buffer.toByteArray();

            return bytes;
        } catch (IOException e) {
            CoreCommonUtils.raiseBizException(BizCode.IO_Error, "序列化异常", e);

            // 不会执行的代码!!
            return null;
        } finally {
            closeQuietly(out);
        }
    }

    @Override
    protected Serializable doDeserialize(byte[] bin) {
        Hessian2Input in = null;
        try {
            ByteArrayInputStream buffer = new ByteArrayInputStream(bin);
            in = new Hessian2Input(buffer);
            /*SerializerFactory factory = SerializerFactory.createDefault();
            factory.addFactory(customFactory);*/
            in.setSerializerFactory(factory);

            Object obj = in.readObject();
            in.close();

            return (Serializable)obj;
        } catch (Exception e) {
            CoreCommonUtils.raiseBizException(BizCode.IO_Error, "反序列化异常", e);

            // 不会执行的代码!!
            return null;
        } finally {
            closeQuietly(in);
        }
    }

    private static void closeQuietly(AbstractHessianOutput io) {
        if(io != null) {
            try {
                io.close();
            } catch (IOException e) {
                ;
            }
        }
    }

    private static void closeQuietly(AbstractHessianInput io) {
        if(io != null) {
            try {
                io.close();
            } catch (IOException e) {
                ;
            }
        }
    }
}
