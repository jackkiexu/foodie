package com.zb.framework.mq.rocketmq.spring;

import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.common.message.Message;
import com.zb.framework.enums.BizCode;
import com.zb.framework.mq.rocketmq.producer.MessageBuilder;
import com.zb.framework.mq.rocketmq.producer.MessageProducer;
import com.zb.framework.mq.rocketmq.producer.SendResult;
import com.zb.framework.mq.rocketmq.producer.SendStatus;
import com.zb.framework.serialize.Serializer;
import com.zb.framework.util.CoreCommonUtils;
import com.zb.framework.util.CoreSystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RocketMQ producer模板<br/>
 *
 * Created by  2015/1/14.
 */
public class RocketMqTemplate implements InitializingBean, MessageProducer, DisposableBean {
    private static final Logger LOG = LoggerFactory.getLogger(RocketMqTemplate.class);

    /**
     * RocketMQ服务配置<br/>
     *
     */
    private RocketMqConfig config = null;

    /**
     * 序列化工具<br/>
     *
     */
    private Serializer serializer = null;

    /**
     * 所有的消费者实现<br/>
     *
     */
    private Map<String/*topic*/, DefaultMQProducer> producers = new ConcurrentHashMap<>(8, 1F);
    private static final Object lock = new Object();

    @Override
    public SendResult send(MessageBuilder builder) {
        SendResult $result = new SendResult();
        try {
            Message message = builder.build(this.serializer);
            DefaultMQProducer producer = getOrCreateProducer(message.getTopic());
            com.alibaba.rocketmq.client.producer.SendResult result = producer.send(message);

            if(result != null) {
                $result.setMessageId(result.getMsgId());
                $result.setStatus(result.getSendStatus() != null
                        ? SendStatus.Success : SendStatus.Unknown);
            }

            return $result;
        } catch (Exception e) {
            LOG.warn("发送RocketMQ消息异常", e);
        }

        return $result;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if(config == null) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "RocketMQ config不能为null");
        }

        if(serializer == null) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "RocketMQ消息序列化实例不能为null");
        }
    }

    private DefaultMQProducer getOrCreateProducer(String topic) throws MQClientException {
        DefaultMQProducer producer = producers.get(topic);
        if(null != producer) {
            return producer;
        }

        synchronized (lock) {
            // double check;
            producer = producers.get(topic);
            if(null != producer) {
                return producer;
            }

            producer = new DefaultMQProducer();
            producer.setHeartbeatBrokerInterval(config.getHeartbeat4BrokerInterval());
            producer.setPersistConsumerOffsetInterval(config.getPersistOffsetInterval());
            producer.setClientCallbackExecutorThreads(config.getNettyAsyncExecutorThreads());
            producer.setPollNameServerInteval(config.getSyncRouteInfoInterval());
            producer.setNamesrvAddr(config.getNamesrvAddressSet());
            producer.setProducerGroup(CoreSystemUtils.objectId());
            producer.setRetryTimesWhenSendFailed(config.getRetryTimes());
            producer.setSendMsgTimeout(config.getSendMessageTimeout());

            producer.start();

            producers.put(topic, producer);
        }

        return producer;
    }

    @Override
    public void destroy() throws Exception {
        for(DefaultMQProducer producer : producers.values()) {
            producer.shutdown();
        }
    }

    public RocketMqConfig getConfig() {
        return config;
    }

    public void setConfig(RocketMqConfig config) {
        this.config = config;
    }

    public Serializer getSerializer() {
        return serializer;
    }

    public void setSerializer(Serializer serializer) {
        this.serializer = serializer;
    }
}
