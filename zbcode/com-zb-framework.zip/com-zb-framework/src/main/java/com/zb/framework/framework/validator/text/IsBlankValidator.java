package com.zb.framework.framework.validator.text;

import com.zb.framework.framework.validator.Validator;
import com.zb.framework.framework.validator.base.AbstractValidator;

/**
 * Created by  2014/12/15.
 */
public class IsBlankValidator extends AbstractValidator implements Validator {
    public IsBlankValidator() {
        super(null);
    }

    @Override
    public boolean doValidate(Object target) {
        if(target == null) {
            return true;
        }

        if(!(target instanceof CharSequence)) {
            return false;
        }

        return ((CharSequence)target).toString().trim().isEmpty();
    }
}
