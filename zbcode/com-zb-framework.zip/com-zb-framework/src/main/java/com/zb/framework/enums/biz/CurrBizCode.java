/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

import java.io.Serializable;

/**
 * Created by  2015/7/2.
 */
public class CurrBizCode extends BizCode implements Serializable {
    private static final long serialVersionUID = -512658988150740680L;

    public static final BizCode TaFail
            = new CurrBizCode("TaFail", ServiceCode.Currency, "001", "Merchant支付失败");

    public static final BizCode TaPending
            = new CurrBizCode("TaPending", ServiceCode.Currency, "002", "Merchant支付中");

    public static final BizCode TaException
            = new CurrBizCode("TaException", ServiceCode.Currency, "003", "Merchant支付异常");

    public static final BizCode TransNotExists
            = new CurrBizCode("TransNotExists", ServiceCode.Currency, "901", "交易数据不存在");

    public static final BizCode OperationPending
            = new CurrBizCode("OperationPending", ServiceCode.Currency, "902", "等待后续操作");

    protected CurrBizCode() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    public CurrBizCode(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }
}
