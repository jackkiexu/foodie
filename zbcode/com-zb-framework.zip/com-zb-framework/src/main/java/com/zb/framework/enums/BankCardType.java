package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 银行卡类型
 * Created by  2015/1/19.
 */
public final class BankCardType extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = -2160088627399173747L;

    public static final BankCardType Debit = new BankCardType("D", "借记卡");

    public static final BankCardType Credit = new BankCardType("C", "贷记卡");

    protected BankCardType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected BankCardType(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return BankCardType.class;
    }
}
