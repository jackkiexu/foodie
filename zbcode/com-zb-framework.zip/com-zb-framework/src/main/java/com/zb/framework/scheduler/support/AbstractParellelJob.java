///**
// * 
// *
// * Copyright (c) 2014-2015 All Rights Reserved.
// */
//package com.zb.framework.scheduler.support;
//
//import com.zb.framework.scheduler.JobContext;
//import com.zb.framework.scheduler.enums.LockSource;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
///**
// * Created by  2015/4/21.
// */
//abstract class AbstractParellelJob<T> extends AbstractJob<T> {
//    private static final Logger LOG = LoggerFactory.getLogger(AbstractParellelJob.class);
//    private LockSource lockSource;
//
//    @Override
//    public final boolean process(T data, JobContext context) {
//        boolean succ = false; // 是否加锁成功
//        boolean hasEx = false;// 是否有处理异常
//
//        // 加锁
//        succ = lock(genLockId(data, context), getLockSource());
//        if(succ) {
//            // double check;
//            //boolean csucc = doubleCheck(data, context);
//        }
//        return false;
//    }
//
//    /**
//     * 对处理的数据加锁<br/>
//     *
//     * @param lockId
//     * @param source
//     * @return
//     */
//    protected abstract boolean lock(String lockId, LockSource source);
//
//    /**
//     * 获取加锁的属性<br/>
//     *
//     * @return
//     */
//    protected abstract LockSource getLockSource();
//
//    /**
//     * 锁的唯一Id<br/>
//     *
//     * @return
//     */
//    protected abstract String genLockId(T data, JobContext context);
//}
