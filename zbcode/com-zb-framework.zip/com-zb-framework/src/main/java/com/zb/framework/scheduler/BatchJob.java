/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.scheduler;

import java.util.List;

/**
 * 批量处理数据的任务类型<br/>
 *
 * Created by  2015/4/21.
 */
public interface BatchJob<T> extends JobBase<T> {
    /**
     * 处理数据<br/>
     *
     * @param data
     * @param context
     * @return
     */
    public boolean process(List<T> data, JobContext context);
}
