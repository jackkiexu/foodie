///**
// * 
// *
// * Copyright (c) 2014-2015 All Rights Reserved.
// */
//package com.zb.framework.scheduler.support;
//
//import com.zb.framework.scheduler.JobBase;
//import com.zb.framework.scheduler.JobContext;
//import com.zb.framework.scheduler.TaskItem;
//import com.zb.framework.util.CoreObjectUtils;
//import com.taobao.pamirs.schedule.IScheduleTaskDeal;
//import com.taobao.pamirs.schedule.TaskItemDefine;
//import org.apache.commons.collections.CollectionUtils;
//import org.apache.commons.lang3.StringUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.List;
//import java.util.Map;
//
///**
// * 任务基类<br/>
// *
// * Created by  2015/4/21.
// */
//public abstract class AbstractJobBase<T> implements JobBase<T>, IScheduleTaskDeal<T> {
//    private static final ThreadLocal<JobContext> Ctx_TLS = new ThreadLocal<>();
//
//    private static final Logger LOG = LoggerFactory.getLogger(AbstractJobBase.class);
//
//    protected final List<T> FORCE_ONCE = Collections.unmodifiableList(new ArrayList<T>());
//
//    @Override
//    public final List<T> selectTasks(String taskParameter, String ownSign
//            , int taskItemNum, List<TaskItemDefine> taskItemList, int eachFetchDataNum) throws Exception {
//        try {
//            JobContext context = new JobContext();
//            context.setEnv(ownSign);
//            context.setPageSize(eachFetchDataNum);
//            context.setTotalTaskItems(taskItemNum);
//            if(StringUtils.isNotEmpty(taskParameter)) {
//                context.setParameters(CoreObjectUtils.json2Object(taskParameter, Map.class));
//            }
//            for(TaskItemDefine tid : taskItemList) {
//                TaskItem ti = new TaskItem();
//                ti.setId(tid.getTaskItemId());
//                String tidParam = tid.getParameter();
//                if(StringUtils.isNotEmpty(tidParam)) {
//                    tidParam = "{" + tidParam + "}";
//                    ti.setParameters(CoreObjectUtils.json2Object(tidParam, Map.class));
//                }
//
//                context.getItems().add(ti);
//            }
//
//            Ctx_TLS.set(context);
//            LOG.info("（" + getName() + ")开始搜索任务列表，ctx = " + getContext());
//
//            final List<T> list = read(context);
//            if(list == FORCE_ONCE) {
//                LOG.info("（" + getName() + ")强制执行一次.");
//                processOnce(getContext());
//            }
//
//            LOG.info("（" + getName() + "）搜索任务列表结束： " + (CollectionUtils.isEmpty(list)?0:list.size()));
//            return list;
//        } finally {
//            Ctx_TLS.remove();
//        }
//    }
//
//    /**
//     * 强制执行一次<br/>
//     *
//     * @param context
//     * @return
//     */
//    protected boolean processOnce(JobContext context) {
//        return true;
//    }
//
//    public final JobContext getContext() {
//        return Ctx_TLS.get();
//    }
//
//    /**
//     * 获取当前Job的名称，一般用于描述Job的功能<br/>
//     *
//     * @return
//     */
//    protected abstract String getName();
//}
