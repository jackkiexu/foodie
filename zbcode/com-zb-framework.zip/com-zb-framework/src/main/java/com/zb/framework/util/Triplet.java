/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.util;

/**
 * 可以存储三个值得Tuple<br/>
 *
 * Created by  2015/6/4.
 */
public class Triplet<V1, V2, V3> {
    private V1 value1 = null;

    private V2 value2 = null;

    private V3 value3 = null;

    public Triplet() {
    }

    public Triplet(V1 value1, V2 value2, V3 value3) {
        this.value1 = value1;
        this.value2 = value2;
        this.value3 = value3;
    }

    public V1 getValue1() {
        return value1;
    }

    public void setValue1(V1 value1) {
        this.value1 = value1;
    }

    public V2 getValue2() {
        return value2;
    }

    public void setValue2(V2 value2) {
        this.value2 = value2;
    }

    public V3 getValue3() {
        return value3;
    }

    public void setValue3(V3 value3) {
        this.value3 = value3;
    }
}
