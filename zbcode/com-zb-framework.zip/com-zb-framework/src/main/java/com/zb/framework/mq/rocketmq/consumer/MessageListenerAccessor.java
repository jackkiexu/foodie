/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.mq.rocketmq.consumer;

import com.zb.framework.serialize.Serializer;

/**
 * Created by  2015/4/1.
 */
public interface MessageListenerAccessor {
    /**
     * 获取序列化工具<br/>
     *
     * @return
     */
    Serializer getSerializer();

    /**
     * 设置序列化工具<br/>
     *
     * @param serializer
     */
    void setSerializer(Serializer serializer);
}
