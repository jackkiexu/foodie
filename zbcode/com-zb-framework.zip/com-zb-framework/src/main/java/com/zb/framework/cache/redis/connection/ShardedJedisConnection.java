//package com.zb.framework.cache.redis.connection;
//
//import org.springframework.dao.DataAccessException;
//import org.springframework.data.redis.ExceptionTranslationStrategy;
//import org.springframework.data.redis.FallbackExceptionTranslationStrategy;
//import org.springframework.data.redis.connection.AbstractRedisConnection;
//import org.springframework.data.redis.connection.DataType;
//import org.springframework.data.redis.connection.MessageListener;
//import org.springframework.data.redis.connection.RedisPipelineException;
//import org.springframework.data.redis.connection.ReturnType;
//import org.springframework.data.redis.connection.SortParameters;
//import org.springframework.data.redis.connection.Subscription;
//import org.springframework.data.redis.connection.jedis.JedisConnection;
//import org.springframework.data.redis.connection.jedis.JedisConverters;
//import org.springframework.data.redis.core.Cursor;
//import org.springframework.data.redis.core.KeyBoundCursor;
//import org.springframework.data.redis.core.ScanIteration;
//import org.springframework.data.redis.core.ScanOptions;
//import org.springframework.data.redis.core.types.RedisClientInfo;
//import org.springframework.util.ReflectionUtils;
//import org.springframework.util.StringUtils;
//import redis.clients.jedis.BinaryJedis;
//import redis.clients.jedis.Builder;
//import redis.clients.jedis.Client;
//import redis.clients.jedis.Connection;
//import redis.clients.jedis.Jedis;
//import redis.clients.jedis.Protocol;
//import redis.clients.jedis.Queable;
//import redis.clients.jedis.ScanParams;
//import redis.clients.jedis.ScanResult;
//import redis.clients.jedis.ShardedJedis;
//import redis.clients.util.Pool;
//
//import java.lang.reflect.Field;
//import java.lang.reflect.Method;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//import java.util.Properties;
//import java.util.Set;
//
///**
// * Created by  2015/2/4.
// */
//public class ShardedJedisConnection extends AbstractRedisConnection {
//    private ShardedJedis jedis = null;
//
//    private final Pool<ShardedJedis> pool;
//
//    /**
//     * 数据库index<br/>
//     * TODO: 目前sharding不支持select操作<br/>
//     *
//     */
//    private final int dbIndex = 0;
//
//    /**
//     * 所有连接的客户端<br/>
//     *
//     */
//    //private List<Client> clients = new ArrayList<>(2);
//
//    /**
//     * Constructs a new <code>ShardedJedisConnection</code> instance.
//     *
//     * @param jedis Jedis entity
//     */
//    public ShardedJedisConnection(ShardedJedis jedis) {
//        this(jedis, null, 0);
//    }
//
//    /**
//     * Constructs a new <code>ShardedJedisConnection</code> instance backed by a jedis pool.
//     *
//     * @param jedis
//     * @param pool can be null, if no pool is used
//     */
//    public ShardedJedisConnection(ShardedJedis jedis, Pool<ShardedJedis> pool, int dbIndex) {
//        this.jedis = jedis;
//        // extract underlying connection for batch operations
//        // TODO： 优化此代码！！
//        //client = (Client) ReflectionUtils.getField(CLIENT_FIELD, jedis);
//        //transaction = new Transaction(client);
//
//        this.pool = pool;
//
//        // TODO 目前不支持select；
//        /*this.dbIndex = dbIndex;
//
//        // select the db
//        // if this fail, do manual clean-up before propagating the exception
//        // as we're inside the constructor
//        if (dbIndex > 0) {
//            try {
//                select(dbIndex);
//            } catch (DataAccessException ex) {
//                close();
//                throw ex;
//            }
//        }*/
//    }
//
//    @Override
//    public boolean isClosed() {
//        return false; // TODO 不知道如何是关闭的？
//    }
//
//    @Override
//    public Object execute(String command, byte[]... args) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void select(int dbIndex) {
//        // TODO 如何进行select操作？
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public byte[] echo(byte[] message) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public String ping() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Object getNativeConnection() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public boolean isQueueing() {
//        // 依次检查所有的连接
//        /*for(Client client: clients) {
//            if(client.isInMulti()) {
//                return true;
//            }
//        }
//
//        return false;*/
//
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public boolean isPipelined() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void openPipeline() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public List<Object> closePipeline() throws RedisPipelineException {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Boolean hSet(byte[] key, byte[] field, byte[] value) {
//        Jedis _this = jedis.getShard(key);
//
//        return JedisConverters.toBoolean(_this.hset(key, field, value));
//    }
//
//    @Override
//    public Boolean hSetNX(byte[] key, byte[] field, byte[] value) {
//        Jedis _this = jedis.getShard(key);
//
//        return JedisConverters.toBoolean(_this.hsetnx(key, field, value));
//    }
//
//    @Override
//    public byte[] hGet(byte[] key, byte[] field) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hget(key, field);
//    }
//
//    @Override
//    public List<byte[]> hMGet(byte[] key, byte[]... fields) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hmget(key, fields);
//    }
//
//    @Override
//    public void hMSet(byte[] key, Map<byte[], byte[]> hashes) {
//        Jedis _this = jedis.getShard(key);
//
//        _this.hmset(key, hashes);
//    }
//
//    @Override
//    public Long hIncrBy(byte[] key, byte[] field, long delta) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hincrBy(key, field, delta);
//    }
//
//    @Override
//    public Double hIncrBy(byte[] key, byte[] field, double delta) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hincrByFloat(key, field, delta);
//    }
//
//    @Override
//    public Boolean hExists(byte[] key, byte[] field) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hexists(key, field);
//    }
//
//    @Override
//    public Long hDel(byte[] key, byte[]... fields) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hdel(key, fields);
//    }
//
//    @Override
//    public Long hLen(byte[] key) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hlen(key);
//    }
//
//    @Override
//    public Set<byte[]> hKeys(byte[] key) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hkeys(key);
//    }
//
//    @Override
//    public List<byte[]> hVals(byte[] key) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hvals(key);
//    }
//
//    @Override
//    public Map<byte[], byte[]> hGetAll(byte[] key) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.hgetAll(key);
//    }
//
//    @Override
//    public Cursor<Map.Entry<byte[], byte[]>> hScan(byte[] key, ScanOptions options) {
//        return hScan(key, 0L, options);
//    }
//
//    /**
//     * @since 1.4
//     * @param key
//     * @param cursorId
//     * @param options
//     * @return
//     */
//    public Cursor<Map.Entry<byte[], byte[]>> hScan(final byte[] key, long cursorId, ScanOptions options) {
//
//        return new KeyBoundCursor<Map.Entry<byte[], byte[]>>(key, cursorId, options) {
//
//            @Override
//            protected ScanIteration<Map.Entry<byte[], byte[]>> doScan(byte[] key, long cursorId, ScanOptions options) {
//
//                if (isQueueing() || isPipelined()) {
//                    throw new UnsupportedOperationException("'HSCAN' cannot be called in pipeline / transaction mode.");
//                }
//
//                ScanParams params = prepareScanParams(options);
//
//                Jedis shard = jedis.getShard(key);
//                ScanResult<Map.Entry<byte[], byte[]>> result = shard.hscan(key, JedisConverters.toBytes(cursorId), params);
//                return new ScanIteration<Map.Entry<byte[], byte[]>>(Long.valueOf(result.getStringCursor()), result.getResult());
//            }
//        }.open();
//    }
//
//    private ScanParams prepareScanParams(ScanOptions options) {
//        ScanParams sp = new ScanParams();
//        if (!options.equals(ScanOptions.NONE)) {
//            if (options.getCount() != null) {
//                sp.count(options.getCount().intValue());
//            }
//            if (StringUtils.hasText(options.getPattern())) {
//                sp.match(options.getPattern());
//            }
//        }
//        return sp;
//    }
//
//    @Override
//    public Boolean exists(byte[] key) {
//        Jedis _this = jedis.getShard(key);
//
//        return _this.exists(key);
//    }
//
//    @Override
//    public Long del(byte[]... keys) {
//        Long i = 0L;
//
//        for (byte[] key : keys) {
//            i += conn(key).del(keys);
//        }
//
//        return i;
//    }
//
//    @Override
//    public DataType type(byte[] key) {
//        return conn(key).type(key);
//    }
//
//    @Override
//    public Set<byte[]> keys(byte[] pattern) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Cursor<byte[]> scan(ScanOptions options) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public byte[] randomKey() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void rename(byte[] key, byte[] newKey) {
//        Jedis shard = jedis.getShard(key);
//        shard.rename(key, newKey);
//    }
//
//    @Override
//    public Boolean renameNX(byte[] key, byte[] newKey) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Boolean expire(byte[] key, long seconds) {
//        return conn(key).expire(key, seconds);
//    }
//
//    @Override
//    public Boolean pExpire(byte[] key, long millis) {
//        return conn(key).pExpire(key, millis);
//    }
//
//    @Override
//    public Boolean expireAt(byte[] key, long unixTime) {
//        return conn(key).expireAt(key, unixTime);
//    }
//
//    @Override
//    public Boolean pExpireAt(byte[] key, long unixTimeInMillis) {
//        return conn(key).pExpireAt(key, unixTimeInMillis);
//    }
//
//    @Override
//    public Boolean persist(byte[] key) {
//        return conn(key).persist(key);
//    }
//
//    @Override
//    public Boolean move(byte[] key, int dbIndex) {
//        return conn(key).move(key, dbIndex);
//    }
//
//    @Override
//    public Long ttl(byte[] key) {
//        return conn(key).ttl(key);
//    }
//
//    @Override
//    public Long pTtl(byte[] key) {
//        return conn(key).pTtl(key);
//    }
//
//    @Override
//    public List<byte[]> sort(byte[] key, SortParameters params) {
//        return conn(key).sort(key, params);
//    }
//
//    @Override
//    public Long sort(byte[] key, SortParameters params, byte[] storeKey) {
//        return conn(key).sort(key, params, storeKey);
//    }
//
//    @Override
//    public byte[] dump(byte[] key) {
//        return conn(key).dump(key);
//    }
//
//    @Override
//    public void restore(byte[] key, long ttlInMillis, byte[] serializedValue) {
//        conn(key).restore(key, ttlInMillis, serializedValue);
//    }
//
//    @Override
//    public Long rPush(byte[] key, byte[]... values) {
//        return conn(key).rPush(key, values);
//    }
//
//    @Override
//    public Long lPush(byte[] key, byte[]... value) {
//        return conn(key).lPush(key, value);
//    }
//
//    @Override
//    public Long rPushX(byte[] key, byte[] value) {
//        return conn(key).rPush(key, value);
//    }
//
//    @Override
//    public Long lPushX(byte[] key, byte[] value) {
//        return conn(key).lPushX(key, value);
//    }
//
//    @Override
//    public Long lLen(byte[] key) {
//        return conn(key).lLen(key);
//    }
//
//    @Override
//    public List<byte[]> lRange(byte[] key, long begin, long end) {
//        return conn(key).lRange(key, begin, end);
//    }
//
//    @Override
//    public void lTrim(byte[] key, long begin, long end) {
//        conn(key).lTrim(key, begin, end);
//    }
//
//    @Override
//    public byte[] lIndex(byte[] key, long index) {
//        return conn(key).lIndex(key, index);
//    }
//
//    @Override
//    public Long lInsert(byte[] key, Position where, byte[] pivot, byte[] value) {
//        return conn(key).lInsert(key, where, pivot, value);
//    }
//
//    @Override
//    public void lSet(byte[] key, long index, byte[] value) {
//        conn(key).lSet(key, index, value);
//    }
//
//    @Override
//    public Long lRem(byte[] key, long count, byte[] value) {
//        return conn(key).lRem(key, count, value);
//    }
//
//    @Override
//    public byte[] lPop(byte[] key) {
//        return conn(key).lPop(key);
//    }
//
//    @Override
//    public byte[] rPop(byte[] key) {
//        return conn(key).rPop(key);
//    }
//
//    @Override
//    public List<byte[]> bLPop(int timeout, byte[]... keys) {
//        List<byte[]> result = new ArrayList<>();
//        for(byte[] key : keys) {
//            result.addAll(conn(key).bLPop(timeout, keys));
//        }
//
//        return result;
//    }
//
//    @Override
//    public List<byte[]> bRPop(int timeout, byte[]... keys) {
//        List<byte[]> result = new ArrayList<>();
//        for(byte[] key : keys) {
//            result.addAll(conn(key).bRPop(timeout, keys));
//        }
//
//        return result;
//    }
//
//    @Override
//    public byte[] rPopLPush(byte[] srcKey, byte[] dstKey) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public byte[] bRPopLPush(int timeout, byte[] srcKey, byte[] dstKey) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public boolean isSubscribed() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Subscription getSubscription() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long publish(byte[] channel, byte[] message) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void subscribe(MessageListener listener, byte[]... channels) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void pSubscribe(MessageListener listener, byte[]... patterns) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void scriptFlush() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void scriptKill() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public String scriptLoad(byte[] script) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public List<Boolean> scriptExists(String... scriptShas) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public <T> T eval(byte[] script, ReturnType returnType, int numKeys, byte[]... keysAndArgs) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public <T> T evalSha(String scriptSha, ReturnType returnType, int numKeys, byte[]... keysAndArgs) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void bgWriteAof() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void bgReWriteAof() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void bgSave() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long lastSave() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void save() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long dbSize() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void flushDb() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void flushAll() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Properties info() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Properties info(String section) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void shutdown() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void shutdown(ShutdownOption option) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public List<String> getConfig(String pattern) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void setConfig(String param, String value) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void resetConfigStats() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long time() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void killClient(String host, int port) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void setClientName(byte[] name) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public String getClientName() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public List<RedisClientInfo> getClientList() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void slaveOf(String host, int port) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void slaveOfNoOne() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long sAdd(byte[] key, byte[]... values) {
//        return conn(key).sAdd(key, values);
//    }
//
//    @Override
//    public Long sRem(byte[] key, byte[]... values) {
//        return conn(key).sRem(key, values);
//    }
//
//    @Override
//    public byte[] sPop(byte[] key) {
//        return conn(key).sPop(key);
//    }
//
//    @Override
//    public Boolean sMove(byte[] srcKey, byte[] destKey, byte[] value) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long sCard(byte[] key) {
//        return conn(key).sCard(key);
//    }
//
//    @Override
//    public Boolean sIsMember(byte[] key, byte[] value) {
//        return conn(key).sIsMember(key, value);
//    }
//
//    @Override
//    public Set<byte[]> sInter(byte[]... keys) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long sInterStore(byte[] destKey, byte[]... keys) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Set<byte[]> sUnion(byte[]... keys) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long sUnionStore(byte[] destKey, byte[]... keys) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Set<byte[]> sDiff(byte[]... keys) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long sDiffStore(byte[] destKey, byte[]... keys) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Set<byte[]> sMembers(byte[] key) {
//        return conn(key).sMembers(key);
//    }
//
//    @Override
//    public byte[] sRandMember(byte[] key) {
//        return conn(key).sRandMember(key);
//    }
//
//    @Override
//    public List<byte[]> sRandMember(byte[] key, long count) {
//        return conn(key).sRandMember(key, count);
//    }
//
//    @Override
//    public Cursor<byte[]> sScan(byte[] key, ScanOptions options) {
//        return conn(key).sScan(key, options);
//    }
//
//    @Override
//    public byte[] get(byte[] key) {
//        return conn(key).get(key);
//    }
//
//    @Override
//    public byte[] getSet(byte[] key, byte[] value) {
//        return conn(key).getSet(key, value);
//    }
//
//    @Override
//    public List<byte[]> mGet(byte[]... keys) {
//        List<byte[]> result = new ArrayList<>();
//        for(byte[] key : keys) {
//            result.addAll(conn(key).mGet(keys));
//        }
//
//        return result;
//    }
//
//    @Override
//    public void set(byte[] key, byte[] value) {
//        conn(key).set(key, value);
//    }
//
//    @Override
//    public Boolean setNX(byte[] key, byte[] value) {
//        return conn(key).setNX(key, value);
//    }
//
//    @Override
//    public void setEx(byte[] key, long seconds, byte[] value) {
//        conn(key).setEx(key, seconds, value);
//    }
//
//    @Override
//    public void pSetEx(byte[] key, long milliseconds, byte[] value) {
//        conn(key).pSetEx(key, milliseconds, value);
//    }
//
//    @Override
//    public void mSet(Map<byte[], byte[]> tuple) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Boolean mSetNX(Map<byte[], byte[]> tuple) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long incr(byte[] key) {
//        return conn(key).incr(key);
//    }
//
//    @Override
//    public Long incrBy(byte[] key, long value) {
//        return conn(key).incrBy(key, value);
//    }
//
//    @Override
//    public Double incrBy(byte[] key, double value) {
//        return conn(key).incrBy(key, value);
//    }
//
//    @Override
//    public Long decr(byte[] key) {
//        return conn(key).decr(key);
//    }
//
//    @Override
//    public Long decrBy(byte[] key, long value) {
//        return conn(key).decrBy(key, value);
//    }
//
//    @Override
//    public Long append(byte[] key, byte[] value) {
//        return conn(key).append(key, value);
//    }
//
//    @Override
//    public byte[] getRange(byte[] key, long begin, long end) {
//        return conn(key).getRange(key, begin, end);
//    }
//
//    @Override
//    public void setRange(byte[] key, byte[] value, long offset) {
//        conn(key).setRange(key, value, offset);
//    }
//
//    @Override
//    public Boolean getBit(byte[] key, long offset) {
//        return conn(key).getBit(key, offset);
//    }
//
//    @Override
//    public Boolean setBit(byte[] key, long offset, boolean value) {
//        return conn(key).setBit(key, offset, value);
//    }
//
//    @Override
//    public Long bitCount(byte[] key) {
//        return conn(key).bitCount(key);
//    }
//
//    @Override
//    public Long bitCount(byte[] key, long begin, long end) {
//        return conn(key).bitCount(key, begin, end);
//    }
//
//    @Override
//    public Long bitOp(BitOperation op, byte[] destination, byte[]... keys) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Long strLen(byte[] key) {
//        return conn(key).strLen(key);
//    }
//
//    @Override
//    public void multi() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public List<Object> exec() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void discard() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void watch(byte[]... keys) {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public void unwatch() {
//        // NOTE sharding不支持直接发送命令，必须进行与key相关的命令！！
//        throw new UnsupportedOperationException("Sharding不支持与key无关的指令");
//    }
//
//    @Override
//    public Boolean zAdd(byte[] key, double score, byte[] value) {
//        return conn(key).zAdd(key, score, value);
//    }
//
//    @Override
//    public Long zAdd(byte[] key, Set<Tuple> tuples) {
//        return conn(key).zAdd(key, tuples);
//    }
//
//    @Override
//    public Long zRem(byte[] key, byte[]... values) {
//        return conn(key).zRem(key, values);
//    }
//
//    @Override
//    public Double zIncrBy(byte[] key, double increment, byte[] value) {
//        return conn(key).zIncrBy(key, increment, value);
//    }
//
//    @Override
//    public Long zRank(byte[] key, byte[] value) {
//        return conn(key).zRank(key, value);
//    }
//
//    @Override
//    public Long zRevRank(byte[] key, byte[] value) {
//        return conn(key).zRevRank(key, value);
//    }
//
//    @Override
//    public Set<byte[]> zRange(byte[] key, long begin, long end) {
//        return conn(key).zRange(key, begin, end);
//    }
//
//    @Override
//    public Set<Tuple> zRangeWithScores(byte[] key, long begin, long end) {
//        return conn(key).zRangeWithScores(key, begin, end);
//    }
//
//    @Override
//    public Set<byte[]> zRangeByScore(byte[] key, double min, double max) {
//        return conn(key).zRangeByScore(key, min, max);
//    }
//
//    @Override
//    public Set<Tuple> zRangeByScoreWithScores(byte[] key, double min, double max) {
//        return conn(key).zRangeByScoreWithScores(key, min, max);
//    }
//
//    @Override
//    public Set<byte[]> zRangeByScore(byte[] key
//            , double min, double max, long offset, long count) {
//        return conn(key).zRangeByScore(key, min, max, offset, count);
//    }
//
//    @Override
//    public Set<Tuple> zRangeByScoreWithScores(byte[] key
//            , double min, double max, long offset, long count) {
//        return conn(key).zRangeByScoreWithScores(key, min, max, offset, count);
//    }
//
//    @Override
//    public Set<byte[]> zRevRange(byte[] key, long begin, long end) {
//        return conn(key).zRevRange(key, begin, end);
//    }
//
//    @Override
//    public Set<Tuple> zRevRangeWithScores(byte[] key, long begin, long end) {
//        return conn(key).zRevRangeWithScores(key, begin, end);
//    }
//
//    @Override
//    public Set<byte[]> zRevRangeByScore(byte[] key, double min, double max) {
//        return conn(key).zRevRangeByScore(key, min, max);
//    }
//
//    @Override
//    public Set<Tuple> zRevRangeByScoreWithScores(byte[] key, double min, double max) {
//        return conn(key).zRevRangeByScoreWithScores(key, min, max);
//    }
//
//    @Override
//    public Set<byte[]> zRevRangeByScore(byte[] key
//            , double min, double max, long offset, long count) {
//        return conn(key).zRevRangeByScore(key, min, max, offset, count);
//    }
//
//    @Override
//    public Set<Tuple> zRevRangeByScoreWithScores(byte[] key
//            , double min, double max, long offset, long count) {
//        return conn(key).zRevRangeByScoreWithScores(key, min, max, offset, count);
//    }
//
//    @Override
//    public Long zCount(byte[] key, double min, double max) {
//        return conn(key).zCount(key, min, max);
//    }
//
//    @Override
//    public Long zCard(byte[] key) {
//        return conn(key).zCard(key);
//    }
//
//    @Override
//    public Double zScore(byte[] key, byte[] value) {
//        return conn(key).zScore(key, value);
//    }
//
//    @Override
//    public Long zRemRange(byte[] key, long begin, long end) {
//        return conn(key).zRemRange(key, begin, end);
//    }
//
//    @Override
//    public Long zRemRangeByScore(byte[] key, double min, double max) {
//        return conn(key).zRemRangeByScore(key, min, max);
//    }
//
//    @Override
//    public Long zUnionStore(byte[] destKey, byte[]... sets) {
//        return conn(destKey).zUnionStore(destKey, sets);
//    }
//
//    @Override
//    public Long zUnionStore(byte[] destKey, Aggregate aggregate
//            , int[] weights, byte[]... sets) {
//        return conn(destKey).zUnionStore(destKey, aggregate, weights, sets);
//    }
//
//    @Override
//    public Long zInterStore(byte[] destKey, byte[]... sets) {
//        return conn(destKey).zInterStore(destKey, sets);
//    }
//
//    @Override
//    public Long zInterStore(byte[] destKey, Aggregate aggregate
//            , int[] weights, byte[]... sets) {
//        return conn(destKey).zInterStore(destKey, aggregate, weights, sets);
//    }
//
//    @Override
//    public Cursor<Tuple> zScan(byte[] key, ScanOptions options) {
//        return conn(key).zScan(key, options);
//    }
//
//    private JedisConnection conn(byte[] key) {
//        Jedis shard = jedis.getShard(key);
//
//        return new JedisConnection(shard);
//    }
//
//    @Override
//    public void close() throws DataAccessException {
//        super.close();
//
//        // reset the connection
//        try {
//            pool.returnResource(jedis);
//
//            return;
//        } catch (Exception ex) {
//            /*DataAccessException dae = convertJedisAccessException(ex);
//            if (broken) {
//                pool.returnBrokenResource(jedis);
//            } else {
//                pool.returnResource(jedis);
//            }
//            throw dae;*/
//        }
//    }
//
//    // --------------------------------------------------------------- hack
//    private static final Field CLIENT_FIELD;
//    private static final Method SEND_COMMAND;
//    private static final Method GET_RESPONSE;
//
//    private static final String SHUTDOWN_SCRIPT = "return redis.call('SHUTDOWN','%s')";
//
//    private static final ExceptionTranslationStrategy EXCEPTION_TRANSLATION = new FallbackExceptionTranslationStrategy(
//            JedisConverters.exceptionConverter());
//
//    static {
//        CLIENT_FIELD = ReflectionUtils.findField(BinaryJedis.class, "client", Client.class);
//        ReflectionUtils.makeAccessible(CLIENT_FIELD);
//        SEND_COMMAND = ReflectionUtils.findMethod(Connection.class, "sendCommand", new Class[] { Protocol.Command.class,
//                byte[][].class });
//        ReflectionUtils.makeAccessible(SEND_COMMAND);
//        GET_RESPONSE = ReflectionUtils.findMethod(Queable.class, "getResponse", Builder.class);
//        ReflectionUtils.makeAccessible(GET_RESPONSE);
//    }
//}
