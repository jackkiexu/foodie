/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.scheduler;

import java.util.HashMap;
import java.util.Map;

/**
 * 任务条目信息<br/>
 *
 * Created by  2015/4/21.
 */
public class TaskItem {
    /**
     * 任务条目Id值<br/>
     *
     */
    private String id = null;

    /**
     * 任务条目自定义参数<br/>
     *
     */
    private Map<String, Object> parameters = new HashMap<>(4, 1F);

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }

    @Override
    public String toString() {
        return "TaskItem{" +
                "id='" + id + '\'' +
                ", parameters=" + parameters +
                '}';
    }
}
