/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.codec;

import com.zb.framework.serialize.HessianSerializer;
import com.zb.framework.serialize.Serializer;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufInputStream;
import org.redisson.client.codec.Codec;
import org.redisson.client.handler.State;
import org.redisson.client.protocol.Decoder;
import org.redisson.client.protocol.Encoder;

import java.io.IOException;
import java.io.Serializable;

/**
 * Created by  2015/5/7.
 */
public class RedissonHessianCodec implements Codec {
    private Serializer serializer = new HessianSerializer();

    private final Decoder<Object> decoder = new Decoder() {
        public Object decode(ByteBuf buf, State state) throws IOException {
            try {
                ByteBufInputStream in = new ByteBufInputStream(buf);
                int len = in.available();
                byte[] bin = new byte[len];
                in.readFully(bin);

                return serializer.deserialize(bin);
            } catch (IOException e) {
                throw e;
            } catch (Exception e) {
                throw new IOException(e);
            }
        }
    };

    private final Encoder encoder = new Encoder() {
        public byte[] encode(Object object) throws IOException {
            if(object != null && !(object instanceof Serializable)) {
                throw new IllegalArgumentException("object不能序列化： " + object);
            }

            return serializer.serialize((Serializable) object);
        }
    };

    public Decoder<Object> getMapValueDecoder() {
        return this.getValueDecoder();
    }

    public Encoder getMapValueEncoder() {
        return this.getValueEncoder();
    }

    public Decoder<Object> getMapKeyDecoder() {
        return this.getValueDecoder();
    }

    public Encoder getMapKeyEncoder() {
        return this.getValueEncoder();
    }

    public Decoder<Object> getValueDecoder() {
        return this.decoder;
    }

    public Encoder getValueEncoder() {
        return this.encoder;
    }

    // --------------------------------------------- help methods;
    public Serializer getSerializer() {
        return serializer;
    }

    public void setSerializer(Serializer serializer) {
        this.serializer = serializer;
    }
}
