/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.lock;

import com.zb.framework.lock.vo.CuratorConfig;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.RetryNTimes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by  on 2015/9/8.
 */
public class LockClient {
    private static final Logger logger = LoggerFactory.getLogger(LockClient.class);

    private static CuratorFramework curator = null;

    private static final Object lock = new Object();

    /**
     * 获取zk客户端
     * @param config
     * @return
     */
    public static CuratorFramework getCurator(CuratorConfig config) {
        if(null != curator){
            return curator;
        }
        synchronized(lock) {
            if(null != curator){
                return curator;
            }
            curator = CuratorClientBuilder.newClient(config).builder();
        }
        return  curator;
    }
}
