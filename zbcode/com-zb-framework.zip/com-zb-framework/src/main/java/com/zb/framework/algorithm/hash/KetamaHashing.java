
package com.zb.framework.algorithm.hash;

class KetamaHashing implements Hashing {
    public static final KetamaHashing INSTANCE = new KetamaHashing();

    @Override
    public long hash(byte[] bytes) {
        if (bytes == null || bytes.length < 4) {
            throw new IllegalArgumentException("字节数量不能少于4");
        }

        return ((long) (bytes[3] & 0xFF) << 24)
                | ((long) (bytes[2] & 0xFF) << 16)
                | ((long) (bytes[1] & 0xFF) << 8)
                | (bytes[0] & 0xFF);
    }
}
