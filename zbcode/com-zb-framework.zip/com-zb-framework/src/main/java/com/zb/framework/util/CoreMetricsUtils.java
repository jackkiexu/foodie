package com.zb.framework.util;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

/**
 * 记录系统信息的工具类<br/>
 *
 * Created by  14-4-4.
 */
public final class CoreMetricsUtils {
    private static final Logger LOG = LoggerFactory.getLogger(CoreMetricsUtils.class);

    private static boolean metricsEnable = false;

    private static ThreadLocal<MetricsData> metrics = new ThreadLocal<MetricsData>(){
        @Override
        protected MetricsData initialValue() {
            return new MetricsData();
        }
    };

    private CoreMetricsUtils(boolean metricsEnable) {
        setMetricsEnable(metricsEnable);
    }

    public static void start(String startPoint, String message, boolean isNew) {
        if(isMetricsEnable() && isNew) {
            metrics.get().start(startPoint, message);
        }
    }

    public static void startNested(String message) {
        if(isMetricsEnable()) {
            metrics.get().startNested(message);
        }
    }

    public static void stopNested() {
        if(isMetricsEnable()) {
            metrics.get().stopNested();
        }
    }

    public static void stop() {
        if(isMetricsEnable()) {
            metrics.get().stop();
        }
    }

    public static String display() {
        if(isMetricsEnable()) {
            return metrics.get().display();
        }

        return null;
    }

    public static void clear() {
        if(isMetricsEnable()) {
            metrics.get().clear();

            metrics.remove();
        }
    }

    public static void dump(boolean isNew) {
        if(!isNew || !isMetricsEnable()) {
            return;
        }

        stop();
        LOG.info(CoreThreadLocalUtils.logPrefix() + display());
        clear();
    }

    static class MetricsData {
        private Stack<Pair<String, StopWatch>> timeStack = new Stack<Pair<String, StopWatch>>();

        private List<Pair<String, StopWatch>> allTimes = new ArrayList<Pair<String, StopWatch>>(5);

        private String startPoint = null;

        private State state = State.UNSTARTED;

        static enum State {
            UNSTARTED,RUNNING, STOPPED;
        }

        public MetricsData() {
            ;
        }

        public void start(String startPoint, String message) {
            clear(); //清理数据；

            this.startPoint = startPoint;

            state = State.RUNNING;

            StopWatch time = new StopWatch();
            time.start();
            timeStack.push(new Pair<String, StopWatch>(message,time));
        }

        public void startNested(String message) {
            if(timeStack.isEmpty() || state != State.RUNNING) { //表示是从没有性能监控的地方进入的；
                return;
            }

            Pair<String, StopWatch> preTime = timeStack.peek();
            if(preTime != null) {
                preTime.getValue2().suspend();
            }

            StopWatch currTime = new StopWatch();
            currTime.start();
            timeStack.push(new Pair<String, StopWatch>(message,currTime));
        }

        public void stopNested() {
            if(timeStack.isEmpty() || state != State.RUNNING) { //表示是从没有性能监控的地方进入的；
                return;
            }

            Pair<String, StopWatch> currTime = timeStack.peek();
            if(currTime != null) {
                currTime.getValue2().stop();

                allTimes.add(currTime);
                timeStack.pop();
            }

            Pair<String, StopWatch> preTime = timeStack.peek();
            if (null != preTime) {
                preTime.getValue2().resume();
            }
        }

        public void stop() {
            state = State.STOPPED;

            while(!timeStack.empty()) {
                Pair<String, StopWatch> pair = timeStack.pop();
                StopWatch pop = pair.getValue2();
                pop.stop();

                allTimes.add(pair);
            }
        }

        public String display() {
            if(state == null || state == State.UNSTARTED || allTimes.isEmpty()) {
                return "-----------------------------(No Perf Metrics)";
            }

            StringBuffer sb = new StringBuffer("-----------------------------" +
                    "(" + startPoint + "--Perf Metrics): ");

            Collections.reverse(allTimes);

            long totalTime = 0L;
            for(Pair<String, StopWatch> pair : allTimes) {
                long time = pair.getValue2().getTime();
                sb.append("call '").append(pair.getValue1()).append("'(time:")
                        .append(time).append("ms), ");

                totalTime += time;
            }
            sb.append("totalTime = ").append(totalTime).append("ms.");
            //sb.setLength(sb.length() - 2); //删除最后的“, ”字符；

            return sb.toString();
        }

        public void clear() {
            timeStack.clear();

            allTimes.clear();

            startPoint = null;

            state = State.UNSTARTED;
        }
    }

    private static void setMetricsEnable(boolean metricsEnable) {
        CoreMetricsUtils.metricsEnable = metricsEnable;
    }

    public static boolean isMetricsEnable() {
        return metricsEnable;
    }
}
