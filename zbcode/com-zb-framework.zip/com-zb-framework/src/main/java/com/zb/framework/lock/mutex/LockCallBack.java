/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.lock.mutex;

/**
 * 获得分布式锁之后的回调函数
 * Created by  on 2015/9/9.
 */
public interface LockCallBack<T> {
    T doInLock() throws InterruptedException;
}
