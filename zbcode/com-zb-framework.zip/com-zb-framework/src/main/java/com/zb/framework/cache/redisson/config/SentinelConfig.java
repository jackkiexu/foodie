/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.config;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * sentinel也支持master/slave<br/>
 *
 * Created by  2015/5/6.
 */
public class SentinelConfig extends MultiConfig {
    /**
     * sentinel名称<br/>
     *
     */
    private String masterName;

    /**
     * 可用的sentinel服务器列表<br/>
     *
     */
    private String sentinelAddresses = null;

    private List<String> sentinelAddressList = new ArrayList<>();

    public String getMasterName() {
        return masterName;
    }

    public void setMasterName(String masterName) {
        this.masterName = masterName;
    }

    public List<String> getSentinelAddressList() {
        return sentinelAddressList;
    }

    /**
     * sentinel服务器列表，多个服务使用“,”分割，服务器地址格式：ip:port，例如：172.16.150.111:6379<br/>
     *
     * @param sentinelAddresses
     */
    public void setSentinelAddresses(String sentinelAddresses) {
        if(StringUtils.isEmpty(sentinelAddresses)) {
            throw  new IllegalArgumentException("sentinel address列表必须设置");
        }

        this.sentinelAddresses = sentinelAddresses;
        this.sentinelAddressList = Arrays.asList(StringUtils.split(sentinelAddresses, ','));
    }

    @Override
    public void validate() {
        super.validate();

        if(StringUtils.isEmpty(masterName)) {
            throw  new IllegalArgumentException("sentinel master name必须设置");
        }

        if(CollectionUtils.isEmpty(sentinelAddressList)) {
            throw  new IllegalArgumentException("sentinel address列表必须设置");
        }
    }

    @Override
    public String toString() {
        return "SentinelConfig{" +
                "masterName='" + masterName + '\'' +
                ", sentinelAddresses=" + sentinelAddresses +
                '}';
    }
}
