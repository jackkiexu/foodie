//package com.zb.framework.cache.redis.connection;
//
//import org.springframework.beans.factory.DisposableBean;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.dao.DataAccessException;
//import org.springframework.data.redis.ExceptionTranslationStrategy;
//import org.springframework.data.redis.PassThroughExceptionTranslationStrategy;
//import org.springframework.data.redis.RedisConnectionFailureException;
//import org.springframework.data.redis.connection.RedisConnection;
//import org.springframework.data.redis.connection.RedisConnectionFactory;
//import org.springframework.data.redis.connection.RedisSentinelConnection;
//import org.springframework.data.redis.connection.jedis.JedisConverters;
//import redis.clients.jedis.JedisPoolConfig;
//import redis.clients.jedis.JedisShardInfo;
//import redis.clients.jedis.ShardedJedis;
//import redis.clients.jedis.ShardedJedisPool;
//import redis.clients.util.Pool;
//
//import java.util.List;
//
///**
// * Created by  2015/2/4.
// */
//public abstract class ShardedJedisConnectionFactory implements InitializingBean, DisposableBean, RedisConnectionFactory {
//    private static final ExceptionTranslationStrategy EXCEPTION_TRANSLATION = new PassThroughExceptionTranslationStrategy(
//            JedisConverters.exceptionConverter());
//
//    /**
//     * 服务器列表<br/>
//     *
//     */
//    private List<JedisShardInfo> shardInfoList = null;
//
//    /**
//     * Jedis pool配置<br/>
//     *
//     */
//    private JedisPoolConfig poolConfig = new JedisPoolConfig();
//
//    /**
//     * Jedis pool实例<br/>
//     *
//     */
//    private Pool<ShardedJedis> pool = null;
//
//    @Override
//    public RedisConnection getConnection() {
//        try {
//            ShardedJedisConnection connection = new ShardedJedisConnection(pool.getResource(), pool, 0);
//            return postProcessConnection(connection);
//        } catch (Exception ex) {
//            throw new RedisConnectionFailureException("Cannot get Jedis connection", ex);
//        }
//    }
//
//    protected RedisConnection postProcessConnection(RedisConnection connection) {
//        return connection;
//    }
//
//    @Override
//    public boolean getConvertPipelineAndTxResults() {
//        throw new UnsupportedOperationException("Sharding不支持Pipeline");
//    }
//
//    @Override
//    public RedisSentinelConnection getSentinelConnection() {
//        throw new UnsupportedOperationException("Sharding不支持Sentinel");
//    }
//
//    @Override
//    public DataAccessException translateExceptionIfPossible(RuntimeException ex) {
//        return EXCEPTION_TRANSLATION.translate(ex);
//    }
//
//    @Override
//    public void afterPropertiesSet() throws Exception {
//        if(shardInfoList == null || shardInfoList.isEmpty()) {
//            throw new IllegalArgumentException("没有配置Sharding的服务器列表");
//        }
//
//        this.pool = createPool();
//    }
//
//    private Pool<ShardedJedis> createPool() {
//        return new ShardedJedisPool(poolConfig, shardInfoList);
//    }
//
//    @Override
//    public void destroy() throws Exception {
//        try {
//            pool.destroy();
//        } catch (Exception e) {
//            // ignore
//        }
//    }
//}
