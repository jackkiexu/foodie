package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * TA交易状态<br/>
 *
 * Created by  2015/1/30.
 */
public final class TaTradeStatus extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = 2923592911311858589L;

    public static final TaTradeStatus Y = new TaTradeStatus("Y", "交易成功");

    public static final TaTradeStatus I = new TaTradeStatus("I", "交易处理中");

    public static final TaTradeStatus E = new TaTradeStatus("E", "交易异常");

    public static final TaTradeStatus F = new TaTradeStatus("F", "交易失败");

    protected TaTradeStatus() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    protected TaTradeStatus(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return TaTradeStatus.class;
    }
}
