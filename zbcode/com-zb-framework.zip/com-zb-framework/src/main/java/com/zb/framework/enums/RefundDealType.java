/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 *
 */
public final class RefundDealType extends AbstractEnum implements Serializable{

    /**
     * 关联tcs_refund_order status
     */
    public static final RefundDealType AUTO_DEAL = new RefundDealType("01","自动处理");
    public static final RefundDealType MANUAL_DEAL = new RefundDealType("02","人工处理");

    protected RefundDealType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected RefundDealType(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return RefundDealType.class;
    }
}
