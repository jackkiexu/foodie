package com.zb.framework.serialize;

import com.zb.framework.enums.BizCode;
import com.zb.framework.util.CoreCommonUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * 序列化与反序列化的Java实现<br/>
 *
 * Created by  2015/1/13.
 */
public class JavaSerializer extends AbstractSerializer implements Serializer {
    @Override
    protected byte[] doSerialize(Serializable object) {
        ObjectOutputStream out = null;
        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(128);
            out = new ObjectOutputStream(buffer);

            out.writeObject(object);
            out.flush();
            out.close();

            byte[] bytes = buffer.toByteArray();

            return bytes;
        } catch (IOException e) {
            CoreCommonUtils.raiseBizException(BizCode.IO_Error, "序列化异常", e);

            // 不会执行的代码!!
            return null;
        } finally {
            closeQuietly(out);
        }
    }

    @Override
    protected Serializable doDeserialize(byte[] bin) {
        ObjectInputStream in = null;
        try {
            ByteArrayInputStream buffer = new ByteArrayInputStream(bin);
            in = new ObjectInputStream(buffer);

            Object obj = in.readObject();
            in.close();

            return (Serializable)obj;
        } catch (Exception e) {
            CoreCommonUtils.raiseBizException(BizCode.IO_Error, "反序列化异常", e);

            // 不会执行的代码!!
            return null;
        } finally {
            closeQuietly(in);
        }
    }

    private static void closeQuietly(Closeable io) {
        if(io != null) {
            try {
                io.close();
            } catch (IOException e) {
                ;
            }
        }
    }
}
