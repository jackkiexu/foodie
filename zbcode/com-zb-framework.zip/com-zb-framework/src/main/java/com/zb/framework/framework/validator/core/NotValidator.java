package com.zb.framework.framework.validator.core;

import com.zb.framework.framework.validator.Validator;
import com.zb.framework.framework.validator.base.AbstractValidator;

/**
 * not验证器<br/>
 *
 * Created by  2014/12/15.
 */
public class NotValidator extends AbstractValidator implements Validator {
    /**
     * 实际的验证器<br/>
     *
     */
    private Validator innerValidator = null;

    public NotValidator(Validator innerValidator) {
        super(null);
        this.innerValidator = innerValidator;
    }

    @Override
    public boolean doValidate(Object value) {
        boolean isSuccess = true;

        try {
            innerValidator.validate(value);
        } catch (Exception e) {
            isSuccess = false;
        }
        return !(isSuccess);
    }
}
