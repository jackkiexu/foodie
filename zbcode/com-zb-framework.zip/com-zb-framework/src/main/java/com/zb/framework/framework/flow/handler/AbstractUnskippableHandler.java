package com.zb.framework.framework.flow.handler;

import com.zb.framework.enums.BizCode;
import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.util.CoreCommonUtils;

/**
 * 默认不跳过的处理器基类<br/>
 *
 * Created by  2014/12/14.
 */
public abstract class AbstractUnskippableHandler extends AbstractHandler implements Handler {
    @Override
    public final boolean isSkippable(Context context) {
        return forceSkippable(context) ? super.isSkippable(context) : false;
    }

    /**
     * 默认情况下是不能跳过的，但是特殊的逻辑需要跳过功能，因此增加一个可选项让用户配置；<br/>
     *
     * @param context
     * @return
     */
    protected boolean forceSkippable(Context context) {
        return false;
    }

    @Override
    protected void doRecover(Context context) {
        if(!forceSkippable(context)) {
            CoreCommonUtils.raiseBizException(BizCode.UnsupportedOperation, "不支持恢复操作");
        }
    }
}
