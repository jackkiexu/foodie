package com.zb.framework.util;

import com.zb.framework.enums.BizCode;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;

/**
 * 线程TLS工具类<br/>
 *
 * Created by  2014/12/17.
 */
public abstract class CoreThreadLocalUtils {
    /**
     * 一个标识符，没有特殊意义<br/>
     *
     */
    private static final Object __tag = new Object();

    /**
     * 当前线程是否初始化的标识符<br/>
     *
     */
    private static final ThreadLocal<Object> __flag__ = new ThreadLocal<Object>() {
        @Override
        protected Object initialValue() {
            return null;
        }
    };

    /**
     * 当前线程独有的上下文对象<br/>
     *
     */
    private static final ThreadLocal<TLSVo> context = new ThreadLocal<TLSVo>() {
        @Override
        protected TLSVo initialValue() {
            return null;
        }
    };

    private CoreThreadLocalUtils() {
        ;//nothing.
    }

    /**
     * 判断TLS是否已经初始化，如果父线程已经初始化，则子线程默认初始化<br/>
     *
     * @return
     */
    public static boolean isInitialized() {
        return __flag__.get() != null/* || isInSubThread()*/;
    }

    /**
     * 判断是否在已经初始化上下文的子线程中<br/>
     *
     * @return
     */
    /*public static boolean isInSubThread() {
        TLSVo vo = context.get();
        long currThreadId = Thread.currentThread().getId();
        if(vo != null // 上下文对象已经继承（从父线程复制过来的）
                // 但是线程Id与主线程不一致
                && vo.getThreadId() != currThreadId) {
            return true;
        }

        return false;
    }*/

    /**
     * 初始化调用上下文<br/>
     *
     * NOTE：必须在try finally中使用清理TLS<br/>
     * <pre>
     *     boolean isNew = false;
     *     try{
     *          isNew = CoreThreadLocalUtils.initialize();
     *
     *         // 调用的业务；
     *     } finally {
     *         CoreThreadLocalUtils.clear(isNew);
     *     }
     * </pre>
     *
     * @param attachObjectClass TLS中用户自定义对象事例类型，用于存放用户自定义数据
     * @return
     */
    public static boolean initialize(Class<?> attachObjectClass) {
        // 为了避免用户初始化TLS后，在使用完TLS未对其清理的情况（例如thread pool中的线程）
        // 再次使用这个TLS时，提示异常
        // TODO: 目前没有技术防止TLS不清理的误操作！！

        /*if(isInSubThread()){ // 子线程直接复制内容
            return true; // 子线程虽然不需要初始化，但是可以对线程中的数据进行清理！！
        }*/

        if(isInitialized()) { // 如果是当前线程的，则返回初始化失败
            return false;
        }

        // 设置当前上下文已经初始化标志！！
        __flag__.set(__tag);

        TLSVo vo = new TLSVo();
        vo.setThreadId(Thread.currentThread().getId());
        vo.setThreadName(Thread.currentThread().getName());

        // 构造用户自定义实例对象
        if(attachObjectClass != null) {
            vo.setAttachObject(CoreObjectUtils.newInstance(attachObjectClass));
        }

        context.set(vo);

        return true;
    }

    /**
     * 清理TLS内容<br/>
     *
     * @param isNew
     */
    public static void clean(boolean isNew) {
        if(isNew) { // 对于继承的子线程，也可以对齐数据进行清理
            __flag__.remove();

            TLSVo vo = context.get();
            context.remove();

            // 如果未初始化TLS，则忽略清理操作
            if(null == vo) {
                return;
            }

            // 如果是非子线程，则需要标记TLS已经清理
            // 主要是避免在子线程未清理TLS的情况下，导致thread pool中的TLS被重复使用
            // TODO: 主线程为清理TLS的情况，目前还没有技术可以避免；
            /*if(!isInSubThread()) {
                vo.setCleared(true);
            }*/

            // 清理Metrics信息；
            CoreMetricsUtils.clear();
        }
    }

    /**
     * 获取TLS值<br/>
     *
     * @return
     */
    public static TLSVo value() {
        if (isInitialized()) {
            TLSVo vo = context.get();

            if (vo == null) { // 未初始化则提示异常
                CoreCommonUtils.raiseBizException(BizCode.UnsupportedOperation, "TLS未初始化");
            }

            return vo;
        }

        CoreCommonUtils.raiseBizException(BizCode.UnsupportedOperation, "TLS未初始化");

        // 不会执行的代码！！
        return null;
    }

    /**
     * 获取TLS日志前缀<br/>
     *
     * @return
     */
    public static String logPrefix() {
        /*if(!isInitialized()) {
            CoreCommonUtils.raiseBizException(BizCode.UnsupportedOperation, "TLS未初始化");
        }

        return "<uuid=" + value().getGuid() + ">";*/

        return StringUtils.EMPTY;
    }
    /**
     * 线程上下文对象<br/>
     *
     */
    public static class TLSVo {
        /**
         * 唯一标识符<br/>
         *
         */
        private String guid = null;

        /**
         * 主进程线程名称<br/>
         *
         */
        private String threadName = null;

        /**
         * 主进程id<br/>
         *
         */
        private long threadId = -1;

        /**
         * 服务调用的起始时间<br/>
         *
         */
        private long startTime = -1L;

        /**
         * 是否已经清理<br/>
         *
         */
        private boolean cleared = false;

        /**
         * 用户自定义对象<br/>
         *
         */
        private Object attachObject = null;

        public TLSVo() {
            startTime = System.currentTimeMillis();

            guid = UUID.randomUUID().toString();
        }

        public String getGuid() {
            return guid;
        }

        void setGuid(String guid) {
            this.guid = guid;
        }

        public String getThreadName() {
            return threadName;
        }

        void setThreadName(String threadName) {
            this.threadName = threadName;
        }

        public long getThreadId() {
            return threadId;
        }

        void setThreadId(long threadId) {
            this.threadId = threadId;
        }

        public long getStartTime() {
            return startTime;
        }

        void setStartTime(long startTime) {
            this.startTime = startTime;
        }

        public boolean isCleared() {
            return cleared;
        }

        void setCleared(boolean cleared) {
            this.cleared = cleared;
        }

        public Object getAttachObject() {
            return attachObject;
        }

        public <T> T attacheObject() {
            return (T)attachObject;
        }

        void setAttachObject(Object attachObject) {
            this.attachObject = attachObject;
        }
    }
}
