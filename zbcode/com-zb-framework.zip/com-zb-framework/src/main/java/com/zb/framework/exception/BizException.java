package com.zb.framework.exception;

import com.zb.framework.base.BaseException;
import com.zb.framework.enums.BizCode;

import java.io.Serializable;

/**
 * 应用业务运行时异常，只能用于服务内部，不能将此异常传递到调用服务方<br/>
 *
 * Created by  2014/12/10.
 */
public class BizException extends BaseException implements Serializable {
    private static final long serialVersionUID = 4350868573071491642L;

    public BizException() {
        super();
    }

    public BizException(BizCode code, String message) {
        super(code, message);
    }

    public BizException(BizCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public BizException(BizCode code, Throwable cause) {
        super(code, cause);
    }

    public BizException(boolean ignoreStackTrace) {
        super(ignoreStackTrace);
    }

    public BizException(BizCode code, String message, boolean ignoreStackTrace) {
        super(code, message, ignoreStackTrace);
    }

    public BizException(BizCode code, String message, Throwable cause, boolean ignoreStackTrace) {
        super(code, message, cause, ignoreStackTrace);
    }

    public BizException(BizCode code, Throwable cause, boolean ignoreStackTrace) {
        super(code, cause, ignoreStackTrace);
    }
}
