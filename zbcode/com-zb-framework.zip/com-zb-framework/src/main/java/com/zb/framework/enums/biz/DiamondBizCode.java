/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 
 * @author 
 * @version $Id: DiamondRspCode.java, v 0.1 2015年5月12日 下午8:35:49  Exp $
 */
public class DiamondBizCode extends BizCode{

    /**  */
    private static final long serialVersionUID = -2777788471684326439L;

    public static final DiamondBizCode Diamond_CharSetError=new DiamondBizCode("Diamond_CharSetError",ServiceCode.Diamond,"001","字符集不正确"); 
    
    public static final DiamondBizCode Diamond_DbError=new DiamondBizCode("Diamond_DbError",ServiceCode.Diamond,"002","数据库操作异常"); 
    
    public static final DiamondBizCode Diamond_FileIOError=new DiamondBizCode("Diamond_FileIOError",ServiceCode.Diamond,"003","文件操作异常"); 
    
    public static final DiamondBizCode Diamond_ParamCheckErr=new DiamondBizCode("Diamond_ParamCheckErr",ServiceCode.Diamond,"004","参数校验出错"); 
    
    public static final DiamondBizCode Diamond_FileUpdated=new DiamondBizCode("Diamond_FileUpdated",ServiceCode.Diamond,"005","文件已经存在");
    
    public static final DiamondBizCode Diamond_Unkown=new DiamondBizCode("Diamond_Unkown",ServiceCode.Diamond,"999","字符集不正确"); 
    
    protected DiamondBizCode(String name, ServiceCode serviceCode, String code,
                            String desc) {
                        super(name, serviceCode, code, desc);
                    }
                    
    protected DiamondBizCode() {

                    }
}
