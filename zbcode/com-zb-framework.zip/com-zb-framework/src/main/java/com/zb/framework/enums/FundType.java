package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 基金类型<br/>
 *
 * Created by  2015/1/9.
 */
public final class FundType extends AbstractCodedEnum implements Serializable {
    public static final FundType Financing = new FundType("Financing", "0", "理财基金");

    public static final FundType Stock = new FundType("Stock", "1", "股票类基金");

    public static final FundType Mix = new FundType("Mix", "2", "混合基金");

    public static final FundType QDII = new FundType("QDII", "3", "海外基金");

    public static final FundType Index = new FundType("Index", "4", "指数基金");

    public static final FundType Bond = new FundType("Bond", "5", "债券基金");

    public static final FundType Currency = new FundType("Currency", "6", "货币基金");

    public static final FundType Grade = new FundType("Graded", "7", "分级基金");

    private static final long serialVersionUID = -1748450951973828853L;

    protected FundType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected FundType(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return FundType.class;
    }
}
