/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.config;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by  2015/5/6.
 */
public class MasterSlaveConfig extends MultiConfig {
    /**
     * master服务器地址<br/>
     *
     */
    private String masterAddress = null;

    /**
     * 可用的slave服务器地址列表<br/>
     *
     */
    private String slaveAddresses = null;

    private List<String> slaveAddressList = new ArrayList<>();

    public String getMasterAddress() {
        return masterAddress;
    }

    public void setMasterAddress(String masterAddress) {
        this.masterAddress = masterAddress;
    }

    public List<String> getSlaveAddressList() {
        return slaveAddressList;
    }

    /**
     * slave服务器列表，多个服务使用“,”分割，服务器地址格式：ip:port，例如：172.16.150.111:6379<br/>
     *
     * @param slaveAddresses
     */
    public void setSlaveAddresses(String slaveAddresses) {
        if(StringUtils.isEmpty(slaveAddresses)) {
            throw  new IllegalArgumentException("slave address列表必须设置");
        }

        this.slaveAddresses = slaveAddresses;
        this.slaveAddressList = Arrays.asList(StringUtils.split(slaveAddresses, ','));
    }

    @Override
    public void validate() {
        super.validate();

        if(StringUtils.isEmpty(masterAddress)) {
            throw new IllegalArgumentException("master服务器信息必须设置");
        }
    }

    @Override
    public String toString() {
        return "MasterSlaveConfig{" +
                "masterAddress='" + masterAddress + '\'' +
                ", slaveAddresses=" + slaveAddresses +
                '}';
    }
}
