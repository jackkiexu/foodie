package com.zb.framework.framework.flow;

import com.zb.framework.base.AbstractRequest;
import com.zb.framework.base.AbstractResponse;
import com.zb.framework.framework.flow.context.AbstractContext;

/**
 * Pipe line属性访问器<br/>
 *
 * Created by  2014/12/10.
 */
public interface OutboundProperty {
    /**
     * 获取当前工作chain的执行上下文<br/>
     *
     * @return
     */
    AbstractContext getContext();

    /**
     * 获取当前工作chain的类型转换器<br/>
     *
     * @return
     */
    Converter<? extends AbstractContext
            , ? extends AbstractRequest, ? extends AbstractResponse> getConverter();
}
