///**
// * 
// *
// * Copyright (c) 2014-2015 All Rights Reserved.
// */
//package com.zb.framework.scheduler.support;
//
//import com.zb.framework.scheduler.BatchJob;
//import com.taobao.pamirs.schedule.IScheduleTaskDealMulti;
//
//import java.util.Arrays;
//
///**
// * Created by  2015/4/21.
// */
//public abstract class AbstractBatchJob<T> extends AbstractJobBase<T> implements BatchJob<T>, IScheduleTaskDealMulti<T> {
//    @Override
//    public final boolean execute(T[] tasks,String ownSign) throws Exception {
//        return process(Arrays.asList(tasks), getContext());
//    }
//}
