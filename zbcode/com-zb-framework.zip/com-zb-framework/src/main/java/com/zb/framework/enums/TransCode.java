package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 交易码<br/>
 *
 * Created by  2014/12/27.
 */
public final class TransCode extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = 3434942520461036786L;

    public static final TransCode PURCHASE
            = new TransCode("PURCHASE", "001", "申购");

    public static final TransCode SUBSCRIBE
            = new TransCode("SUBSCRIBE", "002", "认购");

    public static final TransCode REDEEM
            = new TransCode("REDEEM", "003", "赎回");

    public static final TransCode TRANSFER
            = new TransCode("TRANSFER", "004", "转账");

    public static final TransCode PAY
            = new TransCode("PAY", "005", "支付");

    public static final TransCode CONVERT
            = new TransCode("CONVERT", "006", "转换");

    public static final TransCode EXCHANGE
            = new TransCode("EXCHANGE", "007", "转让");

    public static final TransCode CANCEL
            = new TransCode("CANCEL", "008", "撤单");

    public static final TransCode MELON
            = new TransCode("MELON", "009", "分红");

    public static final TransCode AUTO
            = new TransCode("AUTO", "010", "自动后台交易");

    public static final TransCode MANIPULATE
            = new TransCode("MANIPULATE", "011", "控制类交易");
    /**
     * 基金定投（automatic investment plan （AIP））
     */
    public static final TransCode AIP
            = new TransCode("AIP", "012", "定投");

    protected TransCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected TransCode(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return TransCode.class;
    }
}
