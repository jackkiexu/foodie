/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 
 * @author 
 * @version $Id: BcmBizCode.java, v 0.1 2015年5月23日 下午4:41:08  Exp $
 */
public class BcmBizCode extends BizCode implements Serializable{

    /**  */
    private static final long serialVersionUID = 5761171592446932138L;
    
    public static final BcmBizCode Bcm_CacheRefresh_Fail=new BcmBizCode("Bcm_CacheRefresh_Fail",ServiceCode.BCM,"001","缓存刷新失败");

    protected BcmBizCode() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    public BcmBizCode(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }
}
