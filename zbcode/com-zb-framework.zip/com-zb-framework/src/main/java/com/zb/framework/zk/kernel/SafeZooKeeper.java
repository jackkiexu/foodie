/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.kernel;

import com.zb.framework.enums.BizCode;
import com.zb.framework.zk.event.NodeChangeListener;
import com.zb.framework.zk.event.SessionEvent;
import com.zb.framework.zk.event.SessionListener;
import com.zb.framework.zk.util.ZooKeeperException;
import org.apache.commons.lang3.StringUtils;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 安全可靠的zk实例<br/>
 *
 * Created by  2015/4/28.
 */
public final class SafeZooKeeper implements com.zb.framework.zk.SafeZooKeeper,  SessionListener {
    private static final Logger LOG = LoggerFactory.getLogger(SafeZooKeeper.class);

    private static enum LockFlag {
        Lock, Unlock, LockResp;
    }

    private ReadWriteLock lock = null;

    /**
     * 只读锁<br/>
     *
     */
    private Lock readLock = null;

    /**
     * 读写锁<br/>
     *
     */
    private Lock writeLock = null;

    AsyncWriteLock writeLockHandler = null;

    /**
     * zk初始化管理器<br/>
     *
     * @param initializer
     */
    private ZooKeeperInitializer initializer = null;

    SafeZooKeeper(ZooKeeperInitializer initializer) {
        this.initializer = initializer;

        // 并发锁；
        lock = new ReentrantReadWriteLock(true); // write lock higher!!
        readLock = lock.readLock();
        writeLock = lock.writeLock();

        // 后台write lock实现；
        writeLockHandler = new AsyncWriteLock();
        writeLockHandler.start();

        // 为了避免在未连接zookeeper的情况下操作zk，必须先加锁；
        writeLockHandler.lock();
    }

    // ------------------------------------- 事件接口；
    public void addSessionListener(SessionListener listener) {
        initializer.multicaster.addSessionListener(listener);
    }

    /**
     * 添加一次性节点事件<br/>
     *
     * @param path
     * @param listener
     */
    public void addChangeListener(String path, NodeChangeListener listener) {
        try {
            exists(path, true);
            getData(path, true, null);
            getChildren(path, true);
            initializer.multicaster.addChangeListener(path, listener, false);
        } catch (ZooKeeperException e) {
            LOG.warn("add zk change listener ex", e);
        }
    }

    /**
     * 添加永久性节点事件<br/>
     *
     * @param path
     * @param listener
     */
    public void addPermanentChangeListener(String path, NodeChangeListener listener) {
        try {
            exists(path, true);
            getData(path, true, null);
            getChildren(path, true);
            initializer.multicaster.addChangeListener(path, listener, true);
        } catch (ZooKeeperException e) {
            LOG.warn("add zk change listener ex", e);
        }
    }

    // ------------------------------------- operation接口；
    public void create(String path, byte data[], CreateMode createMode) throws ZooKeeperException {
        try {
            readLock.lock();
            initializer.zk.create(path, data, initializer.acl, createMode);

            LOG.info("zk create success: " + path);
        } catch (Exception e) {
            throw new ZooKeeperException(BizCode.Unknown, "zk create ex, path = " + path, e);
        } finally {
            readLock.unlock();
        }
    }

    public void createRecursive(String path, byte data[], CreateMode createMode) throws ZooKeeperException {
        try {
            readLock.lock();
            final String[] paths = path.split("/");
            String curr = StringUtils.EMPTY;
            for(String p : paths) {
                curr += StringUtils.isEmpty(p) ? "" : "/" + p;
                if(curr.equals(path)) {
                    create(path, data, createMode);
                } else if(StringUtils.isNotEmpty(p) && exists(curr, false) == null) {
                    create(curr, null, createMode);
                }
            }
        } catch (Exception e) {
            throw new ZooKeeperException(BizCode.Unknown, "zk create ex, path = " + path, e);
        } finally {
            readLock.unlock();
        }
    }

    public Stat exists(String path, boolean watch) throws ZooKeeperException {
        try {
            readLock.lock();

            return initializer.zk.exists(path, watch);
        } catch (Exception e) {
            throw new ZooKeeperException(BizCode.Unknown, "zk exists ex, path = " + path, e);
        } finally {
            readLock.unlock();
        }
    }

    public byte[] getData(String path, boolean watch, Stat stat) throws ZooKeeperException {
        try {
            readLock.lock();

            return initializer.zk.getData(path, watch, stat);
        } catch (Exception e) {
            throw new ZooKeeperException(BizCode.Unknown, "zk get node data ex, path = " + path, e);
        } finally {
            readLock.unlock();
        }
    }

    public List<String> getChildren(String path, boolean watch) throws ZooKeeperException {
        try {
            readLock.lock();

            return initializer.zk.getChildren(path, watch);
        } catch (Exception e) {
            throw new ZooKeeperException(BizCode.Unknown, "zk get children ex, path = " + path, e);
        } finally {
            readLock.unlock();
        }
    }

    public List<String> getChildren(String path, boolean watch, Stat stat) throws ZooKeeperException {
        try {
            readLock.lock();

            return initializer.zk.getChildren(path, watch, stat);
        } catch (Exception e) {
            throw new ZooKeeperException(BizCode.Unknown, "zk get children ex, path = " + path, e);
        } finally {
            readLock.unlock();
        }
    }

    public void delete(final String path, int version) throws ZooKeeperException {
        try {
            readLock.lock();

            initializer.zk.delete(path, version);
        } catch (Exception e) {
            throw new ZooKeeperException(BizCode.Unknown, "zk delete ex, path = " + path, e);
        } finally {
            readLock.unlock();
        }
    }

    public void deleteAll(final String path) throws ZooKeeperException {
        try {
            readLock.lock();

            initializer.zk.delete(path, -1);
        } catch (Exception e) {
            throw new ZooKeeperException(BizCode.Unknown, "zk delete ex, path = " + path, e);
        } finally {
            readLock.unlock();
        }
    }

    @Override
    public Stat setData(String path, byte[] data, int version) throws ZooKeeperException {
        try {
            readLock.lock();

            return initializer.zk.setData(path, data, version);
        } catch (Exception e) {
            throw new ZooKeeperException(BizCode.Unknown, "zk set data ex, path = " + path, e);
        } finally {
            readLock.unlock();
        }
    }

    // ------------------------------------- session事件；

    @Override
    public void onDisconnected(SessionEvent event) {
        LOG.info("与zk失去连接，等待zk自动连接.");
    }

    @Override
    public void onConnected(SessionEvent event) {
        LOG.info("重新连接zk成功.");
    }

    @Override
    public void onExpired(SessionEvent event) {
        LOG.info("与zk重新连接，session expired.");

        // 重新注册所有事件；
        final Queue<SessionListener> sessionListeners = initializer.multicaster.sessionListeners;
        for(SessionListener s : sessionListeners) {
            this.addSessionListener(s);
        }

        final Map<String, Queue<EventMulticaster.ListenerNode>> changeListeners
                = initializer.multicaster.changeListeners;
        for(Map.Entry<String, Queue<EventMulticaster.ListenerNode>> entry : changeListeners.entrySet()) {
            for(EventMulticaster.ListenerNode node : entry.getValue()) {
                if(node.permanent) {
                    this.addPermanentChangeListener(node.path, node.listener);
                } else {
                    this.addChangeListener(node.path, node.listener);
                }
            }
        }
    }

    // ------------------------------------- async write lock；
    class AsyncWriteLock extends Thread {
        private BlockingDeque<LockFlag> queue = new LinkedBlockingDeque<>(1); // one to one;
        private BlockingDeque<LockFlag> queue2 = new LinkedBlockingDeque<>(1); // one to one;
        private BlockingDeque<LockFlag> wait = new LinkedBlockingDeque<>(1);
        private boolean locked = false;

        public void lock() {

            try {
                queue.put(LockFlag.Lock);
                queue2.put(LockFlag.Lock);
                wait.take(); // blocking;
            } catch (InterruptedException e) {
                //
            }
        }

        public void unlock() {

            try {
                queue.put(LockFlag.Unlock);
                queue2.put(LockFlag.Unlock);
                wait.take(); // blocking;
            } catch (InterruptedException e) {
                //
            }
        }

        @Override
        public void run() {
            while(true) {

                try {
                    final LockFlag flag = queue2.take(); // waiting request;
                    if(flag == LockFlag.Lock && !locked) {
                        writeLock.lock();
                        locked = true;

                        if(LOG.isDebugEnabled()) {
                            LOG.info("writeLock lock success");
                        }
                    } else if(flag == LockFlag.Unlock && locked) {
                        writeLock.unlock();
                        locked = false;

                        if(LOG.isDebugEnabled()) {
                            LOG.info("writeLock unlock success");
                        }
                    } // else will ignore;

                    wait.put(LockFlag.LockResp); // notify lock & unlock threading;
                    queue.poll(); // receive new request;
                } catch (Exception e) {
                    LOG.info("async write lock ex", e);
                }
            }
        }
    }
}
