/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.util;

import com.zb.framework.base.BaseCheckedException;
import com.zb.framework.base.BaseException;
import com.zb.framework.enums.BizCode;

/**
 * Created by  2015/4/28.
 */
public class ZooKeeperException extends BaseCheckedException {
    public ZooKeeperException() {
        super();
    }

    public ZooKeeperException(BizCode code, String message) {
        super(code, message);
    }

    public ZooKeeperException(BizCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public ZooKeeperException(BizCode code, Throwable cause) {
        super(code, cause);
    }
}
