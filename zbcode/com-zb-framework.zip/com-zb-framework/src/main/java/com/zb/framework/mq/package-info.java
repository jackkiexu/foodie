/**
 * MQ相关<br/>
 *
 * Created by  2015/1/13.
 */
package com.zb.framework.mq;