package com.zb.framework.framework.pigeon.template;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.zb.framework.framework.pigeon.xmap.annotation.XNode;
import com.zb.framework.framework.pigeon.xmap.annotation.XNodeList;
import com.zb.framework.framework.pigeon.xmap.annotation.XObject;

@XObject
public class ProcessDescriptor {

	@XNode("@type")
	private String type;

	@XNode("@name")
	private String name;

	@XNodeList(value = "action", type = ArrayList.class, componentType = ActionDescriptor.class)
	private List<ActionDescriptor> action;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<ActionDescriptor> getAction() {
		return action;
	}

	public void setAction(List<ActionDescriptor> action) {
		this.action = action;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

/*	public Object getActionBeanByName(String name) {
		for (Iterator iterator = this.action.iterator(); iterator.hasNext();) {
			ActionDescriptor action = (ActionDescriptor) iterator.next();
			if (name.equals(action.name)) {
				return action.getBean();
			}
		}

		return null;
	}*/

	 public String toString() {
	        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	    }
}
