/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import java.io.Serializable;

import com.zb.framework.base.AbstractEnum;

/**
 * 冻结资金到期处理方式
 * @author 
 * @version $Id: HoldExpProcModCode.java, v 0.1 2015年1月20日 下午3:28:07  Exp $
 */
public final class HoldExpProcModCode extends AbstractEnum implements Serializable{
    
    

    /**  */
    private static final long serialVersionUID = -3791172022654401801L;
    
    public static final HoldExpProcModCode release=new HoldExpProcModCode("0","到期释放");
    
    public static final HoldExpProcModCode unrelease=new HoldExpProcModCode("1","到期不释放");
    
    protected HoldExpProcModCode(){
        ;
    }
    
    
    protected HoldExpProcModCode(String code,String desc){
        super(code,desc);
    }

    /** 
     * @see com.zb.framework.base.AbstractEnum#getEnumType()
     */
    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return HoldExpProcModCode.class;
    }

}
