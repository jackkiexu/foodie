package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 交易标识<br/>
 *
 * Created by  2015/1/19.
 */
public class TransFlag extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = -3026533389766635686L;

    public static final TransFlag Normal = new TransFlag("N", "正常交易");

    public static final TransFlag Cancel = new TransFlag("C", "撤单交易");

    public static final TransFlag Reverse = new TransFlag("R", "冲正交易");

    public static final TransFlag Refund = new TransFlag("T", "退款交易");

    protected TransFlag() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected TransFlag(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return TransFlag.class;
    }
}
