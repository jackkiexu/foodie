///**
// * 
// *
// * Copyright (c) 2014-2015 All Rights Reserved.
// */
//package com.zb.framework.lock.mutex;
//
//import com.zb.framework.enums.BizCode;
//import com.zb.framework.exception.BizException;
//import com.zb.framework.lock.LockClient;
//import com.zb.framework.lock.LockFailException;
//import com.zb.framework.lock.vo.CuratorConfig;
//import com.zb.framework.util.CoreCommonUtils;
//import com.zb.framework.util.CoreSpringUtils;
//import org.apache.curator.framework.recipes.locks.InterProcessMutex;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.stereotype.Service;
//
//import java.util.concurrent.TimeUnit;
//
///**
// * zk分布式锁客户端
// * 集成该包需要配置 bean 参见
// * qiangungun\common\core-common\src\test\resources\spring\spring-core-lock.xml
// * Created by  on 2015/9/8.
// */
//public class CuratorDistrLock implements InitializingBean {
//
//    private static final Logger logger = LoggerFactory.getLogger(CuratorDistrLock.class);
//
//    private static String basePath = "/app/lock/";
//
//    private CuratorConfig config = new CuratorConfig();
//
//    static {
//        ;
//    }
//
//    public<T> T acquire(String path,long time,TimeUnit unit,LockCallBack<T> callback){
//        InterProcessMutex lock = new InterProcessMutex(LockClient.getCurator(config), basePath + path);
//        try {
//
//            if (lock.acquire(time, unit)) {
//                logger.debug(Thread.currentThread().getName() + " get lock");
//                return callback.doInLock();
//            }else{
//                throw new LockFailException(BizCode.Unknown,"Get lock fail.");
//            }
//        } catch (LockFailException lfe){
//            throw lfe;
//        } catch (Exception e) {
//            CoreCommonUtils.raiseRuntimeException(e);
//        } finally {
//            try {
//                lock.release();
//            }catch (IllegalMonitorStateException ise){
//
//            }catch (Exception e) {
//                logger.warn(Thread.currentThread().getName() + " relase lock fail", e);
//            }
//        }
//        return null;
//    }
//
//    @Override
//    public void afterPropertiesSet() throws Exception {
//        CoreSpringUtils.autowire(config);
//    }
//}
