/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.container;

import com.zb.framework.algorithm.hash.consistent.BucketNode;
import org.redisson.Redisson;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by  2015/5/6.
 */
public class RedisNode implements BucketNode {
    private static final AtomicInteger INDEX = new AtomicInteger(0);
    public static final String SEPARATOR = "-";

    private String address = null;

    private Redisson client = null;

    private String groupName = null;

    private int index = 0;

    public RedisNode(String address, String groupName, Redisson client) {
        this.address = address;
        this.client = client;
        this.groupName = groupName;
        setIndex(INDEX.incrementAndGet());
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Redisson getClient() {
        return client;
    }

    public void setClient(Redisson client) {
        this.client = client;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    @Override
    public String getBucketKey() {
        return groupName + SEPARATOR + index + SEPARATOR + address;
    }
}
