/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 
 * @author 
 * @version $Id: DecisionBizCode.java, v 0.1 2015年6月3日 下午3:06:08  Exp $
 */
public class DecisionBizCode extends BizCode{
    
    
    
    /**  */
    private static final long serialVersionUID = -7300647314222624899L;
    
    public static final DecisionBizCode DecisionCacheRefreshFail=new DecisionBizCode("DecisionCacheRefreshFail",ServiceCode.Decision,"001","缓存刷新失败");

    public static final DecisionBizCode DecisionParamIsNull=new DecisionBizCode("DecisionParamIsNull",ServiceCode.Decision,"002","参数为空");
    
    public static final DecisionBizCode DecisionInvokeRouterFail=new DecisionBizCode("DecisionInvokeRouterFail",ServiceCode.Decision,"003","调用路由异常");

    public static final DecisionBizCode DecisionResultEmpty=new DecisionBizCode("DecisionResultEmpty",ServiceCode.Decision,"004","支付决策结果为空");

    public static final DecisionBizCode DecisionFindSignInfoFail=new DecisionBizCode("DecisionFindSignInfoFail",ServiceCode.Decision,"005","查询会员签约签约信息失败");

    public static final DecisionBizCode DecisionGetPrdRateFail=new DecisionBizCode("DecisionGetPrdRateFail",ServiceCode.Decision,"006","获取产品费率失败");

    
    public static final DecisionBizCode DecisionUnkown=new DecisionBizCode("DecisionUnkown",ServiceCode.Decision,"999","未知异常");

    
    protected DecisionBizCode() {
        ;
    }
    
    /**
     * @param name
     * @param service
     * @param code
     * @param desc
     */
    public DecisionBizCode(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }

}
