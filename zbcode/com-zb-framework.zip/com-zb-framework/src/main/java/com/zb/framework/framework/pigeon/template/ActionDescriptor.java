package com.zb.framework.framework.pigeon.template;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.zb.framework.framework.pigeon.xmap.annotation.XNode;
import com.zb.framework.framework.pigeon.xmap.annotation.XObject;

@XObject
public class ActionDescriptor {

	@XNode("@name")
	String name;
	@XNode("@desc")
	String desc;

	@XNode(value = "@bean")
	private String bean;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getBean() {
		return bean;
	}

	public void setBean(String bean) {
		this.bean = bean;
	}
	
	 public String toString() {
	        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	    }

}
