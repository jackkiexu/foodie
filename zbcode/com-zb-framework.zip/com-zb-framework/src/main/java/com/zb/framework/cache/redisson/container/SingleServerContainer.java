/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.container;

import com.zb.framework.cache.redisson.RedissonContainer;
import com.zb.framework.cache.redisson.config.MasterSlaveConfig;
import org.redisson.Config;
import org.redisson.Redisson;
import org.redisson.SingleServerConfig;

/**
 * Created by  2015/5/6.
 */
public class SingleServerContainer implements RedissonContainer {
    private Redisson client = null;

    public SingleServerContainer(MasterSlaveConfig c) {
        Config config = new Config();
        config.setCodec(c.getCodec());
        config.setThreads(c.getThreads());

        final SingleServerConfig server = config.useSingleServer();
        server.setAddress(c.getMasterAddress());
        server.setConnectionPoolSize(c.getMasterConnectionPoolSize());
        server.setTimeout(c.getTimeout());
        server.setRetryAttempts(c.getRetryAttempts());
        server.setRetryInterval(c.getRetryInterval());
        server.setDatabase(c.getDatabase());

        client = Redisson.create(config);
    }

    @Override
    public Redisson get(String name) {
        return client;
    }

    @Override
    public void shutdown() {
        client.shutdown();
    }
}
