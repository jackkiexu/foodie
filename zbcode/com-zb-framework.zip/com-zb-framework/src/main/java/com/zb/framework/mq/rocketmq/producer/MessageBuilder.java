package com.zb.framework.mq.rocketmq.producer;

import com.alibaba.rocketmq.common.message.Message;
import com.alibaba.rocketmq.common.message.MessageConst;
import com.zb.framework.enums.BizCode;
import com.zb.framework.serialize.Serializer;
import com.zb.framework.util.CoreCommonUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * RocketMQ消息builder<br/>
 *
 * Created by  2015/1/14.
 */
public final class MessageBuilder {
    private String topic = null;

    private String tags = null;

    private String keys = null;

    private Serializable message = null;

    private Integer level = null;

    private Map<String,String> extFields = new HashMap<>(8, 1F);

    private MessageBuilder(String topic) {
        this.topic = topic;
    }

    /**
     * 消息名称<br/>
     *
     * @param topic
     * @return
     */
    public static MessageBuilder withTopic(String topic) {
        if(topic == null || topic.isEmpty()) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "topic不能为空");
        }

        MessageBuilder builder = new MessageBuilder(topic);

        return builder;
    }

    /**
     * 消息主体<br/>
     *
     * @param body
     * @return
     */
    public MessageBuilder body(Serializable body) {
        if(body == null) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "消息body不能为null");
        }

        this.message = body;

        return this;
    }

    /**
     * 发送消息时，tag只能是一个<br/>
     *
     * @param tags
     * @return
     */
    public MessageBuilder tags(String tags) {
        if(tags == null || tags.isEmpty()) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "消息tags不能为空");
        }

        this.tags = tags;

        return this;
    }

    /**
     * 多个key值使用空格（' ')分割<br/>
     *
     * @param keys
     * @return
     */
    public MessageBuilder keys(String keys) {
        if(keys == null || keys.isEmpty()) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "消息keys不能为空");
        }

        this.keys = keys;

        return this;
    }

    /**
     * 设置消息的多个key索引值<br/>
     *
     * @param keys
     * @return
     */
    public MessageBuilder keys(String ... keys) {
        if(keys == null || keys.length == 0) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "消息keys不能为空");
        }

        StringBuilder sb = new StringBuilder();
        for (String k : keys) {
            sb.append(k);
            sb.append(MessageConst.KEY_SEPARATOR);
        }

        this.keys = sb.toString().trim();

        return this;
    }

    public MessageBuilder keys(Collection<String> keys) {
        if(keys == null || keys.isEmpty()) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "消息keys不能为空");
        }

        return keys(keys.toArray(new String[keys.size()]));
    }

    /**
     * 设置消息延迟消费级别，索引从1开始<br/>
     *
     * @param level
     * @return
     */
    public MessageBuilder delayLevel(Integer level) {
        if(level != null && level <= 0) {
            CoreCommonUtils.raiseBizException(
                    BizCode.ParamError, "消息的delay level必须大于0");
        }

        this.level = level;

        return this;
    }

    /**
     * 添加用户自定义扩展内容<br/>
     *
     * @param key
     * @param value
     * @return
     */
    public MessageBuilder addExtField(String key, String value) {
        if(StringUtils.isEmpty(key)) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotEmpty, "扩展参数key不能为空");
        }

        this.extFields.put(key, value);

        return this;
    }

    public Message build(Serializer serializer) {
        Message msg = new Message(this.topic, serializer.serialize(message));
        msg.setTags(this.tags);
        msg.setKeys(keys);

        if(this.level != null) {
            msg.setDelayTimeLevel(this.level);
        }

        // 用户自定义扩展属性；
        for (Map.Entry<String,String> entry : this.extFields.entrySet()) {
            msg.putUserProperty(entry.getKey(), entry.getValue());
        }

        return msg;
    }
}
