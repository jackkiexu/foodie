package com.zb.framework.algorithm.hash.consistent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;
import com.zb.framework.algorithm.hash.*;


public class BucketContainer<T extends BucketNode> {
    private static final Logger LOG = LoggerFactory.getLogger(BucketContainer.class);

    /**
     * 所有的实例（包括虚拟节点）<br/>
     *
     */
    private NavigableMap<Long, T> buckets = new TreeMap<>();

    /**
     * 实际节点值<br/>
     *
     */
    private List<Node<T>> nodes = new ArrayList<>(4);

    /**
     * hash算法<br/>
     *
     */
    private Hashing algo = null;

    /**
     * 是否已经初始化<br/>
     *
     */
    private boolean isInitialized = false;

    public BucketContainer() {
        algo = HashingFactory.ketama();
    }

    public BucketContainer(Hashing algo) {
        if(algo == null) {
            throw new IllegalArgumentException("hash算法不能为null");
        }

        this.algo = algo;
    }

    public void addNode(T value) {
        if(value == null) {
            throw new IllegalArgumentException("node节点不能为null");
        }

        nodes.add(new Node<T>(1, value));
    }

    public void addNode(double weight, T value) {
        if(value == null) {
            throw new IllegalArgumentException("node节点不能为null");
        }
        if(weight <= 0) {
            throw new IllegalArgumentException("权重必须大于0");
        }

        nodes.add(new Node<T>(weight, value));
    }

    public synchronized void initialize() {
        if(nodes.size() <= 0) {
            LOG.warn("请添加节点后再进行初始化!");

            return;
        }

        if(isInitialized) {
            throw new IllegalStateException("已经初始化");
        }

        // 初始化buckets；
        int totalWeight = 0;
        for(Node<T> node : nodes) {
            totalWeight += (int) (node.weight * 100);
        }
        int size = nodes.size() * 100;

        for(Node<T> node : nodes) {
            int weight = (int) (node.weight * 100);

            int thisNodes = (int)(((double)40 * size * weight) / totalWeight);

            for(int i = 0 ; i < thisNodes; ++i) {
                final String key = node.value.getBucketKey() + "-" + i;
                final byte[] bs = MD5.get().digest(key.getBytes());

                for(int k = 0; k < 4; k ++) {
                    long hash = algo.hash(new byte[] {bs[3 + k * 4]
                            , bs[2 + k * 4], bs[1 + k * 4], bs[0 + k * 4]});

                    buckets.put(hash, node.value);
                }
            }
        }
    }

    public T getNode(String key) {
        if(key == null || buckets.isEmpty()) {
            return null;
        }

        final byte[] bs = MD5.get().digest(key.getBytes());
        final long hash = algo.hash(new byte[]{bs[3], bs[2], bs[1], bs[0]});
        final Map.Entry<Long, T> entry = buckets.floorEntry(hash);
        final T value = (entry == null ? buckets.firstEntry() : entry).getValue();
        return value == null ? buckets.firstEntry().getValue() : value;
    }

    public List<T> getAllNodes() {
        List<T> result= new ArrayList<>();
        for(Node<T> node : nodes) {
            result.add(node.value);
        }

        return result;
    }

    // --------------------------------------- inner class
    private class Node<T> {
        // 权重；
        public double weight = 1;

        public T value = null;

        public Node(double weight, T value) {
            this.weight = weight;
            this.value = value;
        }
    }

    private static ThreadLocal<MessageDigest> MD5 = new ThreadLocal<MessageDigest>() {
        @Override
        protected final MessageDigest initialValue() {
            try {
                return MessageDigest.getInstance("MD5");
            } catch (NoSuchAlgorithmException e) {
                throw new IllegalStateException("no md5 algorythm found");
            }
        }
    };
}
