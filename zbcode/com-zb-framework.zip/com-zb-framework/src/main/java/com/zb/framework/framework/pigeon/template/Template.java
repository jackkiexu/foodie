package com.zb.framework.framework.pigeon.template;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Template {
	private Map<String, Process> processMap = new HashMap<String, Process>();
	
	private List<Process> processList = new ArrayList<Process>();
	
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, Process> getProcessMap() {
		return processMap;
	}

	public List<Process> getProcessList() {
		return processList;
	}
	
	public Template(String name, List<Process> processList) {
		this.processList = processList;
		this.name = name;
		for (Iterator<Process> iterator = processList.iterator(); iterator.hasNext();) {
			Process process = (Process) iterator.next();
			this.processMap.put(process.getName(), process);
		}
	}
	
}
