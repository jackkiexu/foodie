/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.task;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * 
 * @author 
 * @version $Id: TaskQueue.java, v 0.1 2015年2月6日 上午9:54:46  Exp $
 */
public class TaskQueue {
	
	private static final Logger logger = LoggerFactory.getLogger(TaskQueue.class);
	
	public static <T>  BlockingQueue<T> newBlockingQueue(int size) {
		logger.info("生成阻塞队列，大小为" + size + "......");
		return new LinkedBlockingQueue<T>(size);
	}
}
