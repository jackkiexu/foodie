package com.zb.framework.framework.pigeon.template;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Process {

	private List<Action> actionList = new ArrayList<Action>();
	
	private Map<String,Action> actionMap = new HashMap<String, Action>();
	
	private String name;

	public List<Action> getActionList() {
		return actionList;
	}

	public void setActionList(List<Action> actionList) {
		this.actionList = actionList;
	}

	public Map<String, Action> getActionMap() {
		return actionMap;
	}

	public void setActionMap(Map<String, Action> actionMap) {
		this.actionMap = actionMap;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



}
