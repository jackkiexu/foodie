
package com.zb.framework.framework.pigeon.xmap;

public interface XGetter {

    Class<?> getType();

    Object getValue(Object instance) throws Exception;
}
