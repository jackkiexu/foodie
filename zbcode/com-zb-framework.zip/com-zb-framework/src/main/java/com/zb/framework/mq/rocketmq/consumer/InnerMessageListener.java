/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.mq.rocketmq.consumer;

import java.io.Serializable;

/**
 * 主要是为了适应AspectJ的接口代理问题引入的接口<br/>
 *
 * Created by  2015/4/1.
 */
public interface InnerMessageListener<T  extends Serializable>
        extends MessageListener<T>, MessageListenerAccessor
        , com.alibaba.rocketmq.client.consumer.listener.MessageListener {
}
