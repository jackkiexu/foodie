package com.zb.framework.web.vo;

import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.Arrays;

/**
 * 调用Dubbo服务接口的信息<br/>
 *
 * Created by  2014/9/23.
 */
public class DubboInvokeVo implements Serializable {
    private static final long serialVersionUID = 1124308647047974663L;

    /**
     * 接口名称<br/>
     *
     * <pre>
     *      1、可以是Spring的Id值
     *      2、可以是一个full qualified class name
     * </pre>
     */
    private String interfaceName = null;

    /**
     * 方法名称<br/>
     *
     */
    private String methodName = null;


    /**
     * 调用方法参数，JSON格式<br/>
     *
     * <pre>
     *     为了避免json格式无须的问题，参数按照方法的定义从左往右定义为：1、2、3 ... n
     * </pre>
     */
    private String parameters = null;

    /**
     * 参数的数组表示形式<br/>
     *
     */
    private String[] parametersArray = null;

    /**
     * 参数个数<br/>
     *
     */
    private int parameterNum = 0;

    /**
     * 参数类型列表<br/>
     *
     */
    private String[] parameterTypes = null;

    /**
     * 用于标识请求的md5值，主要用于缓存<br/>
     *
     */
    private String md5 = null;

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = StringUtils.trim(interfaceName);
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = StringUtils.trim(methodName);
    }

    public String getParameters() {
        return parameters;
    }

    public void setParameters(String parameters) {
        this.parameters = parameters;
    }

    public int getParameterNum() {
        return parameterNum;
    }

    public void setParameterNum(int parameterNum) {
        this.parameterNum = parameterNum;
    }

    public String[] getParameterTypes() {
        return parameterTypes;
    }

    public void setParameterTypes(String[] parameterTypes) {
        this.parameterTypes = parameterTypes == null ? new String[0] : parameterTypes;
    }

    public String[] getParametersArray() {
        return parametersArray;
    }

    public void setParametersArray(String[] parametersArray) {
        this.parametersArray = parametersArray;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    @Override
    public String toString() {
        return "DubboInvokeVo{" +
                "interfaceName='" + interfaceName + '\'' +
                ", methodName='" + methodName + '\'' +
                ", parameters='" + parameters + '\'' +
                ", parametersArray=" + Arrays.toString(parametersArray) +
                ", parameterNum=" + parameterNum +
                ", parameterTypes=" + Arrays.toString(parameterTypes) +
                ", md5='" + md5 + '\'' +
                '}';
    }
}
