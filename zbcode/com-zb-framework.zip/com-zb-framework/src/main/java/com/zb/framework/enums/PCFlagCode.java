/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import java.io.Serializable;

import com.zb.framework.base.AbstractEnum;

/**
 * 对公对私标志
 * @author 
 * @version $Id: PCFlagCode.java, v 0.1 2015年1月23日 下午9:30:15  Exp $
 */
public final class PCFlagCode  extends AbstractEnum implements Serializable{

    /**  */
    private static final long serialVersionUID = 4571481222582305181L;
    
    public static final PCFlagCode Private=new PCFlagCode("0","对私标识");
    public static final PCFlagCode Public=new PCFlagCode("1","对公标识");
    
    protected PCFlagCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected PCFlagCode(String name, String desc) {
        super(name, desc);
    }

    /** 
     * @see com.zb.framework.base.AbstractEnum#getEnumType()
     */
    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return PCFlagCode.class;
    }

    

}
