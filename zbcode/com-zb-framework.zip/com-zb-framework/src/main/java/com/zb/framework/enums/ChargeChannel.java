/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 计费渠道
 */
public final class ChargeChannel extends AbstractCodedEnum implements Serializable{
    private static final long serialVersionUID = 7869864967436755574L;


    public static final ChargeChannel GqbCharge=new ChargeChannel("GqbCharge","GQBFUNDS|11111","滚钱宝支付渠道");

    protected ChargeChannel() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected ChargeChannel(String name, String code, String desc) {
        super(name,code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return ChargeChannel.class;
    }
}
