package com.zb.framework.framework.flow.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 阶段编码<br/>
 *
 * Created by  2014/12/11.
 */
public class PhaseCode extends AbstractEnum implements Serializable {
    public static final PhaseCode VALIDATE
            = new PhaseCode("VALIDATE", "参数验证");

    public static final PhaseCode PREPARE
            = new PhaseCode("PREPARE", "数据准备");

    public static final PhaseCode POST_VALIDATE
            = new PhaseCode("POST_VALIDATE", "数据后期验证");

    protected PhaseCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected PhaseCode(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected final Class<? extends AbstractEnum> getEnumType() {
        return PhaseCode.class;
    }
}
