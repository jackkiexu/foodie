package com.zb.framework.framework.flow.vo;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 响应附加属性<br/>
 *
 * Created by  2014/12/13.
 */
public class ResponseAttributes {
    /**
     * 属性内容，用于存储非结构化附加信息<br/>
     *
     */
    private HashMap<String,String> attributes = new HashMap<String,String>(4, 1F);

    /**
     * 添加一个属性<br/>
     *
     * @param key
     * @param value
     * @return 如果key已经存在，则返回原来的value值；
     */
    public String addExtField(String key, String value) {
        return attributes.put(key, value);
    }

    /**
     * 删除一个属性<br/>
     *
     * @param key
     * @return 如果key已经存在，则返回原来的value值；
     *
     */
    public String removeExtField(String key) {
        return attributes.remove(key);
    }

    /**
     * 通过key获取属性<br/>
     *
     * @param key
     * @return
     */
    public String getExtField(String key) {
        return attributes.get(key);
    }

    /**
     * 将给定的内容复制到当前的响应属性中<br/>
     *
     * @param attributes
     */
    public void copy(Map<String, String> attributes) {
        if(attributes == null) {
            return;
        }

        attributes.putAll(attributes);
    }

    /**
     * 获取附加属性的一个不可变快照<br/>
     *
     * @return
     */
    public Map<String, String> attributes() {
        return Collections.unmodifiableMap(attributes);
    }
}
