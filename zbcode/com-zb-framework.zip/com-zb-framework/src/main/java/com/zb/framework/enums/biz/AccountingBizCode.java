/**
 * 
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * @ClassName: ResultCode
 * @Description:
 * @author 
 * @date 2015年1月5日 下午2:32:38
 * @version V1.0
 */
public class AccountingBizCode extends BizCode implements Serializable {

	/**
	 * @Fields serialVersionUID :
	 */
	private static final long serialVersionUID = 442530149296451246L;

	/** 返回码组成3位系统编码+3位编码 */
	/** 1开头的警告级别的错误 */
	/** 2开头的业务级别的错误 */
	/** 8开头的数据库级别的错误 */
	/** 9开头的系统级别的错误 */
	
	/** 当前正常窗口,不允许进入并行窗口! */
    public static final AccountingBizCode ACM_RUN_STS_NOT_N = new AccountingBizCode(
        "ACM_RUN_STS_NOT_N", ServiceCode.Accounting, "100", "当前正常窗口,不允许进入并行窗口!");
	
	/** 运行状态表未初始化 */
    public static final AccountingBizCode ACM_RUN_STS_NOT_INIT = new AccountingBizCode(
            "ACM_RUN_STS_NOT_INIT", ServiceCode.Accounting, "101", "运行状态表未初始化");
    
    /** 不允许往前切日 */
    public static final AccountingBizCode ACM_CHANGE_ACTDAT_BEF = new AccountingBizCode(
        "ACM_CHANGE_ACTDAT_BEF", ServiceCode.Accounting, "102", "不允许往前切日");
	
    /** 备份运行状态表失败 */
    public static final AccountingBizCode ACM_BCK_RUN_STS_FAIL = new AccountingBizCode(
        "ACM_BCK_RUN_STS_FAIL", ServiceCode.Accounting, "103", "备份运行状态表失败");
    
    /** 登记批次状态表失败 */
    public static final AccountingBizCode ACM_REG_BATCH_STS_FAIL = new AccountingBizCode(
        "ACM_REG_BATCH_STS_FAIL", ServiceCode.Accounting, "104", "登记批次状态表失败");
    
    /** 更新会计日期失败 */
    public static final AccountingBizCode ACM_UPD_ACTDAT_FAIL = new AccountingBizCode(
        "ACM_UPD_ACTDAT_FAIL", ServiceCode.Accounting, "105", "更新会计日期失败");
    
    /** 更新运行状态表失败 */
    public static final AccountingBizCode ACM_UPD_RUN_STS_FAIL = new AccountingBizCode(
        "ACM_UPD_RUN_STS_FAIL", ServiceCode.Accounting, "106", "更新运行状态表失败");
    
    /** 查询批次任务运行登记表失败 */
    public static final AccountingBizCode ACM_QRY_BATCH_TASK_FAIL = new AccountingBizCode(
        "ACM_QRY_BATCH_TASK_FAIL", ServiceCode.Accounting, "107", "查询批次任务运行登记表失败");
    
    /** 登记批次任务运行登记表失败 */
    public static final AccountingBizCode ACM_REG_BATCH_TASK_FAIL = new AccountingBizCode(
        "ACM_REG_BATCH_TASK_FAIL", ServiceCode.Accounting, "108", "登记批次任务运行登记表失败");
    
    /** 更新批次任务运行登记表失败 */
    public static final AccountingBizCode ACM_UPD_BATCH_TASK_FAIL = new AccountingBizCode(
        "ACM_UPD_BATCH_TASK_FAIL", ServiceCode.Accounting, "109", "更新批次任务运行登记表失败");
    
    /** 日终批次VO类不能为空 */
    public static final AccountingBizCode ACM_BAT_VO_NULL = new AccountingBizCode(
        "ACM_BAT_VO_NULL", ServiceCode.Accounting, "110", "日终批次VO类不能为空");
    
    /** 上次任务未完成，不允许执行下一个任务 */
    public static final AccountingBizCode ACM_LAST_BATCH_TASK_NOT = new AccountingBizCode(
        "ACM_LAST_BATCH_TASK_NOT", ServiceCode.Accounting, "111", "上次任务未完成，不允许执行下一个任务");
    
    /** 更新批次运行状态表 */
    public static final AccountingBizCode ACM_UPD_BATCH_STS_FAIL = new AccountingBizCode(
        "ACM_UPD_BATCH_STS_FAIL", ServiceCode.Accounting, "112", "更新批次运行状态表");
    
    /** 当前非批处理窗口,不允许进入正常窗口! */
    public static final AccountingBizCode ACM_RUN_STS_NOT_B = new AccountingBizCode(
        "ACM_RUN_STS_NOT_B", ServiceCode.Accounting, "113", "当前非批处理窗口,不允许进入正常窗口!");
    
	
	
	/** 创建内部账户余额信息失败 */
    public static final AccountingBizCode ACM_CRTINNER_BAL_FAIL = new AccountingBizCode(
            "ACM_CRTINNER_BAL_FAIL", ServiceCode.Accounting, "201", "创建内部账户余额信息失败");
    
    /** 更新内部账户余额失败*/
    public static final AccountingBizCode ACM_UPDINNER_BAL_FAIL = new AccountingBizCode(
            "ACM_UPDINNER_BAL_FAIL", ServiceCode.Accounting, "202", "更新内部账户余额失败");
    
    /** 登记内部账户收支明细失败*/
    public static final AccountingBizCode ACM_REG_INNER_DTL_FAIL = new AccountingBizCode(
            "ACM_REG_INNER_DTL_FAIL", ServiceCode.Accounting, "203", "登记内部账户收支明细失败");
    
    /** 备份总账余额信息失败*/
    public static final AccountingBizCode ACM_BACK_GL_BAL_FAIL = new AccountingBizCode(
            "ACM_BACK_GL_BAL_FAIL", ServiceCode.Accounting, "204", "备份总账余额信息失败");
    
    /** 该科目未发现 */
    public static final AccountingBizCode ACM_NOT_FIND_ITM = new AccountingBizCode(
            "ACM_NOT_FIND_ITM", ServiceCode.Accounting, "205", "该科目未发现");
    
    /** 该科目状态无效 */
    public static final AccountingBizCode ACM_ITM_STATUS_INVALID = new AccountingBizCode(
            "ACM_ITM_STATUS_INVALID", ServiceCode.Accounting, "206", "该科目状态无效");
    
    /** 登记总账余额信息失败 */
    public static final AccountingBizCode ACM_REG_GL_BAL_FAIL = new AccountingBizCode(
            "ACM_REG_GL_BAL_FAIL", ServiceCode.Accounting, "207", "登记总账信息失败");
    
    /** 更新总账余额信息失败 */
    public static final AccountingBizCode ACM_UPD_GL_BAL_FAIL = new AccountingBizCode(
            "ACM_UPD_GL_BAL_FAIL", ServiceCode.Accounting, "208", "更新总账余额信息失败");
    
    /** 登记总分核对临时表失败 */
    public static final AccountingBizCode ACM_REG_GL_VERIFY_FAIL = new AccountingBizCode(
            "ACM_REG_GL_VERIFY_FAIL", ServiceCode.Accounting, "209", "登记总分核对临时表失败");
    
    /** 更新总分核对临时表失败 */
    public static final AccountingBizCode ACM_UPD_GL_VERIFY_FAIL = new AccountingBizCode(
            "ACM_UPD_GL_VERIFY_FAIL", ServiceCode.Accounting, "210", "更新总分核对临时表失败");
    
    /** 到账务中心更新内部户余额失败 */
    public static final AccountingBizCode ACM_ACT_UPDINNBAL_FAIL = new AccountingBizCode(
            "ACM_ACT_UPDINNBAL_FAIL", ServiceCode.Accounting, "211", "到账务中心更新内部户余额失败");
    
    /** 重置会计日期失败 */
    public static final AccountingBizCode ACM_RESET_ACTDAT_FAIL = new AccountingBizCode(
            "ACM_RESET_ACTDAT_FAIL", ServiceCode.Accounting, "212", "重置会计日期失败");
    
    /** 更新每日账户资金收支明细汇总临时表失败 */
    public static final AccountingBizCode ACM_UPD_DTLSUMTMP_FAIL = new AccountingBizCode(
            "ACM_UPD_DTLSUMTMP_FAIL", ServiceCode.Accounting, "213", "更新每日账户资金收支明细汇总临时表失败");
    
    /** 到资金对账系统登记对账批次失败 */
    public static final AccountingBizCode ACM_REG_ARECON_BAT_FAIL = new AccountingBizCode(
            "ACM_REG_ARECON_BAT_FAIL", ServiceCode.Accounting, "214", "到资金对账系统登记对账批次失败");
    
    /** 到账务日终批量更新主账户余额信息失败 */
    public static final AccountingBizCode ACM_BAT_MAIN_BAL_FAIL = new AccountingBizCode(
            "ACM_BAT_MAIN_BAL_FAIL", ServiceCode.Accounting, "215", "到账务日终批量更新主账户余额信息失败");
    
    /** 到报表系统日终批量生成报表失败 */
    public static final AccountingBizCode ACM_BAT_AREPORT_FAIL = new AccountingBizCode(
            "ACM_BAT_AREPORT_FAIL", ServiceCode.Accounting, "216", "到报表系统日终批量生成报表失败");
    

	/** 8开头的数据库级别的错误 */
	/** db幂等异常 */
	public static final AccountingBizCode ACM_DB_SYSTEM_ERROR = new AccountingBizCode(
			"ACM_DB_SYSTEM_ERROR", ServiceCode.Accounting, "899", "db幂等异常");

	/** 9开头的系统级别的错误 */
	/** 类转换失败 */
	public static final AccountingBizCode ACM_SYSTEM_CLASS_CONVERT_ERROR = new AccountingBizCode(
			"ACM_SYSTEM_CLASS_CONVERT_ERROR", ServiceCode.Accounting, "901",
			"类转换失败");

	/** 未知错误 */
	public static final AccountingBizCode ACM_UN_KNOWN = new AccountingBizCode(
			"ACM_UN_KNOWN", ServiceCode.Accounting, "998", "未知错误");

	/** 系统异常 */
	public static final AccountingBizCode ACM_SYSTEM_ERROR = new AccountingBizCode(
			"ACM_SYSTEM_ERROR", ServiceCode.Accounting, "999", "系统异常");

	private AccountingBizCode(String name, ServiceCode serviceCode, String code,
			String desc) {
		super(name, serviceCode, code, desc);
	}
	
	private AccountingBizCode() {

	}

}
