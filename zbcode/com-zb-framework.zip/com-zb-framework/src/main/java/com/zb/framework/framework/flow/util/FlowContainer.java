package com.zb.framework.framework.flow.util;

import java.util.List;

/**
 * 自定义容器<br/>
 *
 * Created by  2014/12/12.
 */
public interface FlowContainer<T> {
    /**
     * 验证域的总数量<br/>
     *
     * @return
     */
    int size();

    /**
     * 让容器的容量不小于指定的值<br/>
     *
     * @param minCapacity
     */
    void ensureCapacity(int minCapacity);

    /**
     * 扩展容器的容量<br/>
     *
     * @param addedCapacity
     */
    void expandCapacity(int addedCapacity);

    /**
     * 添加元素<br/>
     *
     * @param field
     * @return
     */
    boolean add(T field);

    /**
     * 获取所有的元素<br/>
     *
     * @return
     */
    List<T> toList();

    /**
     * 是否为空<br/>
     *
     * @return
     */
    boolean isEmpty();
}
