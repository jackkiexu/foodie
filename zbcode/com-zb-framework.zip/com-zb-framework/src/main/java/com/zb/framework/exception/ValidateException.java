/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.exception;

import com.zb.framework.base.BaseException;
import com.zb.framework.enums.BizCode;

import java.io.Serializable;

/**
 * 参数验证异常<br/>
 *
 * Created by  2015/4/28.
 */
public class ValidateException extends BaseException implements Serializable {
    private static final long serialVersionUID = -4299652739138318666L;

    public ValidateException() {
        super();
    }

    public ValidateException(BizCode code, String message) {
        super(code, message);
    }

    public ValidateException(BizCode code, String message, Throwable cause) {
        super(code, message, cause);
    }

    public ValidateException(BizCode code, Throwable cause) {
        super(code, cause);
    }

    public ValidateException(boolean ignoreStackTrace) {
        super(ignoreStackTrace);
    }

    public ValidateException(BizCode code, String message, boolean ignoreStackTrace) {
        super(code, message, ignoreStackTrace);
    }

    public ValidateException(BizCode code, String message, Throwable cause, boolean ignoreStackTrace) {
        super(code, message, cause, ignoreStackTrace);
    }

    public ValidateException(BizCode code, Throwable cause, boolean ignoreStackTrace) {
        super(code, cause, ignoreStackTrace);
    }
}
