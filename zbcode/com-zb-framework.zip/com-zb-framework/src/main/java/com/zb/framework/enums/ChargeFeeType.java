/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 费率类型<br/>
 *
 * Created by 
 */
public class ChargeFeeType extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = -8166091845965066890L;

    public static final ChargeFeeType Percent = new ChargeFeeType("Percent","0", "百分比");

    public static final ChargeFeeType Each = new ChargeFeeType("Each","5", "每笔");


    protected ChargeFeeType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected ChargeFeeType(String name, String code, String desc) {
        super(name,code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return ChargeFeeType.class;
    }
}
