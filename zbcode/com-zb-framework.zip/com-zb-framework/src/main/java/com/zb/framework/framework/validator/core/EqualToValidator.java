package com.zb.framework.framework.validator.core;

import com.zb.framework.framework.validator.Validator;
import com.zb.framework.framework.validator.base.AbstractValidator;

/**
 * 对象equal验证器<br/>
 *
 * Created by  2014/12/15.
 */
public class EqualToValidator extends AbstractValidator implements Validator {
    public EqualToValidator(Object referObject) {
        super(referObject);
    }

    @Override
    public boolean doValidate(Object target) {
        return null != target && target.equals(getReferObject());
    }
}
