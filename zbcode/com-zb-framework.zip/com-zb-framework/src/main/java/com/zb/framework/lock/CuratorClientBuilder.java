/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.lock;


import com.zb.framework.lock.vo.CuratorConfig;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.RetryNTimes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * zk 客户端工厂类
 */
public class CuratorClientBuilder {
    private static final Logger logger = LoggerFactory.getLogger(CuratorClientBuilder.class);

    private CuratorConfig config = null;

    private CuratorFramework client = null;

    CuratorClientBuilder(){

    }

    /**
     * 构建build对象 单实例
     * @return
     */
    protected static CuratorClientBuilder newClient(CuratorConfig config){
        CuratorClientBuilder builder = new CuratorClientBuilder();
        builder.config = config;

        return builder;
    }

    protected CuratorFramework builder(){
        return build();
    }

    /**
     * 构建curator客户端
     * @return
     */
    private CuratorFramework build() {
        /**
         * 创建带命名空间的zk连接
         */
        logger.info("Initializer curator connect："+config);

        try {
            if(client != null){
                logger.info("curator client already initial.");
                return client;
            }
            client = CuratorFrameworkFactory.builder()
                    .retryPolicy(new RetryNTimes(100,1000))
                    .namespace(config.getNamespace())
                    .connectString(config.getConnection())
                    //.authorization(config.getUserName(), config.getPassword().getBytes())
                    .sessionTimeoutMs(config.getSessionTimeout())
                    .connectionTimeoutMs(config.getConnectTimeout())
                    .build();
            client.start();
            logger.info("Initializer curator connect success.");

        }catch (Exception e){
            logger.error("Initializer curator connect fail：",e);
        }
        return client;
    }

}
