package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 审核状态<br/>
 *
 *
 */
public final class CoreVerifyStatus extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = 239777752289079524L;

    public static final CoreVerifyStatus CheckReturn = new CoreVerifyStatus("CheckReturn", "0", "审核退回");

    public static final CoreVerifyStatus CheckPass = new CoreVerifyStatus("CheckPass", "1", "审核通过");

    public static final CoreVerifyStatus UnCheck = new CoreVerifyStatus("UnCheck", "2", "未审核");


    protected CoreVerifyStatus() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected CoreVerifyStatus(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return CoreVerifyStatus.class;
    }
}
