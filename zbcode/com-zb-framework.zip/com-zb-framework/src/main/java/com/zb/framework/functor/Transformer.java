/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.functor;

/**
 * 转换器<br/>
 *
 * Created by  2015/3/24.
 */
public interface Transformer<Input, Output> {
    /**
     * 转换输入的实例<br/>
     *
     * @param input
     * @return
     */
    public Output transform(Input input);
}
