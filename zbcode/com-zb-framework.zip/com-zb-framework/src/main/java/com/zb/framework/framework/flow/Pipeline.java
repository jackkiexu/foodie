package com.zb.framework.framework.flow;

import com.zb.framework.base.AbstractRequest;
import com.zb.framework.base.AbstractResponse;
import com.zb.framework.framework.flow.context.AbstractContext;

/**
 * Pipe line容器，一个可以定制的handler chain<br/>
 *
 * Created by  2014/12/10.
 */
public interface Pipeline extends OutboundInvoker {
    /**
     * 将处理器列表添加到工作flow的头部（front）<br/>
     *
     * @param handlers
     */
    void offer(Handler ... handlers);

    /**
     * 将处理器列表添加到工作flow的尾部（tail）<br/>
     *
     * @param handlers
     */
    void append(Handler ... handlers);

    /**
     * 设置与此工作chain相关的类型转换器<br/>
     *
     * @param converter
     */
    void setConverter(Converter<? extends AbstractContext
            , ? extends AbstractRequest, ? extends AbstractResponse> converter);

    /**
     * 设置与此工作chain相关的上下文<br/>
     *
     * @param context
     */
    <TContext extends AbstractContext>
    void setContext(TContext context);
}
