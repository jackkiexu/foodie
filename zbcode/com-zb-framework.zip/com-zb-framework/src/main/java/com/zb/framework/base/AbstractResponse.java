package com.zb.framework.base;



import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.util.CoreCommonUtils;
import com.zb.framework.util.CoreSystemUtils;

/**
 * 服务调用返回值基类<br/>
 *
 * Created by  2014/12/10.
 */
public abstract class AbstractResponse extends AbstractModel implements Serializable {
    private static final long serialVersionUID = 9132233374292213699L;

    /**
     * 服务调用运行结果编码<br/>
     *
     */
    private BizCode code = null;

    /**
     * 服务调用描述信息<br/>
     *
     */
    private String message = null;

    public AbstractResponse() {
        setServerIp(CoreSystemUtils.localIp());
        setServerHostName(CoreSystemUtils.localHostName());
    }

    /**
     * 获取服务调用运行结果编码<br/>
     *
     * @return
     */
    public BizCode getCode() {
        return code;
    }

    /**
     * 设置服务调用运行结果编码<br/>
     *
     * @param code
     */
    public void setCode(BizCode code) {
        this.code = code;
    }

    /**
     * 返回服务调用描述信息<br/>
     *
     * @return
     */
    public String getMessage() {
        return message;
    }

    /**
     * 设置服务调用描述信息<br/>
     *
     * @param message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * 判断响应是否成功<br/>
     *
     * @return
     */
    public boolean isSuccess() {
        return CoreCommonUtils.isSuccess(getCode());
    }

    @Override
    public String toString() {
        return "AbstractResponse{" +
                "code=" + code +
                ", message='" + message + '\'' +
                "} " + super.toString();
    }
}
