/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.spring.flow.config;

import com.zb.framework.enums.BizCode;
import com.zb.framework.spring.flow.support.SpringHoldFragment;
import com.zb.framework.spring.flow.support.SpringHoldHandler;
import com.zb.framework.spring.flow.support.SpringHoldTemplate;
import com.zb.framework.util.CoreCommonUtils;
import com.zb.framework.util.EncryptUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.beans.factory.xml.AbstractBeanDefinitionParser;
import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
import org.springframework.beans.factory.xml.NamespaceHandler;
import org.springframework.beans.factory.xml.NamespaceHandlerResolver;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;

import java.lang.reflect.Constructor;
import java.util.List;

/**
 * 流程框架相关的spring Bean解析器<br/>
 *
 * <pre>
 *     <flow:template id = "myTemplate" converter-class = "com.qiangungun.con.MyConverter">
 *         <handler class = "com.qiangungun.handler.MyHandler" enable-transaction = "true"/>
 *         <handler class = "com.qiangungun.handler.MyHandler" transaction-template = "myTransTemplate"/>
 *         <handler class = "com.qiangungun.handler.MyHandler" transaction-manager = "myTransManager"/>
 *         <handler class = "com.qiangungun.handler.MyHandler" listener-list = "myListenerList">
 *             <listener-list>
 *                 <listener class = "com.qiangungun.listener.MyListener/>
 *                 <listener ref = "myListener"/>
 *             </listener-list>
 *         </handler>
 *         <handler ref = "myHandler"/>
 *
 *         <fragment enable-transaction = "true">
 *             <handler ref = "myHandler"/>
 *
 *             <listener-list>
 *                 <listener class = "com.qiangungun.listener.MyListener/>
 *                 <listener ref = "myListener"/>
 *             </listener-list>
 *         </fragment>
 *
 *         <fragment if = "ctx.name == 'my-name'" transaction-template = "myTransTemplate">
 *             <handler ref = "myHandler"/>
 *
 *             <listener-list>
 *                 <listener class = "com.qiangungun.listener.MyListener/>
 *                 <listener ref = "myListener"/>
 *             </listener-list>
 *         </fragment>
 *
 *         <fragment ref = "myFragment"/>
 *     </flow:template>
 *
 *     <flow:fragment id = "fId" transaction-manager = "myTransManager">
 *         <handler ref = "myHandler"/>
 *
 *         <listener-list>
 *                 <listener class = "com.qiangungun.listener.MyListener/>
 *                 <listener ref = "myListener"/>
 *             </listener-list>
 *     </flow:fragment>
 *
 *     <flow:fragment id = "fId" if = "ctx.name == 'my-name'">
 *         <handler ref = "myHandler"/>
 *
 *         <listener-list>
 *                 <listener class = "com.qiangungun.listener.MyListener/>
 *                 <listener ref = "myListener"/>
 *         </listener-list>
 *
 *         <fragment ref = "otherFragment"/>
 *     </flow:fragment>
 *
 *     <flow:handler id = "myHandler" class = "com.qiangungun.handler.MyHandler" enable-transaction = "true"/>
 * </pre>
 *
 * Created by  2015/4/23.
 */
public class FlowNamespaceHandler extends NamespaceHandlerSupport {
    public static final String Node_Template = "template";

    public static final String Node_Handler = "handler";

    public static final String Node_Listener_List = "listener-list";

    public static final String Node_Listener = "listener";

    public static final String Node_Fragment = "fragment";

    public static final String Attr_Id = "id";

    public static final String Attr_Converter_Class = "converter-class";

    public static final String Attr_Converter_Ref = "converter-ref";

    public static final String Attr_Class = "class";

    public static final String Attr_Ref = "ref";

    public static final String Attr_Enable_Transaction = "enable-transaction";

    public static final String Attr_Transaction_Template = "transaction-template";

    public static final String Attr_Transaction_Manager = "transaction-manager";

    public static final String Attr_If = "if";

    public static final String Attr_Ref_Listener_List = "listener-list";

    public static final String Spring_Inner_P_Schema = "http://www.springframework.org/schema/p";

    @Override
    public void init() {
        registerBeanDefinitionParser(Node_Template, new TemplateBeanDefinitionParser());
        registerBeanDefinitionParser(Node_Handler, new HandlerBeanDefinitionParser());
        //registerBeanDefinitionParser(Node_Listener_List, new TemplateBeanDefinitionParser());
        //registerBeanDefinitionParser(Node_Listener, new TemplateBeanDefinitionParser());
        registerBeanDefinitionParser(Node_Fragment, new FragmentBeanDefinitionParser());
    }

    /**
     * 节点解析基类<br/>
     *
     */
    private static abstract class AbstractFlowBeanDefinitionParser extends AbstractBeanDefinitionParser {

        @Override
        protected boolean shouldGenerateId() {
            return false;
        }

        @Override
        protected boolean shouldGenerateIdAsFallback() {
            return true;
        }

        @Override
        protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext) {
            BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition();
            doParse(element, parserContext, builder);

            return builder.getBeanDefinition();
        }

        protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
            builder.getRawBeanDefinition().setBeanClass(getBeanClass(element));
            builder.getRawBeanDefinition().setSource(parserContext.extractSource(element));
        }

        protected abstract Class<?> getBeanClass(Element element);
    }

    private static class TemplateBeanDefinitionParser extends AbstractFlowBeanDefinitionParser {
        @Override
        protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
            super.doParse(element, parserContext, builder);

            // id必须设置，有xsd约束；

            // 获取converter属性，二者必须有一个存在；
            final String converterRef = element.getAttribute(Attr_Converter_Ref);
            final String converterClass = element.getAttribute(Attr_Converter_Class);
            if(StringUtils.isNotEmpty(converterRef)) {
                builder.addPropertyValue("converter", new RuntimeBeanReference(converterRef));
            } else if(StringUtils.isNotEmpty(converterClass)) {
                RootBeanDefinition bean = new RootBeanDefinition(converterClass);
                final String id = parserContext.getReaderContext().registerWithGeneratedName(bean);
                builder.addPropertyValue("converter", new RuntimeBeanReference(id));
            } else {
                CoreCommonUtils.raiseBizException(BizCode.ParamError
                        , Attr_Converter_Ref + "或者" + Attr_Converter_Class + "二者必须设置一个属性");
            }

            List<Object> handlerBeans = getAllHandlers(
                    element, parserContext, builder.getRawBeanDefinition());

            // 添加所有handler；
            builder.addPropertyValue("handlers", handlerBeans);
        }

        @Override
        protected Class<?> getBeanClass(Element element) {
            return SpringHoldTemplate.class;
        }
    }

    private static List<Object> getAllHandlers(
            Element element, ParserContext parserContext, AbstractBeanDefinition containingBeanDefinition) {
        final BeanDefinitionParserDelegate delegate = parserContext.getDelegate();
        List<Object> handlerBeans = new ManagedList<>(6);

        final List<Element> children = DomUtils.getChildElements(element);
        for (Element ele : children) {
            // 解析handler；
            // final List<Element> handlers = DomUtils.getChildElementsByTagName(element, Node_Handler);
            if(Node_Handler.equals(ele.getLocalName())) {
                final Object value
                        = delegate.parsePropertySubElement(ele, containingBeanDefinition);
                handlerBeans.add(value);
            }

            // 解析fragment；
            //final List<Element> fragments = DomUtils.getChildElementsByTagName(element, Node_Fragment);
            if(Node_Fragment.equals(ele.getLocalName())) {
                final String ref = ele.getAttribute(Attr_Ref);
                if(StringUtils.isNotEmpty(ref)) {
                    handlerBeans.add(new RuntimeBeanReference(ref));
                } else {
                    final Object value
                            = delegate.parsePropertySubElement(ele, containingBeanDefinition);
                    handlerBeans.add(value);
                }
            }

            // 忽略不认识的阶段；
        }
        return handlerBeans;
    }

    /**
     * handler相关的配置<br/>
     *
     */
    private static abstract class BaseHandlerBeanDefinitionParser extends AbstractFlowBeanDefinitionParser {
        @Override
        protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
            super.doParse(element, parserContext, builder);

            // 解析事务属性；
            final String transTemplate = element.getAttribute(Attr_Transaction_Template);
            final String  transManager= element.getAttribute(Attr_Transaction_Manager);
            final String enableTrans = element.getAttribute(Attr_Enable_Transaction);
            if(StringUtils.isNotEmpty(transTemplate)) {
                builder.addPropertyReference("transactionTemplate", transTemplate);
            } else if(StringUtils.isNotEmpty(transManager)) {
                builder.addPropertyReference("transactionManager", transManager);
            } else if(StringUtils.isNotEmpty(enableTrans)) {
                builder.addPropertyValue("enableTransaction", enableTrans);
            }

            // 解析listener；
            final String refListenerList = element.getAttribute(Attr_Ref_Listener_List);
            final List<Element> nodListElements = DomUtils.getChildElementsByTagName(element, Node_Listener_List);
            if(StringUtils.isNotEmpty(refListenerList)) {
                builder.addPropertyReference("listeners", refListenerList);
            } else if(CollectionUtils.isNotEmpty(nodListElements)) {
                // 只能有一个，由xsd限制；
                List<RuntimeBeanReference> listeners = new ManagedList<>(nodListElements.size());
                Element nodeList = nodListElements.get(0);

                // 获取所有的listener子节点；
                final List<Element> listenerNodes = DomUtils.getChildElementsByTagName(nodeList, Node_Listener);
                for(Element ele : listenerNodes) {
                    final String ref = ele.getAttribute(Attr_Ref);
                    final String listenerClazz = ele.getAttribute(Attr_Class);
                    if(StringUtils.isNotEmpty(ref)) {
                        listeners.add(new RuntimeBeanReference(ref));
                    } else if (StringUtils.isNotEmpty(listenerClazz)){
                        // 支持p:
                        final String id = createWrapperBean(ele, parserContext, listenerClazz);
                        listeners.add(new RuntimeBeanReference(id));
                    } else {
                        CoreCommonUtils.raiseBizException(BizCode.ParamError, "监听器（listener）必须包含ref或者class属性");
                    }
                }

                builder.addPropertyValue("listeners", listeners);
            }
        }
    }

    /**
     * 独立的handler节点表示非ref的阶段<br/>
     *
     */
    private static class HandlerBeanDefinitionParser extends BaseHandlerBeanDefinitionParser {
        @Override
        protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
            super.doParse(element, parserContext, builder);

            // class的类型；
            final String clazz = element.getAttribute(Attr_Class);
            final String ref = element.getAttribute(Attr_Ref);
            if(StringUtils.isNotEmpty(ref)) {
                builder.addPropertyReference("holdHandler", ref);
            } else if(StringUtils.isNotEmpty(clazz)) {
                final String beanId = createWrapperBean(element, parserContext, clazz);
                builder.addPropertyValue("holdHandler", new RuntimeBeanReference(beanId));
            } else if(StringUtils.isEmpty(clazz)) {
                CoreCommonUtils.raiseBizException(BizCode.ParamError, "必须配置handler的class属性");
            }

            //parserContext.getDelegate().parseCustomElement(element, builder.getBeanDefinition());
        }

        @Override
        protected Class<?> getBeanClass(Element element) {
            return SpringHoldHandler.class;
        }
    }

    private static String createWrapperBean(Element element, ParserContext parserContext, String clazz) {
        RootBeanDefinition root = new RootBeanDefinition(clazz);
        root.setSource(parserContext.extractSource(element));
        final String beanId = parserContext.getReaderContext().registerWithGeneratedName(root);
        parseP(element, parserContext, root, beanId);
        return beanId;
    }

    private static void parseP(Element element
            , ParserContext parserContext, BeanDefinition beanDefinition, String beanId) {
        final NamespaceHandlerResolver namespaceHandlerResolver
                = parserContext.getReaderContext().getNamespaceHandlerResolver();

        // 解析p:
        final NamedNodeMap attributes = element.getAttributes();
        for(int i = 0; i < attributes.getLength(); ++i) {
            final String uri = parserContext.getDelegate().getNamespaceURI(attributes.item(i));
            if(Spring_Inner_P_Schema.equals(uri)) {
                final NamespaceHandler resolve = namespaceHandlerResolver.resolve(uri);
                resolve.decorate(attributes.item(i), new BeanDefinitionHolder(beanDefinition, beanId), parserContext);
            }
        }
    }

    private static class FragmentBeanDefinitionParser extends BaseHandlerBeanDefinitionParser {
        @Override
        protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder) {
            super.doParse(element, parserContext, builder);

            final List<Object> handlers = getAllHandlers(
                    element, parserContext, builder.getRawBeanDefinition());

            // 添加所有handler；
            builder.addPropertyValue("holdHandlers", handlers);

            // 添加boolean expr；
            final String ifExpr = element.getAttribute(Attr_If);
            if(StringUtils.isNotEmpty(ifExpr)) {
                builder.addPropertyValue("booleanExpression", ifExpr);
            }

            // 支持p:
            final String id = element.getAttribute(ID_ATTRIBUTE);
            if(StringUtils.isNotEmpty(id)) {
                parseP(element, parserContext, builder.getBeanDefinition(), id);
            } else {
                final String genId = EncryptUtils.encryptMD5(handlers.toString());
                parseP(element, parserContext, builder.getBeanDefinition(), genId);
            }

            // 默认情况下fragment的name就是其id值（如果没有使用p:name配置）；
            if(StringUtils.isNotEmpty(id)) {
                final MutablePropertyValues propertyValues = builder.getBeanDefinition().getPropertyValues();
                final PropertyValue name = propertyValues.getPropertyValue("name");
                if(name == null) {
                    builder.addPropertyValue("name", id);
                }
            }
        }

        @Override
        protected Class<?> getBeanClass(Element element) {
            final String clazz = element.getAttribute("class");

            final ClassLoader classLoader = CoreCommonUtils.getClassLoader(FlowNamespaceHandler.class);
            try {
                return StringUtils.isNotEmpty(clazz) ? classLoader.loadClass(clazz) : SpringHoldFragment.class;
            } catch (ClassNotFoundException e) {
                CoreCommonUtils.raiseBizException(BizCode.ClassOrInstanceError, "初始化class error", e);
            }

            return null;
        }

        @Override
        protected String resolveId(Element element
                , AbstractBeanDefinition definition, ParserContext parserContext) throws BeanDefinitionStoreException {
            final String id = element.getAttribute(ID_ATTRIBUTE);
            if(StringUtils.isNotEmpty(id)) {
                return id;
            } else {
                Object pv = definition.getPropertyValues().getPropertyValue("holdHandlers");

                return EncryptUtils.encryptMD5(pv.toString());
            }
        }
    }

    // ------------------------------------------------------ helper;
    private static Object newDefault(String clazzName) {
        try {
            final Class<?> clazz = Class.forName(clazzName);
            final Constructor<?> defConst = clazz.getConstructor();
            return defConst.newInstance();
        } catch (Exception e) {
            CoreCommonUtils.raiseBizException(BizCode.ParamError, "调用默认构造函数失败： " + clazzName, e);
        }

        return null;
    }
}
