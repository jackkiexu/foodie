/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.container;

import com.zb.framework.algorithm.hash.consistent.BucketContainer;
import com.zb.framework.cache.redisson.RedissonContainer;
import com.zb.framework.cache.redisson.config.MultiConfig;
import com.zb.framework.util.CoreSystemUtils;
import org.apache.commons.lang3.StringUtils;
import org.redisson.Config;
import org.redisson.Redisson;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by  2015/5/6.
 */
public abstract class MultiContainer implements RedissonContainer {
    private boolean useHashing = true;

    private Redisson client = null;

    private BucketContainer<RedisNode> container = null;

    private Set<String> groupNames = new HashSet<>(4, 1F);

    public MultiContainer(List<MultiConfig> configs) {
        if(configs.size() == 1) {
            useHashing = false;
        } else {
            container = new BucketContainer<>();
        }

        // validate group name;
        validateGroupName(configs);

        for(MultiConfig config : configs) {
            config.validate();

            client = Redisson.create(createConfig(config));

            fillBucket(client, config);
        }

        if(useHashing) {
            container.initialize();
        }
    }

    protected void validateGroupName(List<MultiConfig> configs) {
        for(MultiConfig config : configs) {
            if(StringUtils.isEmpty(config.getGroupName())) {
                config.setGroupName(CoreSystemUtils.objectId());
            }

            final boolean exists = groupNames.contains(config.getGroupName());
            if(exists) {
                config.setGroupName(CoreSystemUtils.objectId());
            }

            groupNames.add(config.getGroupName());
        }
    }

    @Override
    public Redisson get(String name) {
        return useHashing ? container.getNode(name).getClient() : client;
    }

    @Override
    public void shutdown() {
        if(!useHashing) {
            client.shutdown();
        } else {
            for (RedisNode node : container.getAllNodes()) {
                node.getClient().shutdown();
            }
        }
    }

    protected abstract Config createConfig(MultiConfig config);

    protected abstract String[] getAddressList(MultiConfig config);

    private void fillBucket(Redisson client, MultiConfig config) {
        if(!useHashing) {
            return;
        }

        for(String address : getAddressList(config)) {
            final String name = config.getGroupName();
            container.addNode(new RedisNode(address, name, client));
        }
    }

    public BucketContainer<RedisNode> getContainer() {
        return container;
    }
}
