
package com.zb.framework.algorithm.hash;


public interface Hashing {
    /**
     * 计算给定值的hash值<br/>
     *
     * @param bytes
     * @return
     */
    long hash(byte[] bytes);
}
