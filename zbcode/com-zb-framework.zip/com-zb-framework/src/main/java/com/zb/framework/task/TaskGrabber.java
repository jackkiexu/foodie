/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.task;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * 
 * 
 * @author 
 * @version $Id: TaskGrabber.java, v 0.1 2015年2月6日 上午9:54:22  Exp $
 */
public abstract class TaskGrabber {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private TaskProducer taskProducer;

	private BlockingQueue<Task<?>> queue;
	
	private boolean stopFlag=false;
	
	private ExecutorService executor;

	public TaskGrabber(TaskProducer taskProducer, BlockingQueue<Task<?>> queue) {
		super();
		this.taskProducer = taskProducer;
		this.queue = queue;
	}

	public void start() {
	    executor = Executors.newSingleThreadExecutor();
		executor.execute(new Runnable() {
			@Override
			public void run() {
                logger.debug("线程id: " + Thread.currentThread().getName());
				while (!isStopFlag()) {
					/** 产生任务列表 */
                    logger.debug("线程id: " + Thread.currentThread().getName() + " 开始 产生taskList");
					List<Task<?>> taskList = taskProducer.produceList();
                    logger.debug("线程id: " + Thread.currentThread().getName() + " 产生taskList :" + taskList.size());
					if (taskList == null || taskList.size() == 0) {
						logger.debug("没有抓到任务，暂停10秒钟...");
						try {
                            TimeUnit.SECONDS.sleep(10);
                            continue;
						} catch (InterruptedException e) {
                            logger.info("线程id :" + Thread.currentThread().getName() + "被打断！",e);
						}
					}
					for (Task<?> task : taskList) {
						try {
							int rows=updateStatus(task);
							if(rows==0){
							    continue;
							}
							queue.put(task);
							logger.debug("任务" + task.getTaskId() + "被放入队列......");
						} catch (InterruptedException e) {
							logger.info("任务抓取器被中断......",e);
						}
					}
				}
			}
		});
	}

	public abstract int updateStatus(Task<?> task);

    public boolean isStopFlag() {
        return stopFlag;
    }

    public void setStopFlag(boolean stopFlag) {
        this.stopFlag = stopFlag;
    }
	
	public void destory(){
	    logger.info("开始销毁线程[{}]....",this.getClass().getName());
	    try{
	        if(executor!=null){
	            executor.shutdown();
	        }
	    }catch(Exception e){
	        logger.error("线程销毁异常",e);
	    }
	}

}
