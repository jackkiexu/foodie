package com.zb.framework.mq.rocketmq.spring;

import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.MQPushConsumer;
import com.zb.framework.enums.BizCode;
import com.zb.framework.mq.rocketmq.consumer.AbstractConcurrentMessageListener;
import com.zb.framework.mq.rocketmq.consumer.InnerMessageListener;
import com.zb.framework.serialize.Serializer;
import com.zb.framework.util.CoreCommonUtils;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 消费监听器容器<br/>
 *
 * Created by  2015/1/14.
 */
public class MessageListenerContainer implements InitializingBean, DisposableBean {
    /**
     * RocketMQ服务器配置信息<br/>
     */
    private RocketMqConfig config = null;

    /**
     * 订阅集合<br/>
     */
    private Map<RocketMqTopic, InnerMessageListener<?>> subscribers = new ConcurrentHashMap<>(16, 1F);

    /**
     * 消费者客户端<br/>
     */
    private static final Map<RocketMqTopic, MQPushConsumer> consumers = new ConcurrentHashMap<>(16, 1F);

    private static final Set<RocketMqTopic> startedConsumers = new HashSet<>(16, 1F);

    /**
     * 反序列化工具<br/>
     *
     */
    private Serializer serializer = null;

    public RocketMqConfig getConfig() {
        return config;
    }

    public void setConfig(RocketMqConfig config) {
        this.config = config;
    }

    public Map<RocketMqTopic, InnerMessageListener<?>> getSubscribers() {
        return subscribers;
    }

    public void setSubscribers(Map<RocketMqTopic, InnerMessageListener<?>> subscribers) {
        this.subscribers = subscribers;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if(getSubscribers() == null) {
            return;
        }

        // 默认序列化实例必须提供！！
        if(getSerializer() == null) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "序列化实例不能为null");
        }

        Set<Map.Entry<RocketMqTopic, InnerMessageListener<?>>> entries = getSubscribers().entrySet();
        for(Map.Entry<RocketMqTopic, InnerMessageListener<?>> entry : entries) {
            RocketMqTopic topic = entry.getKey();

            // 不允许重复的订阅关系
            if(consumers.containsKey(topic)) {
                /*CoreCommonUtils.raiseBizException(BizCode.DuplicatedError, "存在相同的topic： " + topic);*/

                continue;
            };

            InnerMessageListener<?> listener = entry.getValue();
            if(listener.getSerializer() == null) {
                listener.setSerializer(serializer);
            }

            DefaultMQPushConsumer pushConsumer = new DefaultMQPushConsumer();
            pushConsumer.setConsumerGroup(topic.getGroup());
            pushConsumer.setMessageListener(listener);
            pushConsumer.subscribe(topic.getTopic(), topic.getTags());
            pushConsumer.setConsumeThreadMin(topic.getConsumeThreadMin());
            pushConsumer.setConsumeThreadMax(topic.getConsumeThreadMax());
            pushConsumer.setConsumeMessageBatchMaxSize(topic.getConsumeMessageBatchSize());

            // name server
            pushConsumer.setNamesrvAddr(config.getNamesrvAddressSet());
            pushConsumer.setClientCallbackExecutorThreads(config.getNettyAsyncExecutorThreads());
            pushConsumer.setPollNameServerInteval(config.getSyncRouteInfoInterval());
            pushConsumer.setHeartbeatBrokerInterval(config.getHeartbeat4BrokerInterval());
            pushConsumer.setPersistConsumerOffsetInterval(config.getPersistOffsetInterval());

            consumers.put(topic, pushConsumer);
        }

        Set<Map.Entry<RocketMqTopic, MQPushConsumer>> $entries = consumers.entrySet();
        for(Map.Entry<RocketMqTopic, MQPushConsumer> entry : $entries) {
            if(!startedConsumers.contains(entry.getKey())) {
                entry.getValue().start();

                startedConsumers.add(entry.getKey());
            }
        }
    }

    @Override
    public void destroy() throws Exception {
        Collection<MQPushConsumer> values = consumers.values();

        for (MQPushConsumer consumer : values) {
            consumer.shutdown();
        }
    }

    public Serializer getSerializer() {
        return serializer;
    }

    public void setSerializer(Serializer serializer) {
        this.serializer = serializer;
    }
}
