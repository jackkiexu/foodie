/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.kernel;

import com.zb.framework.zk.event.EventObject;
import com.zb.framework.zk.event.NodeChangeEvent;
import com.zb.framework.zk.event.NodeChangeListener;
import com.zb.framework.zk.event.SessionEvent;
import com.zb.framework.zk.event.SessionListener;
import org.apache.commons.collections.CollectionUtils;
import org.apache.zookeeper.Watcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * 事件广播管理器<br/>
 *
 * Created by  2015/4/28.
 */
public final class EventMulticaster {
    private static final Logger LOG = LoggerFactory.getLogger(EventMulticaster.class);

    Queue<SessionListener> sessionListeners = new LinkedBlockingQueue<>(8);
    private BlockingDeque<SessionEvent> sessionEvents = new LinkedBlockingDeque<>(8);

    Map<String, Queue<ListenerNode>> changeListeners = new ConcurrentHashMap<>(8, 1F);
    private BlockingDeque<NodeChangeEvent> changeEvents = new LinkedBlockingDeque<>(8);

    private ZooKeeperInitializer initializer = null;

    EventMulticaster(ZooKeeperInitializer initializer) {
        this.initializer = initializer;

        new SessionEventDispatcher("zk-session-dispatcher").start();
        new ChangeEventDispatcher("zk-node-change-dispatcher").start();
    }

    public void addSessionListener(SessionListener listener ) {
        Assert.notNull(listener, "session监听器不能为null");

        sessionListeners.add(listener);
    }

    public void addChangeListener(String path, NodeChangeListener listener, boolean permanent) {
        Assert.notNull(listener, "node change监听器不能为null");
        Assert.hasText(path, "路径不能为空");

        Queue<ListenerNode> list = changeListeners.get(path);
        if(CollectionUtils.isEmpty(list)) {
            synchronized (changeListeners) {
                list = changeListeners.get(path);
                if(CollectionUtils.isEmpty(list)) {
                    list = new LinkedBlockingQueue<ListenerNode>(4);

                    // NOTE: 虽然有并发的风行，仅仅是相对顺序的问题，暂时不用处理！！
                    changeListeners.put(path, list);
                }
            }
        }

        synchronized (list) {
            ListenerNode newNode = new ListenerNode(path, listener, permanent);

            // check exists;
            for(ListenerNode ncl : list) {
                if(ncl.equals(newNode)) {
                    return;
                }
            }

            list.add(newNode);
        }
    }

    /**
     * 发布事件<br/>
     *
     * @param event
     */
    void publish(EventObject event) {
        if(event instanceof SessionEvent) {
            if(LOG.isDebugEnabled()) {
                LOG.info("发布session消息： " + event);
            }

            sessionEvents.add((SessionEvent) event);
        } else if(event instanceof NodeChangeEvent) {
            if(LOG.isDebugEnabled()) {
                LOG.info("发布node change消息： " + event);
            }

            changeEvents.add((NodeChangeEvent) event);
        }
    }

    // ----------------------------------------------- 事件处理线程；
    private abstract class BaseEventDispatcher<T extends EventObject> extends Thread {
        public BaseEventDispatcher() {
            super();
        }

        public BaseEventDispatcher(String name) {
            super(name);
        }

        @Override
        public final void run() {
            while(true) {
                T event = null;
                try {
                    event = nextEvent();
                } catch (Exception e) {
                    LOG.warn("获取zk event消息异常", e);

                    continue;
                }

                // 如果没有监听器，则抛弃；
                if(!exitsListeners(event)) {
                    continue;
                }

                try {
                    dispatch(event);
                } catch (Exception e) {
                    LOG.warn("消费zk event异常", e); // ignore error;
                }
            }
        }

        /**
         * 获取下一个消息，如果没有则阻塞<br/>
         *
         * @return
         * @throws InterruptedException
         */
        protected abstract T nextEvent() throws InterruptedException;

        /**
         * 是否存在监听器列表<br/>
         *
         * @return
         */
        protected abstract boolean exitsListeners(T event);

        /**
         * 处理事件<br/>
         *
         * @param event
         */
        protected abstract void dispatch(T event) throws Exception;
    }

    private class SessionEventDispatcher extends BaseEventDispatcher<SessionEvent> {
        public SessionEventDispatcher() {
            super();
        }

        public SessionEventDispatcher(String name) {
            super(name);
        }

        @Override
        protected SessionEvent nextEvent() throws InterruptedException {
            return sessionEvents.take();
        }

        @Override
        protected boolean exitsListeners(SessionEvent event) {
            return !CollectionUtils.isEmpty(sessionListeners);
        }

        @Override
        protected void dispatch(SessionEvent event) {
            // 复制listener；
            final SessionListener[] list = sessionListeners.toArray(
                    new SessionListener[sessionListeners.size()]);

            if(LOG.isDebugEnabled()) {
                LOG.info("消费session消息： " + event);
            }

            // 消费；
            for(SessionListener listener : list) {
                if(event.getState() == Watcher.Event.KeeperState.Disconnected) {
                    listener.onDisconnected(event);
                } else if(event.getState() == Watcher.Event.KeeperState.SyncConnected) {
                    listener.onConnected(event);
                } else if(event.getState() == Watcher.Event.KeeperState.Expired) {
                    listener.onExpired(event);
                }
            }
        }
    }

    private class ChangeEventDispatcher extends BaseEventDispatcher<NodeChangeEvent> {
        public ChangeEventDispatcher() {
            super();
        }

        public ChangeEventDispatcher(String name) {
            super(name);
        }

        @Override
        protected NodeChangeEvent nextEvent() throws InterruptedException {
            return changeEvents.take();
        }

        @Override
        protected boolean exitsListeners(NodeChangeEvent event) {
            return !CollectionUtils.isEmpty(changeListeners.get(event.getPath()));
        }

        @Override
        protected void dispatch(NodeChangeEvent event) {
            // 复制listener；
            final ListenerNode[] list = changeListeners.get(event.getPath()).toArray(
                    new ListenerNode[0]);

            if(LOG.isDebugEnabled()) {
                LOG.info("消费node change消息： " + event);
            }

            // 消费；
            for(ListenerNode listener : list) {
                if(event.getType() == Watcher.Event.EventType.NodeCreated) {
                    listener.listener.onCreated(event);
                } else if(event.getType() == Watcher.Event.EventType.NodeDataChanged) {
                    listener.listener.onDataChanged(event);
                } else if(event.getType() == Watcher.Event.EventType.NodeDeleted) {
                    listener.listener.onDeleted(event);
                } else if(event.getType() == Watcher.Event.EventType.NodeChildrenChanged) {
                    listener.listener.onChildrenChanged(event);
                }

                // 继续监听永久性事件；
                if(listener.permanent) {
                    initializer.szk.addPermanentChangeListener(listener.path, listener.listener);
                }
            }
        }
    }

    // --------------------------------------------- inner class;
    static class ListenerNode {
        /**
         * 监听的路径<br/>
         *
         */
        public String path = null;

        /**
         * 回调处理器<br/>
         *
         */
        public NodeChangeListener listener = null;

        /**
         * 是否永久监听<br/>
         *
         */
        boolean permanent = false;

        public ListenerNode(String path, NodeChangeListener listener) {
            this(path, listener, false);
        }

        public ListenerNode(String path, NodeChangeListener listener, boolean permanent) {
            this.path = path;

            this.listener = listener;

            this.permanent = permanent;
        }

        @Override
        public boolean equals(Object obj) {
            if(!(obj instanceof ListenerNode)) {
                return false;
            }

            ListenerNode other = (ListenerNode) obj;

            return listener == other.listener && permanent == other.permanent;
        }

        @Override
        public String toString() {
            return super.toString();
        }
    }
}
