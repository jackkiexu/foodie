/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.config;

import com.zb.framework.cache.redisson.codec.RedissonHessianCodec;
import org.redisson.client.codec.Codec;

/**
 * Created by  2015/5/6.
 */
public abstract class RedissonConfig {
    /**
     * 连接超时时间<br/>
     *
     */
    private int timeout = 60000;

    /**
     * 重试次数<br/>
     *
     */
    private int retryAttempts = 5;

    /**
     * 重试时间周期<br/>
     *
     */
    private int retryInterval = 1000;

    /**
     * 数据库index<br/>
     *
     */
    private int database = 0;

    /**
     * 线程数<br/>
     *
     */
    private int threads = 0;

    private Codec codec = null;

    public RedissonConfig() {
        codec = new RedissonHessianCodec();
        //codec = new SerializationCodec();
    }

    /**
     * 验证配置的有效性<br/>
     *
     */
    public  void validate() {
        if(threads < 0) {
            throw new IllegalArgumentException("线程数量不能为负数");
        }

        if(database < 0) {
            throw new IllegalArgumentException("数据库索引不能为负数");
        }

        if(timeout <= 0) {
            throw new IllegalArgumentException("超时时间必须大于0");
        }

        if(retryAttempts <= 0) {
            throw new IllegalArgumentException("重试次数必须大于0");
        }

        if(retryInterval <= 0) {
            throw new IllegalArgumentException("重试周期必须大于0");
        }
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public int getRetryAttempts() {
        return retryAttempts;
    }

    public void setRetryAttempts(int retryAttempts) {
        this.retryAttempts = retryAttempts;
    }

    public int getRetryInterval() {
        return retryInterval;
    }

    public void setRetryInterval(int retryInterval) {
        this.retryInterval = retryInterval;
    }

    public int getDatabase() {
        return database;
    }

    public void setDatabase(int database) {
        this.database = database;
    }

    public Codec getCodec() {
        return codec;
    }

    public void setCodec(Codec codec) {
        this.codec = codec;
    }

    public int getThreads() {
        return threads;
    }

    public void setThreads(int threads) {
        this.threads = threads;
    }
}
