/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * Created by  2015/3/26.
 */
public class LargeRedFlag extends AbstractEnum implements Serializable {
    public static final LargeRedFlag No = new LargeRedFlag("0", "拒绝顺延");

    public static final LargeRedFlag Yes = new LargeRedFlag("1", "顺延");

    protected LargeRedFlag() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    protected LargeRedFlag(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return LargeRedFlag.class;
    }
}
