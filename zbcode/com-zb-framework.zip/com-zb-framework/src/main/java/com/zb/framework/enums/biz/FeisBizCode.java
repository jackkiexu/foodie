package com.zb.framework.enums.biz;

import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * Created by  on 2015/4/29.
 */
public class FeisBizCode extends BizCode implements Serializable {

    /**  */
    private static final long serialVersionUID = 7960660079710190368L;

    public FeisBizCode(){}

    public static final BizCode INVOKE_SYS_FMD_ERROR= new FeisBizCode("INVOKE_SYS_FMD_ERROR", ServiceCode.PaymentFeis,"001","INFO调用主数据失败");

    public static final BizCode INVOKE_SYS_MGW_FAIL = new FeisBizCode("INVOKE_SYS_MGW_FAIL",ServiceCode.PaymentFeis,"002","INFO调用网关失败");

    public static final BizCode INVOKE_SYS_MGW_ERROR = new FeisBizCode("INVOKE_SYS_MGW_ERROR",ServiceCode.PaymentFeis,"009","INFO调用网关失败");

    public static final BizCode INVOKE_SYS_CIF_ERROR= new FeisBizCode("INVOKE_SYS_CIF_ERROR",ServiceCode.PaymentFeis,"003","INFO调用会员失败");

    public static final BizCode INVOKE_SYS_ROUTER_ERROR = new FeisBizCode("INVOKE_SYS_ROUTER_ERROR",ServiceCode.PaymentFeis,"004","INFO调用路由失败");

    public static final BizCode FMD_CHANNEL_NOT_SET = new FeisBizCode("FMD_CHANNEL_NOT_SET",ServiceCode.PaymentFeis,"005","INFO主数据渠道未配置");

    public static final BizCode AGREEMENT_NO_CREATE_FAIL = new FeisBizCode("AGREEMENT_NO_CREATE_FAIL",ServiceCode.PaymentFeis,"006","INFO签约协议号生成失败");

    public static final BizCode SIGN_MASTER_NOT_EXIST = new FeisBizCode("SIGN_MASTER_NOT_EXIST",ServiceCode.PaymentFeis,"007","INFO签约流水不存在");

    public static final BizCode SIGN_CHANNEL_PHASE_NOT_SET = new FeisBizCode("SIGN_CHANNEL_PHASE_NOT_SET",ServiceCode.PaymentFeis,"008","INFO签约短信发送模板未配置");

    public static final BizCode INVOKE_SYS_FMD_QUERY_BANK_RESP_CODE_UNKNOWN = new FeisBizCode("INVOKE_SYS_FMD_QUERY_BANK_RESP_CODE_UNKNOWN",ServiceCode.PaymentFeis,"013","INFO调用主数据，返回码未知");

    public static final BizCode INVOKE_SYS_BASIC_BUILD_SEDN_SMS_ERROR = new FeisBizCode("INVOKE_SYS_BASIC_BUILD_SEDN_SMS_ERROR",ServiceCode.PaymentFeis,"010","INFO调用basic生成发送短信验证码失败");

    public static final BizCode INVOKE_SYS_BASIC_BUILD_SMS_ERROR = new FeisBizCode("INVOKE_SYS_BASIC_BUILD_SMS_ERROR",ServiceCode.PaymentFeis,"011","INFO调用basic生成短信验证码失败");

    public static final BizCode INVOKE_SYS_BASIC_SEND_SMS_ERROR = new FeisBizCode("INVOKE_SYS_BASIC_SEND_SMS_ERROR",ServiceCode.PaymentFeis,"012","INFO调用basic发送短信验证码失败");

    public static final BizCode INVOKE_SYS_BCDC_ERROR = new FeisBizCode("INVOKE_SYS_BCDC_ERROR",ServiceCode.PaymentFeis,"017","INFO调用bcdc失败");

    public static final BizCode INVOKE_SYS_BASIC_VERIFY_SMS_ERROR = new FeisBizCode("INVOKE_SYS_BASIC_VERIFY_SMS_ERROR",ServiceCode.PaymentFeis,"014","INFO调用basic校验短信验证码失败");

    public static final BizCode FMD_TERM_CHANNEL_NOT_FIND = new FeisBizCode("FMD_TERM_CHANNEL_NOT_FIND",ServiceCode.PaymentFeis,"015","INFO调用fmd,未找到解约渠道");

    public static final BizCode INVOKE_SYS_BCDC_UPDATE_SIGN_INFO_ERROR = new FeisBizCode("INVOKE_SYS_BCDC_UPDATE_SIGN_INFO_ERROR",ServiceCode.PaymentFeis,"016","INFO调用bcdc,更新签约信息失败");

    public static final BizCode Feis_cacheRefresh_fail = new FeisBizCode("Feis_cacheRefresh_fail",ServiceCode.PaymentFeis,"018","金融信息缓存刷新失败");

    public FeisBizCode(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }
}
