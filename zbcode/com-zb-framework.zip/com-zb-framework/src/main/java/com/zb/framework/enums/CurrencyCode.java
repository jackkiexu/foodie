package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;
import java.util.Currency;

/**
 * 货币编码<br/>
 *
 * Created by  2015/1/20.
 */
public final class CurrencyCode extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = 1627256884311058012L;

    public static final CurrencyCode CNY = new CurrencyCode("CNY", "156", "人民币");

    public static final CurrencyCode EUR = new CurrencyCode("EUR", "978", "欧元");

    public static final CurrencyCode GBP = new CurrencyCode("GBP", "826", "英镑");

    public static final CurrencyCode HKD = new CurrencyCode("HKD", "344", "港元");

    public static final CurrencyCode JPY = new CurrencyCode("JPY", "392", "日元");

    public static final CurrencyCode USD = new CurrencyCode("USD", "840", "美元");

    protected CurrencyCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    public CurrencyCode(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return CurrencyCode.class;
    }

    /**
     * 通过枚举的name获取货币类型<br/>
     *
     * <pre>
     *     CurrencyCode.byName("CNY");
     * </pre>
     * @param name
     * @return
     */
    public static Currency byName(String name) {
        final CurrencyCode cc = CurrencyCode.valueOf(CurrencyCode.class, name);
        if(cc != null) {
            return Currency.getInstance(cc.name());
        }

        return null;
    }

    /**
     * 通过枚举的name获取货币类型<br/>
     *
     * <pre>
     *     CurrencyCode.byName("156");
     * </pre>
     * @param code
     * @return
     */
    public static Currency byCode(String code) {
        final CurrencyCode cc = CurrencyCode.valueByCode(CurrencyCode.class, code);
        if(cc != null) {
            return Currency.getInstance(cc.name());
        }

        return null;
    }
}
