package com.zb.framework.enums.product;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 业务控制类型枚举<br/>
 *
 */
public class InnerControlBusiType extends AbstractCodedEnum implements Serializable {

    public static final InnerControlBusiType OpenDay = new InnerControlBusiType("01","01", "开放日管理");
    public static final InnerControlBusiType LargePurchase = new InnerControlBusiType("02","02", "大额限购管理");
    public static final InnerControlBusiType SuspendTrade = new InnerControlBusiType("03","03", "暂停交易管理");


    protected InnerControlBusiType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    public InnerControlBusiType(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return InnerControlBusiType.class;
    }
}
