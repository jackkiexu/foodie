package com.zb.framework.framework.pigeon.template;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import com.zb.framework.framework.pigeon.xmap.annotation.spring.XMapSpring;

public class TemplateBean implements Serializable {
	private static final Logger logger = LoggerFactory.getLogger(TemplateBean.class);

	private static final long serialVersionUID = -3131022211140649796L;

	private TemplateManager templateManager;

	private Element content;
	
	private String type;

	public String getType() {
		return type;
	}

	public TemplateManager getTemplateManager() {
		return templateManager;
	}

	public void setTemplateManager(TemplateManager templateManager) {
		this.templateManager = templateManager;
	}

	public Element getContent() {
		return content;
	}

	public void setContent(Element content) {
		this.content = content;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void init() {

		XMapSpring xmap = new XMapSpring();
		xmap.register(TemplateDescriptor.class,
				templateManager.getApplicationContext());

		try {

			TemplateDescriptor template = (TemplateDescriptor) xmap.load(content);
			
			logger.debug(template.toString());

			templateManager.registerTemplate(template);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
