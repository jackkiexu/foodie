/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 
 * @author 
 * @version $Id: RouterBizCode.java, v 0.1 2015年5月30日 下午2:53:22  Exp $
 */
public class RouterBizCode extends BizCode{

    /**  */
    private static final long serialVersionUID = 8494433492840183882L;
    
    public static final RouterBizCode RtNoUsedChannels=new RouterBizCode("RtNoUsedChannels",ServiceCode.Router,"001","没有可用的渠道");
    
    public static final RouterBizCode RtNoUsedSignInfos=new RouterBizCode("RtNoUsedSignInfos",ServiceCode.Router,"002","会员签约信息不存");
    
    public static final RouterBizCode RtRouterInfoNotExist=new RouterBizCode("RtRouterInfoNotExist",ServiceCode.Router,"003","路由信息不存在");
    
    public static final RouterBizCode Router_Cache_Refresh_Fail=new RouterBizCode("Router_Cache_Refresh_Fail",ServiceCode.Router,"004","缓存刷新失败");
    
    public static final RouterBizCode RouterGetChargeFeeFail=new RouterBizCode("RouterGetChargeFeeFail",ServiceCode.Router,"005","获取产品费率失败");
    
    public static final RouterBizCode RtUnkown=new RouterBizCode("RtUnkown",ServiceCode.Router,"999","路由未知异常");
    
    
    
    protected RouterBizCode() {
        ;
    }
    
    /**
     * @param name
     * @param service
     * @param code
     * @param desc
     */
    public RouterBizCode(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }

}
