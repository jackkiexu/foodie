/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import java.io.Serializable;

import com.zb.framework.base.AbstractEnum;

/**
 * 
 * @author 
 * @version $Id: FxoStatus.java, v 0.1 2015年1月23日 下午9:46:21  Exp $
 */
public final class FxoStatus extends AbstractEnum implements Serializable {

    /**  */

    private static final long      serialVersionUID = -879914911550006998L;

    public static final FxoStatus U     = new FxoStatus("U", "预计");
    public static final FxoStatus S     = new FxoStatus("S", "成功");
    public static final FxoStatus F     = new FxoStatus("F", "失败");
    public static final FxoStatus P     = new FxoStatus("P", "处理中");
    public static final FxoStatus R     = new FxoStatus("R", "反向");
    public static final FxoStatus Q     = new FxoStatus("Q", "队列中");
    public static final FxoStatus T     = new FxoStatus("T", "超时");


    protected FxoStatus() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected FxoStatus(String name, String desc) {
        super(name, desc);
    }

    /** 
     * @see com.zb.framework.base.AbstractEnum#getEnumType()
     */
    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return FxoStatus.class;
    }

}
