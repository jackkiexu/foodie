/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk;

import com.zb.framework.zk.event.NodeChangeListener;
import com.zb.framework.zk.event.SessionListener;
import com.zb.framework.zk.util.ZooKeeperException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

import java.util.List;

/**
 *
 * Created by  2015/5/1.
 */
public interface SafeZooKeeper {
    /**
     * 添加session事件回调句柄<br/>
     *
     * @param listener
     */
    void addSessionListener(SessionListener listener);

    /**
     * 添加一次性节点事件回调句柄<br/>
     *
     * @param path
     * @param listener
     */
    void addChangeListener(String path, NodeChangeListener listener);

    /**
     * 添加永久性节点事件回调句柄<br/>
     *
     * @param path
     * @param listener
     */
    void addPermanentChangeListener(String path, NodeChangeListener listener);

    /**
     * 创建zk节点并设置节点数据<br/>
     *
     * @param path
     * @param data
     * @param createMode
     * @throws com.zb.framework.zk.util.ZooKeeperException
     */
    void create(String path, byte data[], CreateMode createMode) throws ZooKeeperException;

    /**
     * 递归创建所有不存在的zk节点并设置最后节点的数据<br/>
     *
     * @param path
     * @param data
     * @param createMode
     * @throws com.zb.framework.zk.util.ZooKeeperException
     */
    void createRecursive(String path, byte data[], CreateMode createMode) throws ZooKeeperException;

    /**
     * 获取节点的状态数据<br/>
     *
     * @param path
     * @param watch
     * @return
     * @throws com.zb.framework.zk.util.ZooKeeperException
     */
    Stat exists(String path, boolean watch) throws ZooKeeperException;

    /**
     * 获取节点的数据<br/>
     *
     * @param path
     * @param watch
     * @param stat
     * @return
     * @throws com.zb.framework.zk.util.ZooKeeperException
     */
    byte[] getData(String path, boolean watch, Stat stat) throws ZooKeeperException;

    /**
     * 获取所有子节点path<br/>
     *
     * @param path
     * @param watch
     * @return
     * @throws com.zb.framework.zk.util.ZooKeeperException
     */
    List<String> getChildren(String path, boolean watch) throws ZooKeeperException;

    /**
     * 获取所有子节点path<br/>
     *
     * @param path
     * @param watch
     * @param stat
     * @return
     * @throws com.zb.framework.zk.util.ZooKeeperException
     */
    List<String> getChildren(String path, boolean watch, Stat stat) throws ZooKeeperException;

    /**
     * 删除节点<br/>
     *
     * @param path
     * @param version
     * @throws com.zb.framework.zk.util.ZooKeeperException
     */
    void delete(final String path, int version) throws ZooKeeperException;

    /**
     * 删除节点的所有版本<br/>
     *
     * @param path
     * @throws com.zb.framework.zk.util.ZooKeeperException
     */
    void deleteAll(final String path) throws ZooKeeperException;

    /**
     * 设置节点数据<br/>
     *
     * @param path
     * @param data
     * @param version
     * @return
     * @throws ZooKeeperException
     */
    Stat setData(final String path, byte data[], int version) throws ZooKeeperException;
}
