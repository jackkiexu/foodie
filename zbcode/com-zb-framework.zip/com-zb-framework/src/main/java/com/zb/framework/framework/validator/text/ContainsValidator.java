package com.zb.framework.framework.validator.text;

import com.zb.framework.enums.BizCode;
import com.zb.framework.framework.validator.Validator;
import com.zb.framework.framework.validator.base.AbstractValidator;
import com.zb.framework.util.CoreCommonUtils;

/**
 * Created by  2014/12/15.
 */
public class ContainsValidator extends AbstractValidator implements Validator {
    public ContainsValidator(String referObject) {
        super(referObject);

        if(referObject == null) {
            CoreCommonUtils.raiseValidateException(BizCode.ParamNotNull, "子字符串不能为null");
        }
    }

    @Override
    public boolean doValidate(Object target) {
        if(target == null || !(target instanceof CharSequence)) {
            return false;
        }

        return ((CharSequence)target).toString().indexOf((String)getReferObject()) >= 0;
    }
}
