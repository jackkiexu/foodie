/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.config;

import com.zb.framework.util.CoreSystemUtils;

/**
 * Created by  2015/5/6.
 */
public abstract class MultiConfig extends RedissonConfig {
    /**
     * slave连接池大小<br/>
     *
     */
    private int slaveConnectionPoolSize = 100;

    /**
     * master连接池大小<br/>
     *
     */
    private int masterConnectionPoolSize = 100;

    /**
     * 组名<br/>
     *
     */
    private String groupName = null;

    public MultiConfig() {
        groupName = CoreSystemUtils.objectId();
    }

    public int getSlaveConnectionPoolSize() {
        return slaveConnectionPoolSize;
    }

    public void setSlaveConnectionPoolSize(int slaveConnectionPoolSize) {
        this.slaveConnectionPoolSize = slaveConnectionPoolSize;
    }

    public int getMasterConnectionPoolSize() {
        return masterConnectionPoolSize;
    }

    public void setMasterConnectionPoolSize(int masterConnectionPoolSize) {
        this.masterConnectionPoolSize = masterConnectionPoolSize;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    @Override
    public void validate() {
        if(slaveConnectionPoolSize <= 0) {
            throw new IllegalArgumentException("slave连接池大小必须大于0");
        }

        if(masterConnectionPoolSize <= 0) {
            throw new IllegalArgumentException("master连接池大小必须大于0");
        }
    }

    @Override
    public String toString() {
        return "MultiConfig{" +
                "slaveConnectionPoolSize=" + slaveConnectionPoolSize +
                ", masterConnectionPoolSize=" + masterConnectionPoolSize +
                "} " + super.toString();
    }
}
