/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import java.io.Serializable;

import com.zb.framework.base.AbstractEnum;

/**
 * 支付状态
 * @author 
 * @version $Id: PayStatus.java, v 0.1 2015年1月20日 下午5:38:43  Exp $
 */
public class PayStatus extends AbstractEnum implements Serializable{
    
    

    /**  */
    private static final long serialVersionUID = 4853051436575845865L;
    
    public static final PayStatus Initial=new PayStatus("N","初始化");
    public static final PayStatus Success=new PayStatus("S","成功");
    public static final PayStatus PerSuccess=new PayStatus("B","预处理成功");
    public static final PayStatus Fail=new PayStatus("F","失败");
    public static final PayStatus Pending=new PayStatus("P","处理中");
    
    
    
    protected PayStatus(){
        ;
    }
    
    protected PayStatus(String name,String desc){
        super(name,desc);
    }

    /** 
     * @see com.zb.framework.base.AbstractEnum#getEnumType()
     */
    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return PayStatus.class;
    }

}
