/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.kernel;

/**
 * zk配置信息<br/>
 *
 *
 * Created by  2015/4/28.
 */
public class ZkConfig {
    /**
     * zk服务器列表<br/>
     *
     */
    private String connection = null;

    /**
     * zk session超时时间<br/>
     *
     */
    private Integer sessionTimeout = null;

    /**
     * 用户名<br/>
     *
     */
    private String userName = null;

    /**
     * 密码<br/>
     *
     */
    private String password = null;

    public String getConnection() {
        return connection;
    }

    public void setConnection(String connection) {
        this.connection = connection;
    }

    public Integer getSessionTimeout() {
        return sessionTimeout;
    }

    public void setSessionTimeout(Integer sessionTimeout) {
        this.sessionTimeout = sessionTimeout;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "ZkConfig{" +
                "connection='" + connection + '\'' +
                ", sessionTimeout=" + sessionTimeout +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
