
package com.zb.framework.framework.pigeon.xmap;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

public class XMethodSetter implements XSetter {

    /** method */
    private final Method method;

    public XMethodSetter(Method method) {
        this.method = method;
        this.method.setAccessible(true);
    }

    public Class<?> getType() {
        return method.getParameterTypes()[0];
    }

    public void setValue(Object instance, Object value) throws IllegalAccessException,
                                                       InvocationTargetException {
        method.invoke(instance, value);
    }

}
