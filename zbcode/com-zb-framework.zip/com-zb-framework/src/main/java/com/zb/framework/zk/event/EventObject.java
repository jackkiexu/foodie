/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.event;

import com.zb.framework.zk.kernel.SafeZooKeeper;
import org.apache.zookeeper.Watcher;

/**
 * Created by  2015/4/28.
 */
public abstract class EventObject {
    /**
     * zk实例<br/>
     *
     */
    private SafeZooKeeper zooKeeper = null;

    /**
     * zk状态<br/>
     *
     */
    private Watcher.Event.KeeperState state = null;

    public SafeZooKeeper getZooKeeper() {
        return zooKeeper;
    }

    public void setZooKeeper(SafeZooKeeper zooKeeper) {
        this.zooKeeper = zooKeeper;
    }

    public Watcher.Event.KeeperState getState() {
        return state;
    }

    public void setState(Watcher.Event.KeeperState state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "EventObject{" +
                "zooKeeper=" + zooKeeper +
                ", state=" + state +
                '}';
    }
}
