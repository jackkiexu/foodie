/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 
 * @author 
 * @version $Id: FxoBizCodeEnum.java, v 0.1 2015年2月5日 下午7:56:41  Exp $
 */
public class FxoBizCodeEnum extends BizCode{
    
    /**  */
    private static final long serialVersionUID = 5686930753492462215L;
    
    public static final FxoBizCodeEnum WithDrawPrePareExp=new  FxoBizCodeEnum("WithDrawPrePareExp",ServiceCode.Fxo,"001","提现信息初始化异常");
    public static final FxoBizCodeEnum GenThirdSeqExp=new  FxoBizCodeEnum("GenThirdSeqExp",ServiceCode.Fxo,"002","第三方流水生成失败");
    public static final FxoBizCodeEnum NoUpdateForWithdrawManualFlag=new  FxoBizCodeEnum("NoUpdateForWithdrawManualFlag",ServiceCode.Fxo,"003","没有更新提现表中人工处理的状态");
    public static final FxoBizCodeEnum NoUpdateForManualFlag=new  FxoBizCodeEnum("NoUpdateForManualFlag",ServiceCode.Fxo,"004","没有更新到人工处理状态");
    public static final FxoBizCodeEnum ManualFlagNotFinalState=new  FxoBizCodeEnum("ManualFlagNotFinalState",ServiceCode.Fxo,"005","人工处理状态为终态");
    public static final FxoBizCodeEnum FxoDataSaveFail=new  FxoBizCodeEnum("FxoDataSaveFail",ServiceCode.Fxo,"006","数据保存失败");
    public static final FxoBizCodeEnum CreateReconFileError=new  FxoBizCodeEnum("CreateReconFileError",ServiceCode.Fxo,"007","创建对账文件失败");
    public static final FxoBizCodeEnum RenameReconFileError=new  FxoBizCodeEnum("RenameReconFileError",ServiceCode.Fxo,"008","文件重命名失败");
    
    
    public static final FxoBizCodeEnum Fxo_Cache_Refresh_Fail=new  FxoBizCodeEnum("Fxo_Cache_Refresh_Fail",ServiceCode.Fxo,"009","缓存刷新失败");
    public static final FxoBizCodeEnum FxoParamIsNull=new  FxoBizCodeEnum("FxoParamIsNull",ServiceCode.Fxo,"010","请求参数为空");
    public static final FxoBizCodeEnum FxoDataNoExist=new  FxoBizCodeEnum("FxoDataNoExist",ServiceCode.Fxo,"011","数据不存在");
    public static final FxoBizCodeEnum FxoDataNoMatch=new  FxoBizCodeEnum("FxoDataNoMatch",ServiceCode.Fxo,"012","数据不一致");
    public static final FxoBizCodeEnum FxoResendPartErr=new  FxoBizCodeEnum("FxoResendPartErr",ServiceCode.Fxo,"013","重发部分异常");
    
    public static final FxoBizCodeEnum FxoSwithPartErr=new  FxoBizCodeEnum("FxoSwithPartErr",ServiceCode.Fxo,"014","转人工部分失败");
    public static final FxoBizCodeEnum FxoSwithErr=new  FxoBizCodeEnum("FxoSwithErr",ServiceCode.Fxo,"015","转人工失败");
    public static final FxoBizCodeEnum FxoDateDeleteFail=new  FxoBizCodeEnum("FxoDateDeleteFail",ServiceCode.Fxo,"016","数据删除失败");
    public static final FxoBizCodeEnum FxoDateUpdateFail=new  FxoBizCodeEnum("FxoDateUpdateFail",ServiceCode.Fxo,"017","数据更新失败");
    public static final FxoBizCodeEnum FxoMailSendTypeError=new  FxoBizCodeEnum("FxoMailSendTypeError",ServiceCode.Fxo,"018","邮件发送类型不正确");
    
    public static final FxoBizCodeEnum Fxo_Unknown=new  FxoBizCodeEnum("Fxo_Unknown",ServiceCode.Fxo,"999","交易未知或处理中");
    

    
    protected FxoBizCodeEnum() {
        ;
    }
    
    public FxoBizCodeEnum(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }

}
