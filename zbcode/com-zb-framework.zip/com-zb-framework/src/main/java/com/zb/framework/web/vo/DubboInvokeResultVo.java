package com.zb.framework.web.vo;

import java.io.Serializable;

/**
 * Created by  2014/9/23.
 */
public class DubboInvokeResultVo implements Serializable {
    private static final long serialVersionUID = 1505838029410834893L;

    public DubboInvokeResultVo(Object result) {
        this.result = result;
    }
    private Object result = null;

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }
}
