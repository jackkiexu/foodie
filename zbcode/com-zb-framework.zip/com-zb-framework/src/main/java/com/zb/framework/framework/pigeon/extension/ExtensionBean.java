package com.zb.framework.framework.pigeon.extension;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import com.zb.framework.framework.pigeon.xmap.annotation.spring.XMapSpring;

public class ExtensionBean {

	private static final Logger logger = LoggerFactory.getLogger(ExtensionBean.class);

	private String point;

	private DefaultExtension bean;

	private Element content;

	public void init() {

		XMapSpring xmap = new XMapSpring();
		xmap.register(bean.getDescriptorClass(),bean.getApplicationContext());
	
		try {
	
			Object contribution = xmap.load(content);

			bean.registerContribution(contribution, point);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	public String getPoint() {
		return point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	public DefaultExtension getBean() {
		return bean;
	}

	public void setBean(DefaultExtension bean) {
		this.bean = bean;
	}

	public Element getContent() {
		return content;
	}

	public void setContent(Element content) {
		this.content = content;
	}
}
