/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson;

/**
 * Created by  2015/5/6.
 */
public interface RedissonContainer {
    /**
     * 获取redission客户端<br/>
     *
     * @param name
     * @return
     */
    org.redisson.Redisson get(String name);

    /**
     * 关闭服务<br/>
     *
     */
    void shutdown();
}
