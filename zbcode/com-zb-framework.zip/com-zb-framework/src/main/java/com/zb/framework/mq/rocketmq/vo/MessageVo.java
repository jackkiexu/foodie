package com.zb.framework.mq.rocketmq.vo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * 消息实例<br/>
 *
 * Created by  2015/1/15.
 */
public class MessageVo<T extends Serializable> implements Serializable {
    private static final long serialVersionUID = 2935552366763067433L;

    /**
     * 消息body<br/>
     *
     */
    private T message = null;

    /**
     * 消息Id值<br/>
     *
     */
    private String messageId = null;

    /**
     * 消息Tags<br/>
     *
     */
    private String tags = null;

    /**
     * 消息的索引key值<br/>
     *
     */
    private String keys = null;

    /**
     * 消息主题名称<br/>
     *
     */
    private String topicName = null;

    private Map<String,String> extFields = new HashMap<>(8, 1F);

    public T getMessage() {
        return message;
    }

    public void setMessage(T message) {
        this.message = message;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getKeys() {
        return keys;
    }

    public void setKeys(String keys) {
        this.keys = keys;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public void copy(Map<String, String> extFields) {
        if(extFields != null) {
            this.extFields.putAll(extFields);
        }
    }

    public Map<String, String> getExtFields() {
        return extFields;
    }

    public String getExtField(String key) {
        return this.extFields.get(key);
    }

    @Override
    public String toString() {
        return "MessageVo{" +
                "message=" + message +
                ", messageId='" + messageId + '\'' +
                ", tags='" + tags + '\'' +
                ", keys='" + keys + '\'' +
                ", topicName='" + topicName + '\'' +
                '}';
    }
}
