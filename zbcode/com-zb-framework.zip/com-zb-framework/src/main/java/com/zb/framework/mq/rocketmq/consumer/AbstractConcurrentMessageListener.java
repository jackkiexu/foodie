package com.zb.framework.mq.rocketmq.consumer;

import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.common.message.MessageConst;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.zb.framework.mq.rocketmq.vo.MessageVo;
import com.zb.framework.serialize.Serializer;
import com.zb.framework.util.CoreThreadLocalUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 消费者的抽象实现<br/>
 *
 * Created by  2015/1/14.
 */
public abstract class AbstractConcurrentMessageListener<T extends Serializable>
        implements MessageListenerConcurrently, InnerMessageListener<T>, InitializingBean {
    private static final Logger LOG = LoggerFactory.getLogger(AbstractConcurrentMessageListener.class);

    private Serializer serializer = null;

    @Override
    public ConsumeConcurrentlyStatus consumeMessage(
            List<MessageExt> msgs, ConsumeConcurrentlyContext context) {

        boolean isNew = false;
        try {
            CoreThreadLocalUtils.initialize(getTLSClass());

            LOG.info(CoreThreadLocalUtils.logPrefix() + "接受消息数量：" + msgs.size());

            for(MessageExt message : msgs) {
                final Map<String, String> properties = message.getProperties();
                // 设置当前线程的uuid，与远程的thread同步；
                // NOTE: 不需要同步，在client中进行同步！！
                //setUuid(properties.get(CoreConstants.Curr_Thread_Uuid_Key));

                Serializable object = serializer.deserialize(message.getBody());

                MessageVo<T> $message = new MessageVo<>();
                $message.setTags(message.getTags());
                $message.setMessageId(message.getMsgId());
                $message.setMessage((T)object);
                $message.setKeys(message.getKeys());
                $message.setTopicName(message.getTopic());
                $message.copy(filter(message, properties));

                consume($message);
            }
        } catch (Exception ex) {
            LOG.warn(CoreThreadLocalUtils.logPrefix() + "消费消息异常", ex);

            if(retryWhenException()) {
                return ConsumeConcurrentlyStatus.RECONSUME_LATER;
            } else {
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            }
        } finally {
            CoreThreadLocalUtils.clean(isNew);
        }

        return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
    }

    /**
     * 过滤扩展参数<br/>
     *
     * @param message
     * @param properties
     * @return
     */
    protected Map<String, String> filter(MessageExt message, Map<String, String> properties) {
        if(properties == null || properties.isEmpty()) {
            return Collections.emptyMap();
        }

        Map<String, String> result = new HashMap<>(properties.size(), 1F);
        for(Map.Entry<String,String> entry : properties.entrySet()) {
            String key = entry.getKey();
            if(!MessageConst.systemKeySet.contains(key)
                    && (key != null && key.indexOf("__") < 0)) {
                result.put(key, entry.getValue());
            }
        }

        return result;
    }

    @Override
    public abstract void consume(MessageVo<T> message);

    /**
     * TLS实例类型<br/>
     *
     * @return
     */
    protected Class<?> getTLSClass() {
        return null;
    }

    public Serializer getSerializer() {
        return serializer;
    }

    public void setSerializer(Serializer serializer) {
        this.serializer = serializer;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        /*if(null == serializer) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "消息序列化实例不能为null");
        }*/
    }

    /**
     * 消息处理失败了是否重新消费<br/>
     *
     * @return
     */
    protected boolean retryWhenException() {
        return false;
    }

    // ---------------------------------------- primate methods
    private static void setUuid(String uuid) {
        try {
            if(set_uuid != null) {
                set_uuid.invoke(null, uuid);
            }
        } catch (Exception e) {
            ; // ignore
        }
    }

    private static Method set_uuid = null;
    static {
        try {
            final Class<?> clazz = Class.forName(
                    "com.qiangungun.monitor.client.util.MContextUtils");
            set_uuid = clazz.getDeclaredMethod("setUuid", String.class);
        } catch (Exception e) {
            ; // ignore
        }
    }
}
