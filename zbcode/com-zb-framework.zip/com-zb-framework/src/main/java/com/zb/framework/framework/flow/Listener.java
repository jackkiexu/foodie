package com.zb.framework.framework.flow;

/**
 * Pipe line的事件回调接口<br/>
 *
 * Created by  2014/12/10.
 */
public interface Listener {

}
