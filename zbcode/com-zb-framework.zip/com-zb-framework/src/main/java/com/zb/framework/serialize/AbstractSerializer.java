package com.zb.framework.serialize;

import com.zb.framework.enums.BizCode;
import com.zb.framework.util.CoreCommonUtils;

import java.io.Serializable;

/**
 * 序列化/反序列化抽象实现<br/>
 *
 * Created by  2015/1/13.
 */
public abstract class AbstractSerializer implements Serializer {
    @Override
    public final byte[] serialize(Serializable object) {
        /*if(object == null) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "序列化对象不能为null");
        }*/

        return doSerialize(object);
    }

    /**
     * 执行具体的序列化逻辑<br/>
     *
     * @param object
     * @return
     */
    protected abstract byte[] doSerialize(Serializable object);

    @Override
    public final Serializable deserialize(byte[] bin) {
        if(bin == null) {
            CoreCommonUtils.raiseBizException(BizCode.ParamNotNull, "反序列化字节不能为null");
        }

        return doDeserialize(bin);
    }

    /**
     * 执行具体的反序列化逻辑<br/>
     *
     * @param bin
     * @return
     */
    protected abstract Serializable doDeserialize(byte[] bin);
}
