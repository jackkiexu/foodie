package com.zb.framework.framework.flow;

import com.zb.framework.base.AbstractRequest;

/**
 * 工作流程模板接口<br/>
 *
 * Created by  2014/12/10.
 */
public interface PipelineTemplate<TReq extends AbstractRequest> {
    /**
     * 根据预定义的配置，构造一个工作流程chain<br/>
     *
     * @return
     */
    OutboundInvoker create(TReq request);
}
