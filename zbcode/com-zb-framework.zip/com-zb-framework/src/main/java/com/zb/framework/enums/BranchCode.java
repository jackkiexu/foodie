package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 收单网点<br/>
 *
 * Created by  2014/12/27.
 */
public final class BranchCode extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = -1544322127142302649L;

    public static BranchCode QianGunGun = new BranchCode("QianGunGun", "0001", "官网");

    protected BranchCode() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return BranchCode.class;
    }

    protected BranchCode(String name, String code, String desc) {
        super(name, code, desc);
    }
}
