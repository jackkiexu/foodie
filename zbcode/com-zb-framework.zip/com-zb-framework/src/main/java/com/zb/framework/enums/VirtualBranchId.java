/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 模拟（虚拟）的渠道Id编码<br/>
 *
 * Created by  2015/9/22.
 */
public class VirtualBranchId extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = 8363867335466152030L;

    public static VirtualBranchId GQB = new VirtualBranchId("GQB"
            , "GQBFUNDS|11111", "GQBFUNDS", "11111", "滚钱宝渠道");

    public static VirtualBranchId Bonus = new VirtualBranchId("Bonus"
            , "BonusV|21111", "BonusV", "21111", "红包渠道");

    private String branchId = null;

    private String channelType = null;

    protected VirtualBranchId() {
        super();
    }

    protected VirtualBranchId(String name, String code
            , String branchId, String channelType, String desc) {
        super(name, code, desc);

        this.branchId = branchId;
        this.channelType = channelType;
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return VirtualBranchId.class;
    }

    public String branchId() {
        return branchId;
    }

    public String channelType() {
        return channelType;
    }
}
