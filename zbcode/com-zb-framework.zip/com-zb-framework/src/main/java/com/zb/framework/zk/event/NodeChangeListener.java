/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.zk.event;

/**
 * 节点变化事件<br/>
 *
 * Created by  2015/4/28.
 */
public interface NodeChangeListener {
    /**
     * 节点已经创建成功时触发此事件<br/>
     *
     * @param event
     */
    void onCreated(NodeChangeEvent event);

    /**
     * 节点已经删除成功时触发此事件<br/>
     *
     * @param event
     */
    void onDeleted(NodeChangeEvent event);

    /**
     * 节点的数据已经变化时触发此事件<br/>
     *
     * @param event
     */
    void onDataChanged(NodeChangeEvent event);

    /**
     * 节点的子节点已经变化（包括子节点有创建、删除、数据变化）时触发此事件<br/>
     *
     * @param event
     */
    void onChildrenChanged(NodeChangeEvent event);
}
