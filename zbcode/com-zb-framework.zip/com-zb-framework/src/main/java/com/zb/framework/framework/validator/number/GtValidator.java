package com.zb.framework.framework.validator.number;

import com.zb.framework.framework.validator.Validator;

/**
 * Created by  2014/12/15.
 */
public class GtValidator extends AbstractNumberValidator implements Validator {
    public GtValidator(Object referObject) {
        super(referObject);
    }

    @Override
    protected Type getType() {
        return Type.GT;
    }
}
