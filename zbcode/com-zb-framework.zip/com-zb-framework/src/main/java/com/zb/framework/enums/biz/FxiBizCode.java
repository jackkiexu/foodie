package com.zb.framework.enums.biz;

import java.io.Serializable;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

public class FxiBizCode extends BizCode implements Serializable{
    /**  */
    private static final long serialVersionUID = -5779219812272255940L;
    
    public static final FxiBizCode COMMON_FAIL=new FxiBizCode("COMMON_FAIL",ServiceCode.Fxi,"002","交易失败");
    
    public static final FxiBizCode SYSTEM_ERROR=new FxiBizCode("SYSTEM_ERROR",ServiceCode.Fxi,"099","系统异常");
    
    public static final FxiBizCode Fxi_Unknown=new FxiBizCode("Fxi_Unknown",ServiceCode.Fxi,"999","交易未知或处理中");
   
    public static final FxiBizCode NOT_NULL=new FxiBizCode("NOT_NULL",ServiceCode.Fxi,"062","违反非空约束");
    
    public static final FxiBizCode PROCESS_TEMPLATE_NULL=new FxiBizCode("PROCESS_TEMPLATE_NULL",ServiceCode.Fxi,"005","获取流程模板失败");
    
    public static final FxiBizCode PROCESS_EXECUTOR_NULL=new FxiBizCode("PROCESS_EXECUTOR_NULL",ServiceCode.Fxi,"006","流程执行器为空");
    
    public static final FxiBizCode INVALID_PARAMETER=new FxiBizCode("INVALID_PARAMETER",ServiceCode.Fxi,"060","请求数据格式非法");
    
    public static final FxiBizCode REQUEST_IDENTIFY_NULL=new FxiBizCode("REQUEST_IDENTIFY_NULL",ServiceCode.Fxi,"008","请求数据格式非法");
    
    public static final FxiBizCode REQUEST_IDENTIFY_UNABLE=new FxiBizCode("REQUEST_IDENTIFY_UNABLE",ServiceCode.Fxi,"009","请求方身份不可用");
    
    public static final FxiBizCode SIGN_VERIFY_FAIL=new FxiBizCode("SIGN_VERIFY_FAIL",ServiceCode.Fxi,"010","验签失败");
    
    public static final FxiBizCode CONNECT_TIMEOUT=new FxiBizCode("CONNECT_TIMEOUT",ServiceCode.Fxi,"011","连接超时失效");
    
    public static final FxiBizCode BANK_CODE_NOT_EXSIT=new FxiBizCode("BANK_CODE_NOT_EXSIT",ServiceCode.Fxi,"012","银行代码不存在");
    
    public static final FxiBizCode NO_PROCESS_MATCHED=new FxiBizCode("NO_PROCESS_MATCHED",ServiceCode.Fxi,"013","没有匹配到对应的流程");
    
    public static final FxiBizCode NO_CHANNEL_DARA=new FxiBizCode("NO_CHANNEL_DARA",ServiceCode.Fxi,"016","主数据未返回渠道数据");
    
    public static final FxiBizCode EXCHANGE_CODE_NULL=new FxiBizCode("EXCHANGE_CODE_NULL",ServiceCode.Fxi,"017","主数据未返回渠道数据");
    
    public static final FxiBizCode RECOVER_AMT_NOT_EQUALS_TRANS_AMT=new FxiBizCode("RECOVER_AMT_NOT_EQUALS_TRANS_AMT",ServiceCode.Fxi,"018","对账金额和交易金额不一致");
    
    public static final FxiBizCode EXCHANGE_CODE_UNABLE=new FxiBizCode("EXCHANGE_CODE_UNABLE",ServiceCode.Fxi,"019","金融交换代码不可用");
    
    public static final FxiBizCode RESULT_TYPE_INVALID=new FxiBizCode("RESULT_TYPE_INVALID",ServiceCode.Fxi,"020","应答类型非法");
    
    public static final FxiBizCode COMMON_UNKOWN=new FxiBizCode("COMMON_UNKOWN",ServiceCode.Fxi,"003","交易未知或处理中");
    
    public static final FxiBizCode INSTRUCTION_CAST_ERROR=new FxiBizCode("INSTRUCTION_CAST_ERROR",ServiceCode.Fxi,"022","交易指令转换异常");
    
    public static final FxiBizCode IP_INVALID=new FxiBizCode("IP_INVALID",ServiceCode.Fxi,"061","请求IP非法");
    
    public static final FxiBizCode TRANS_STATUS_ERROR=new FxiBizCode("TRANS_STATUS_ERROR",ServiceCode.Fxi,"072","对象状态不正确，不能操作");
    
    
    public static final FxiBizCode NO_AUTHORITY=new FxiBizCode("NO_AUTHORITY",ServiceCode.Fxi,"091","权限不足");
    
    public static final FxiBizCode SYSTEM_TIMEOUT=new FxiBizCode("SYSTEM_TIMEOUT",ServiceCode.Fxi,"098","系统超时");
    
    public static final FxiBizCode TRANSACTION_DATA_NOT_EXISTS=new FxiBizCode("TRANSACTION_DATA_NOT_EXISTS",ServiceCode.Fxi,"070","交易数据不存在");
    
    public static final FxiBizCode ILLEGAL_SETTLE_STATUS=new FxiBizCode("ILLEGAL_SETTLE_STATUS",ServiceCode.Fxi,"023","清算状态非法");
    
    public static final FxiBizCode REQUEST_BIZ_NO_DUPLICATE=new FxiBizCode("REQUEST_BIZ_NO_DUPLICATE",ServiceCode.Fxi,"071","请求方流水重复");
    
    public static final FxiBizCode SETTLE_SERIAL_NO_DUPLICATE=new FxiBizCode("SETTLE_SERIAL_NO_DUPLICATE",ServiceCode.Fxi,"024","清算流水号重复");
    
    public static final FxiBizCode GW_RESULT_NULL=new FxiBizCode("GW_RESULT_NULL",ServiceCode.Fxi,"025","网关返回结果为空");
    
    public static final FxiBizCode RESULT_CODE_MAP_NULL=new FxiBizCode("RESULT_CODE_MAP_NULL",ServiceCode.Fxi,"026","应答码映射为空");
    
    public static final FxiBizCode CHNNELROUTER_RESULT_NULL=new FxiBizCode("CHNNELROUTER_RESULT_NULL",ServiceCode.Fxi,"027","渠道路由结果为空");
    
    public static final FxiBizCode CURRENT_STATUS_EXCHANGED=new FxiBizCode("CURRENT_STATUS_EXCHANGED",ServiceCode.Fxi,"028","当前状态已变迁为目标状态");
    
    public static final FxiBizCode PURCHASE_TRANSATION_NULL=new FxiBizCode("PURCHASE_TRANSATION_NULL",ServiceCode.Fxi,"029","消费指令为空");
    
    public static final FxiBizCode GREATER_THAN_ORIGIN=new FxiBizCode("GREATER_THAN_ORIGIN",ServiceCode.Fxi,"030","总退款金额大于原交易金额");
    
    public static final FxiBizCode AGREEMENT_NO_NULL=new FxiBizCode("AGREEMENT_NO_NULL",ServiceCode.Fxi,"031","未签约，交易不能进行");
    
    public static final FxiBizCode RECOVER_REMOTESUCC_LOCALEFAIL=new FxiBizCode("RECOVER_REMOTESUCC_LOCALEFAIL",ServiceCode.Fxi,"032","对账恢复，银行成功，本地失败");
    
    public static final FxiBizCode RECOVER_REMOTEFAIL_LOCALSUCC=new FxiBizCode("RECOVER_REMOTEFAIL_LOCALSUCC",ServiceCode.Fxi,"033","对账恢复，银行失败，本地成功");
    
    public static final FxiBizCode NOTIFY_RECONE_FAIL=new FxiBizCode("NOTIFY_RECONE_FAIL",ServiceCode.Fxi,"034","通知对账记流水失败");
    
    public static final FxiBizCode RESP_AMOUNT_NOT_EQUAL=new FxiBizCode("RESP_AMOUNT_NOT_EQUAL",ServiceCode.Fxi,"035","应答金额与交换金额不等");
    
    public static final FxiBizCode REPOSITORY_DATA_ACCESS_ERROR=new FxiBizCode("REPOSITORY_DATA_ACCESS_ERROR",ServiceCode.Fxi,"097","数据库操作异常");
    
    public static final FxiBizCode REPOSITORY_CACHE_ACCESS_ERROR=new FxiBizCode("REPOSITORY_CACHE_ACCESS_ERROR",ServiceCode.Fxi,"036","缓存操作异常");
    
    public static final FxiBizCode INTEGRATION_MESSAGEGW_ERROR=new FxiBizCode("INTEGRATION_MESSAGEGW_ERROR",ServiceCode.Fxi,"037","调用MESSAGEGW异常");
    
    public static final FxiBizCode Fxi_Cache_Refresh_Fail=new FxiBizCode("Fxi_Cache_Refresh_Fail",ServiceCode.Fxi,"038","缓存刷新失败");

    public static final FxiBizCode Fxi_Gen_Third_Seq_Fail=new FxiBizCode("Fxi_Gen_Third_Seq_Fail",ServiceCode.Fxi,"039","生成第三方流水失败");
    
    public static final FxiBizCode Fxi_Get_Router_Fail=new FxiBizCode("Fxi_Get_Router_Fail",ServiceCode.Fxi,"040","获取路由信息失败");
    
    public static final FxiBizCode Fxi_Channel_NoExist=new FxiBizCode("Fxi_Channel_NoExist",ServiceCode.Fxi,"041","渠道不存在");

    public static final FxiBizCode InvokeAcctUnKnownErr=new FxiBizCode("InvokeAcctUnKnownErr",ServiceCode.Fxi,"042","调用账务未异常");
    
    
    protected FxiBizCode() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    public FxiBizCode(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }
}
