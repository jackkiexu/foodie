package com.zb.framework.enums;

import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 资金类型<br/>
 *
 * Created by  2015/1/29.
 */
public final class CashType extends AbstractEnum implements Serializable {
    private static final long serialVersionUID = 5901542148867311972L;

    public static final CashType V = new CashType("V", "滚钱宝");      // virtual

    public static final CashType B = new CashType("B", "银行卡");      // bank

    public static final CashType Z = new CashType("Z", "混合类型");     // mix

    public static final CashType R = new CashType("R", "红包");        // red

    public static final CashType C = new CashType("C", "优惠券");      // coupon

    public static final CashType O = new CashType("O", "其他");        // other

    protected CashType() {
        super(); // 解决反序列化无法构造新实例的问题！！
    }

    protected CashType(String name, String desc) {
        super(name, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return CashType.class;
    }
}
