/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.spring.flow.support;

import com.zb.framework.base.AbstractRequest;
import com.zb.framework.base.AbstractResponse;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.context.AbstractContext;
import com.zb.framework.framework.flow.converter.AbstractConverter;
import com.zb.framework.framework.flow.template.AbstractPipelineTemplate;
import com.zb.framework.framework.flow.util.FlowContainer;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;
import com.zb.framework.framework.validator.ValidatorBuilder;
import org.springframework.beans.factory.InitializingBean;

import java.util.List;

/**
 * Created by  2015/4/24.
 */
public class SpringHoldTemplate<T extends AbstractRequest> extends AbstractPipelineTemplate<T> implements InitializingBean {
    private AbstractConverter<? extends AbstractContext, T
            , ? extends AbstractResponse, ? extends AbstractFlowVo> converter = null;

    private List<Handler> handlers = null;

    public AbstractConverter<? extends AbstractContext, T

            , ? extends AbstractResponse, ? extends AbstractFlowVo> getConverter() {
        return converter;
    }

    public void setConverter(AbstractConverter<? extends AbstractContext
            , T, ? extends AbstractResponse, ? extends AbstractFlowVo> converter) {
        this.converter = converter;
    }

    public void setHandlers(List<Handler> handlers) {
        this.handlers = handlers;
    }

    @Override
    protected void fillHandlers(FlowContainer<Handler> container) {
        for(Handler handler : handlers) {
            container.add(handler);
        }
    }

    @Override
    protected AbstractConverter<? extends AbstractContext, T
            , ? extends AbstractResponse, ? extends AbstractFlowVo> createConverter() {
        return converter;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        new ValidatorBuilder().notEmpty("模板处理（handler）列表不能为空")
                .build().validate(handlers);

        new ValidatorBuilder().notNull("转换器（converter）不能为null")
                .build().validate(converter);
    }
}
