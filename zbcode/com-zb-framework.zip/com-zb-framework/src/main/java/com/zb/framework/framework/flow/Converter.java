package com.zb.framework.framework.flow;

import com.zb.framework.base.AbstractRequest;
import com.zb.framework.base.AbstractResponse;
import com.zb.framework.framework.flow.context.AbstractContext;

/**
 * 1、Pipe line参数转换器，用于将服务调用的请求参数转换为内部pipe line参数以及业务需要使用的上下文对象<br/>
 * 2、服务调用成功后，通过转换器获取返回值实例<br/>
 *
 * Created by  2014/12/10.
 */
public interface Converter<TContext extends AbstractContext, TIn extends AbstractRequest, TOut extends AbstractResponse> {
    /**
     * 将业务参数转换为Pipe line执行上下文<br/>
     *
     * @param request
     * @return
     */
    TContext  toContext(TIn request);

    /**
     * 将Pipe line执行上下文转换为业务返回值<br/>
     *
     * @param context
     * @return
     */
    TOut toResponse(AbstractContext context);
}
