package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 数据状态<br/>
 *
 *
 */
public final class CoreStatus extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = 239777752289079524L;

    public static final CoreStatus Invalid = new CoreStatus("Invalid", "0", "失效");

    public static final CoreStatus Valid = new CoreStatus("Valid", "1", "有效");

    public static final CoreStatus PreRelease = new CoreStatus("PreRelease", "2", "预发");

    public static final CoreStatus Other = new CoreStatus("Other", "9", "产品查询预发数据");

    protected CoreStatus() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected CoreStatus(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return CoreStatus.class;
    }
}
