package com.zb.framework.framework.flow.util;

import com.zb.framework.framework.flow.Listener;

/**
 * Created by  2014/12/13.
 */
public class FlowListenerContainer extends AbstractFlowContainer<Listener> implements FlowContainer<Listener> {
    public FlowListenerContainer(int capacity) {
        super(capacity);
    }
}
