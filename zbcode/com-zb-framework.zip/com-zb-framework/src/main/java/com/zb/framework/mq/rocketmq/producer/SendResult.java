package com.zb.framework.mq.rocketmq.producer;

/**
 * Created by  2015/1/14.
 */
public class SendResult {
    /**
     * 成功发送消息后，消息的Id值<br/>
     *
     */
    private String messageId = null;

    /**
     * 消息发送状态<br/>
     *
     */
    private SendStatus status = SendStatus.Unknown;

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public SendStatus getStatus() {
        return status;
    }

    public void setStatus(SendStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "SendResult{" +
                "messageId='" + messageId + '\'' +
                ", status=" + status +
                '}';
    }
}
