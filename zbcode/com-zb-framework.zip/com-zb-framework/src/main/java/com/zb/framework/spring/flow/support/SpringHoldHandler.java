/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.spring.flow.support;

import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.Listener;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContextAware;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;

import java.util.Collections;
import java.util.List;

/**
 *
 * Created by  2015/4/23.
 */
public class SpringHoldHandler extends SpringHoldBaseHandler implements Handler, ApplicationContextAware, InitializingBean {
    /**
     * 被代理的处理器<br/>
     *
     */
    private Handler holdHandler = null;

    @Override
    protected boolean doHandle(final Context context, AbstractFlowVo callerParam) {
        if(!getEnableTransaction()) {
            return holdHandler.handle(context);
        } else {
            return getTransactionTemplate().execute(new TransactionCallback<Boolean>() {
                @Override
                public Boolean doInTransaction(TransactionStatus status) {
                    return holdHandler.handle(context);
                }
            });
        }
    }

    public Handler getHoldHandler() {
        return holdHandler;
    }

    public void setHoldHandler(Handler holdHandler) {
        this.holdHandler = holdHandler;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        super.afterPropertiesSet();

        // 自动注解；
        getApplicationContext().getAutowireCapableBeanFactory().autowireBean(holdHandler);
    }

    @Override
    protected List<Listener> getProxyListeners() {
        final List<Listener> list = holdHandler.getListeners();
        return CollectionUtils.isEmpty(list) ? Collections.EMPTY_LIST : list;
    }
}
