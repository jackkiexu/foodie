package com.zb.framework.framework.validator;

/**
 * 验证者<br/>
 *
 * Created by  2014/12/14.
 */
public interface Validator {
    /**
     * 执行验证操作<br/>
     *
     */
    void validate(Object target);
}
