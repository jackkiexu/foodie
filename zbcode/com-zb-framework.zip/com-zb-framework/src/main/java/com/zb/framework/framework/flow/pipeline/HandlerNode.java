package com.zb.framework.framework.flow.pipeline;


import com.zb.framework.enums.BizCode;
import com.zb.framework.exception.BizException;
import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.Listener;
import com.zb.framework.framework.flow.Pipeline;
import com.zb.framework.framework.flow.listener.AroundListener;
import com.zb.framework.framework.flow.listener.ExceptionListener;
import com.zb.framework.framework.flow.listener.PostListener;
import com.zb.framework.framework.flow.listener.PreListener;

import java.util.List;

/**
 * 处理器节点数据结构<br/>
 *
 * Created by  2014/12/12.
 */
public class HandlerNode {
    /**
     * 当前需要执行的处理器实例<br/>
     *
     */
    private Handler handler = null;

    /**
     * 下一个将会执行的处理器节点<br/>
     *
     */
    private HandlerNode next = null;

    /**
     * 指向执行引擎<br/>
     *
     */
    private Pipeline pipeline = null;

    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public HandlerNode getNext() {
        return next;
    }

    public void setNext(HandlerNode next) {
        this.next = next;
    }

    /**
     * 执行节点逻辑<br/>
     *
     */
    public void exec(Context context) {
        Handler h = getHandler();
        if(h == null) {
            throw new BizException(BizCode.BizDataNotExists
                    , "[CTS flow] 处理器实例不能为null.");
        }

        List<Listener> listeners = h.getListeners();
        // 处理监听器
        preListener(listeners);

        boolean _continue = false;
        try {
            // 处理监听器
            tryListener(listeners);

            _continue = h.handle(context);

            if(_continue && null != getNext()) {
                getNext().exec(context);
            }

            // 处理监听器
            // 备注：异常情况下不会执行！
            postListener(listeners);
        } catch (Exception e) {
            // 处理监听器
            caughtListener(listeners, e);

            throwContinue(e);
        } finally {
            // 处理监听器
            finallyListener(listeners);
        }
    }

    public void caughtListener(List<Listener> listeners, Exception e) {
        for (Listener listener : listeners) {
            if(listener instanceof ExceptionListener) {
                ((AroundListener)listener).onCaught(getPipeline(), e);
            }
        }
    }

    public void postListener(List<Listener> listeners) {
        for (Listener listener : listeners) {
            if(listener instanceof PostListener) {
                ((PostListener)listener).onExecuted(getPipeline());
            }
        }
    }

    public void finallyListener(List<Listener> listeners) {
        for (Listener listener : listeners) {
            if(listener instanceof AroundListener) {
                ((AroundListener)listener).onFinally(getPipeline());
            }
        }
    }

    public void tryListener(List<Listener> listeners) {
        for (Listener listener : listeners) {
            if(listener instanceof AroundListener) {
                ((AroundListener)listener).onTry(getPipeline());
            }
        }
    }

    public void preListener(List<Listener> listeners) {
        for (Listener listener : listeners) {
            if(listener instanceof PreListener) {
                ((PreListener)listener).onGoing(getPipeline());
            }
        }
    }

    private void throwContinue(Exception e) {
        if(e instanceof RuntimeException) {
            throw (RuntimeException)e;
        } else {
            throw new RuntimeException(e);
        }
    }

    public Pipeline getPipeline() {
        return pipeline;
    }

    public void setPipeline(Pipeline pipeline) {
        this.pipeline = pipeline;
    }
}
