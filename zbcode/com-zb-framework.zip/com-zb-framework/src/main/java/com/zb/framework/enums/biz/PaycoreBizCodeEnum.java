/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

/**
 * 支付核心返回码枚举
 * @author 
 * @version $Id: PaycoreBizCodeEnum.java, v 0.1 2015年1月21日 下午11:11:42  Exp $
 */
public class PaycoreBizCodeEnum  extends BizCode{
    /**  */
    private static final long serialVersionUID = -5307358386379263533L;
    
    public static final PaycoreBizCodeEnum userSignChannelEmpty=new PaycoreBizCodeEnum("userSignChannelEmpty",ServiceCode.PayCore,"001","用户签约渠道不存在");
    public static final PaycoreBizCodeEnum bankChannelEmpty=new PaycoreBizCodeEnum("bankChannelEmpty",ServiceCode.PayCore,"002","用户签约渠道不存在");
    
    public static final PaycoreBizCodeEnum InitPayinfoFail=new PaycoreBizCodeEnum("InitPayinfoFail",ServiceCode.PayCore,"003","初始化支付信息失败");
    public static final PaycoreBizCodeEnum PayinfoPayTypeErr=new PaycoreBizCodeEnum("PayinfoPayTypeErr",ServiceCode.PayCore,"004","支付类型不正确");
    public static final PaycoreBizCodeEnum PendingPayinfoFail=new PaycoreBizCodeEnum("PendingPayinfoFail",ServiceCode.PayCore,"005","更新支付信息状态处理中失败");
    public static final PaycoreBizCodeEnum PendingPayinfoDetailFail=new PaycoreBizCodeEnum("PendingPayinfoDetailFail",ServiceCode.PayCore,"006","更新支付信息状态处理中失败");
    public static final PaycoreBizCodeEnum SetPayBranchIdFail=new PaycoreBizCodeEnum("SetPayBranchIdFail",ServiceCode.PayCore,"007","设置支付分机构失败");
    
    
    
    
    public static final PaycoreBizCodeEnum AcctTxnCodeNotFund=new PaycoreBizCodeEnum("AcctTxnCodeNotFund",ServiceCode.PayCore,"008","无法映射账务交易码");
    
    public static final PaycoreBizCodeEnum PayCore_CacheRefresh_Fail=new PaycoreBizCodeEnum("PayCore_CacheRefresh_Fail",ServiceCode.PayCore,"009","缓存刷新失败");
    public static final PaycoreBizCodeEnum PayCore_ActivityId_NotExist=new PaycoreBizCodeEnum("PayCore_ActivityId_NotExist",ServiceCode.PayCore,"010","无法获取事务编号");
    public static final PaycoreBizCodeEnum PayCore_Amount_UnMatch=new PaycoreBizCodeEnum("PayCore_Amount_UnMatch",ServiceCode.PayCore,"011","金额不匹配");
    public static final PaycoreBizCodeEnum PayCore_Decision_NoData=new PaycoreBizCodeEnum("PayCore_Decision_NoData",ServiceCode.PayCore,"012","决策结果不存在");
    
    public static final PaycoreBizCodeEnum UpdatePayinfoDetailFail=new PaycoreBizCodeEnum("UpdatePayinfoDetailFail",ServiceCode.PayCore,"013","更新支付信息明细状态失败");
    
    public static final PaycoreBizCodeEnum UpdatePayinfoFail=new PaycoreBizCodeEnum("UpdatePayinfoFail",ServiceCode.PayCore,"014","更新支付信息状态失败");
    
    public static final PaycoreBizCodeEnum PaycorePayInfoNotExist=new PaycoreBizCodeEnum("PaycorePayInfoNotExist",ServiceCode.PayCore,"015","支付信息不存在");
    
    public static final PaycoreBizCodeEnum PaycoreLuckyPayFail=new PaycoreBizCodeEnum("PaycoreLuckyPayFail",ServiceCode.PayCore,"016","红包支付失败");
    
    public static final PaycoreBizCodeEnum PayCoreUpdatePayinfoDetailFail=new PaycoreBizCodeEnum("PayCoreUpdatePayinfoDetailFail",ServiceCode.PayCore,"017","更新支付明细失败");
    
    public static final PaycoreBizCodeEnum PayCoreUpdatePayinfoFail=new PaycoreBizCodeEnum("PayCoreUpdatePayinfoFail",ServiceCode.PayCore,"018","更新支付信息失败");
    
    public static final PaycoreBizCodeEnum PayCoreAddProdBookFail=new PaycoreBizCodeEnum("PayCoreAddProdBookFail",ServiceCode.PayCore,"019","添加产品账失败");
    
    public static final PaycoreBizCodeEnum PayCoreUpdateProdBookFail=new PaycoreBizCodeEnum("PayCoreUpdateProdBookFail",ServiceCode.PayCore,"020","更新产品账失败");
    
    public static final PaycoreBizCodeEnum PayCorePayToolNotConfig=new PaycoreBizCodeEnum("PayCorePayToolNotConfig",ServiceCode.PayCore,"021","支付工具未配置");
    
    public static final PaycoreBizCodeEnum InvokeFxiUnKnownErr=new PaycoreBizCodeEnum("InvokeFxiUnKnownErr",ServiceCode.PayCore,"997","调用资金流入未知错误");
    public static final PaycoreBizCodeEnum InvokeAcctUnKnownErr=new PaycoreBizCodeEnum("InvokeAcctUnKnownErr",ServiceCode.PayCore,"998","调用账务未知错误");
    //最终失败错误，指未入库的失败，与上游系统约定若返回此此代码就认为最终失败，其它错可以做掉单处理。
    public static final PaycoreBizCodeEnum FinalFailure=new PaycoreBizCodeEnum("FinalFailure",ServiceCode.PayCore,"996","最终失败错误");
    public static final PaycoreBizCodeEnum PayCore_Unknown=new PaycoreBizCodeEnum("PayCore_Unknown",ServiceCode.PayCore,"999","交易未知或处理中");
    protected PaycoreBizCodeEnum() {
        ;
    }
    
    /**
     * @param name
     * @param service
     * @param code
     * @param desc
     */
    public PaycoreBizCodeEnum(String name, ServiceCode service, String code, String desc) {
        super(name, service, code, desc);
    }

    
}
