package com.zb.framework.framework.flow;

import com.zb.framework.framework.flow.enums.PhaseCode;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;
import com.zb.framework.framework.flow.vo.ResponseAttributes;

/**
 * Pipe line上下文信息<br/>
 *
 * Created by  2014/12/10.
 */
public interface Context {
    /**
     * 当前上下文是否是异步执行环境（Async Environment），如果需要进入异步执行环境，
     * 需要在工作流参数中设置{@link com.zb.framework.framework.flow.enums.FlowAttribute#IS_ASYNC}附加参数<br/>
     *
     * @return
     */
    boolean isAsyncEnvironment();

    /**
     * 获取Pipe line的入口参数<br/>
     *
     * @return
     */
    AbstractFlowVo getCallerParam();

    /**
     * 获取起点阶段编码，默认情况下就是pipe line的第一个节点，只有在异步执行环境下才可能是其他节点<br/>
     *
     * <pre>
     *     Note： 此阶段编码表示pipe line从哪个节点开始运行.
     * </pre>
     *
     * @return
     */
    PhaseCode getStarting();

    /**
     * 返回给调用方的属性集合<br/>
     *
     * @return
     */
    ResponseAttributes getResponseAttributes();

    /**
     * 节点是否在starting phase节点后面<br/>
     *
     * @return
     */
    boolean isBehindStartingPhase();

    /**
     * 获取自定义的附加对象，可能不同的handler需要特殊的数据<br/>
     *
     * @param key
     * @return
     */
    Object getAttachObject(String key);
}
