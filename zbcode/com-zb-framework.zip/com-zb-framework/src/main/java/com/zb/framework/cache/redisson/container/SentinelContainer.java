/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.container;

import com.zb.framework.cache.redisson.RedissonContainer;
import com.zb.framework.cache.redisson.config.MultiConfig;
import com.zb.framework.cache.redisson.config.SentinelConfig;
import com.zb.framework.functor.Transformer;
import com.zb.framework.util.CoreListUtils;
import org.redisson.Config;
import org.redisson.SentinelServersConfig;

import java.util.List;

/**
 * Created by  2015/5/6.
 */
public class SentinelContainer extends MultiContainer implements RedissonContainer {
    public SentinelContainer(List<SentinelConfig> configs) {
        super(CoreListUtils.transform(configs
                , new Transformer<SentinelConfig, MultiConfig>(){
            @Override
            public MultiConfig transform(SentinelConfig o) {
                return o;
            }
        }));
    }

    @Override
    protected Config createConfig(MultiConfig config) {
        SentinelConfig $config = (SentinelConfig) config;

        Config c = new Config();
        c.setCodec(config.getCodec());
        c.setThreads($config.getThreads());

        final SentinelServersConfig server = c.useSentinelConnection();
        server.setMasterName($config.getMasterName());
        server.setMasterConnectionPoolSize($config.getMasterConnectionPoolSize());
        server.setSlaveConnectionPoolSize($config.getSlaveConnectionPoolSize());
        server.setTimeout($config.getTimeout());
        server.setRetryAttempts($config.getRetryAttempts());
        server.setRetryInterval($config.getRetryInterval());
        server.setTimeout($config.getTimeout());
        server.addSentinelAddress($config.getSentinelAddressList().toArray(new String[0]));

        return c;
    }

    @Override
    protected String[] getAddressList(MultiConfig config) {
        SentinelConfig $config = (SentinelConfig) config;

        return $config.getSentinelAddressList().toArray(new String[0]);
    }
}
