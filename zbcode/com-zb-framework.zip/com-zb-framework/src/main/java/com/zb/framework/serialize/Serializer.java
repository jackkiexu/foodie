package com.zb.framework.serialize;

import java.io.Serializable;

/**
 * 序列化/反序列化接口<br/>
 *
 * Created by  2015/1/13.
 */
public interface Serializer {
    /**
     * 序列化对象<br/>
     *
     * @param object
     * @return
     */
    byte[] serialize(Serializable object);

    /**
     * 反序列化字节为java对象<br/>
     *
     * @return
     */
    Serializable deserialize(byte[] bin);
}
