package com.zb.framework.framework.flow.pipeline;

import com.zb.framework.base.AbstractRequest;
import com.zb.framework.base.AbstractResponse;
import com.zb.framework.framework.flow.Converter;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.Pipeline;
import com.zb.framework.framework.flow.context.AbstractContext;
import com.zb.framework.framework.flow.enums.PhaseCode;

/**
 * Created by  2014/12/12.
 */
public class DefaultPipeline implements Pipeline {
    /**
     * 工作chain的头部<br/>
     *
     */
    private HandlerNode head = new HandlerNode();

    /**
     * 工作chain的尾部<br/>
     *
     */
    private HandlerNode tail = null;

    /**
     * 执行上下文参数<br/>
     *
     */
    private AbstractContext context = null;

    /**
     * 类型转换器<br/>
     *
     */
    private Converter<? extends AbstractContext
            , ? extends AbstractRequest, ? extends AbstractResponse> converter = null;

    public DefaultPipeline() {
        this(null);
    }

    public DefaultPipeline(AbstractContext context) {
        setContext(context);

        setTail(head);
    }

    @Override
    public void offer(Handler... handlers) {
        // 不要使用apache commons utils，减少外部依赖
        if(handlers == null || handlers.length == 0) {
            return;
        }

        HandlerNode pre = head.getNext();
        for (Handler handler : handlers) {
            if(handler == null) {
                continue;
            }

            HandlerNode node = new HandlerNode();
            node.setPipeline(this);
            node.setHandler(handler);
            node.setNext(pre);

            pre = node;
        }

        head.setNext(pre);
    }

    @Override
    public void append(Handler... handlers) {
        if(handlers == null || handlers.length == 0) {
            return;
        }

        HandlerNode next = tail;
        for (Handler handler : handlers) {
            if(handler == null) {
                continue;
            }

            HandlerNode node = new HandlerNode();
            node.setPipeline(this);
            node.setHandler(handler);
            next.setNext(node);

            next = node;
        }

        tail = next;
    }

    @Override
    public void start() {
        // TODO 完善异常处理
        head.getNext().exec(getContext());
    }

    @Override
    public void start(PhaseCode phase) {
        // TODO 完善异常处理
        getContext().setStarting(phase);
        head.getNext().exec(getContext());
    }

    @Override
    public <TRes extends AbstractResponse> TRes toResponse() {
        return (TRes)getConverter().toResponse(getContext());
    }

    @Override
    public
    Converter<? extends AbstractContext
            , ? extends AbstractRequest, ? extends AbstractResponse> getConverter() {
        return this.converter;
    }

    @Override
    public void setConverter(Converter converter) {
        this.converter = converter;
    }

    public HandlerNode getHead() {
        return head;
    }

    public void setHead(HandlerNode head) {
        this.head = head;
    }

    public HandlerNode getTail() {
        return tail;
    }

    public void setTail(HandlerNode tail) {
        this.tail = tail;
    }

    public AbstractContext getContext() {
        return context;
    }

    public void setContext(AbstractContext context) {
        this.context = context;
    }
}
