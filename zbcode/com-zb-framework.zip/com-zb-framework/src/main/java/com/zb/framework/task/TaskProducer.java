/**
 * 
 * Copyright (c) 2015-2015 All Rights Reserved.
 */
package com.zb.framework.task;

import java.util.List;

/**
 * 
 * 
 * @author 
 * @version $Id: TaskProducer.java, v 0.1 2015年2月6日 上午9:54:37  Exp $
 */
public interface TaskProducer {
	List<Task<?>> produceList();
}
