/**
 * 
 *
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.cache.redisson.container;

import com.zb.framework.cache.redisson.RedissonContainer;
import com.zb.framework.cache.redisson.config.MasterSlaveConfig;
import com.zb.framework.cache.redisson.config.MultiConfig;
import com.zb.framework.functor.Transformer;
import com.zb.framework.util.CoreListUtils;
import org.apache.commons.collections.CollectionUtils;
import org.redisson.Config;
import org.redisson.MasterSlaveServersConfig;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by  2015/5/6.
 */
public class MasterSlaveContainer extends MultiContainer implements RedissonContainer {
    public MasterSlaveContainer(List<MasterSlaveConfig> configs) {
        super(CoreListUtils.transform(configs
                , new Transformer<MasterSlaveConfig, MultiConfig>() {
            @Override
            public MultiConfig transform(MasterSlaveConfig o) {
                return o;
            }
        }));
    }

    @Override
    protected Config createConfig(MultiConfig config) {
        MasterSlaveConfig $config = (MasterSlaveConfig) config;

        Config c = new Config();
        c.setCodec(config.getCodec());
        c.setThreads($config.getThreads());

        final MasterSlaveServersConfig server = c.useMasterSlaveConnection();
        server.setMasterAddress($config.getMasterAddress());
        server.setTimeout($config.getTimeout());
        server.setRetryAttempts($config.getRetryAttempts());
        server.setRetryInterval($config.getRetryInterval());
        server.setMasterConnectionPoolSize($config.getMasterConnectionPoolSize());
        server.setSlaveConnectionPoolSize($config.getSlaveConnectionPoolSize());
        server.setTimeout($config.getTimeout());

        if(CollectionUtils.isEmpty($config.getSlaveAddressList())) {
            server.addSlaveAddress($config.getSlaveAddressList().toArray(new String[0]));
        } else {
            server.addSlaveAddress($config.getMasterAddress());
        }

        return c;
    }

    @Override
    protected String[] getAddressList(MultiConfig config) {
        MasterSlaveConfig $config = new MasterSlaveConfig();

        List<String> all = new ArrayList<>();
        all.addAll($config.getSlaveAddressList());
        all.add($config.getMasterAddress());

        return all.toArray(new String[0]);
    }
}
