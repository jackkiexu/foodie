package com.zb.framework.framework.flow.handler;

import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.enums.PhaseCode;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;

/**
 * 数据准备处理器基类<br/>
 *
 * Created by  2014/12/26.
 */
public abstract class AbstractPrepareHandler extends AbstractHandler implements Handler {
    @Override
    protected boolean doHandle(final Context context,final AbstractFlowVo callerParam) {

        // 进行必要的数据准备
        doPrepare(context, callerParam);

        return true;
    }

    /**
     * 进行数据准备逻辑<br/>
     *
     * @param context
     * @param callerParam
     */
    protected abstract void doPrepare(final Context context,final AbstractFlowVo callerParam);

    @Override
    public PhaseCode getPhaseCode() {
        return PhaseCode.PREPARE;
    }
}
