package com.zb.framework.framework.flow.handler;

import com.zb.framework.framework.flow.Context;
import com.zb.framework.framework.flow.Handler;
import com.zb.framework.framework.flow.enums.PhaseCode;
import com.zb.framework.framework.flow.vo.AbstractFlowVo;
import com.zb.framework.framework.validator.ValidatorBuilder;

/**
 * 验证业务基类<br/>
 *
 * Created by  2014/12/14.
 */
public abstract class AbstractValidateHandler
        extends AbstractUnskippableHandler implements Handler {
    @Override
    protected boolean doHandle(final Context context,final AbstractFlowVo callerParam) {

        // 进行必要的验证逻辑
        doValidate(context, callerParam);

        return true;
    }

    /**
     * 验证参数的正确性与合法性<br/>
     *
     * @param context
     * @param callerParam
     */
    protected abstract void doValidate(final Context context,final AbstractFlowVo callerParam);

    /**
     * 创建一个Validator Builder实例，方便子类使用<br/>
     *
     * @return
     */
    protected ValidatorBuilder newBuilder() {
        return new ValidatorBuilder();
    }

    @Override
    public PhaseCode getPhaseCode() {
        return PhaseCode.VALIDATE;
    }
}
