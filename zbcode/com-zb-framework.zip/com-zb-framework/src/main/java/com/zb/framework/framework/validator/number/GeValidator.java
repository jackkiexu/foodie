package com.zb.framework.framework.validator.number;

import com.zb.framework.framework.validator.Validator;

/**
 * Created by  2014/12/15.
 */
public class GeValidator extends AbstractNumberValidator implements Validator {
    public GeValidator(Object referObject) {
        super(referObject);
    }

    @Override
    protected Type getType() {
        return Type.GE;
    }
}
