/**
 * 
 * Copyright (c) 2014-2015 All Rights Reserved.
 */
package com.zb.framework.enums.biz;

import com.zb.framework.enums.BizCode;
import com.zb.framework.enums.ServiceCode;

import java.io.Serializable;

/**
 * @ClassName: BonusBizCode
 * @Description:
 * @author 
 * @date 2015年6月23日 下午2:32:38
 * @version V1.0
 */
public class BonusBizCode extends BizCode implements Serializable {

    private static final long serialVersionUID = -2887421342455086313L;

	/** 返回码组成3位系统编码+3位编码 */
	/** 1开头的警告级别的错误 */
	/** 2开头的业务级别的错误 */
	/** 8开头的数据库级别的错误 */
	/** 9开头的系统级别的错误 */

	public static final BonusBizCode BONUS_CALL_ACCTRANS_FAIL = new BonusBizCode(
			"BONUS_CALL_ACCTRANS_FAIL", ServiceCode.Bonus, "201", "调用账务异常");

	public static final BonusBizCode BONUS_FIELD_NOT_NULL = new BonusBizCode(
			"BONUS_FIELD_NOT_NULL", ServiceCode.Bonus, "202", "关键字段不能为空");

	public static final BonusBizCode BONUS_ACTIVITY_NOT_REG = new BonusBizCode(
			"BONUS_ACTIVITY_NOT_REG", ServiceCode.Bonus, "203", "红包营销活动未登记");

	public static final BonusBizCode BONUS_ACTIVITY_LMT_FULL = new BonusBizCode(
			"BONUS_ACTIVITY_LMT_FULL", ServiceCode.Bonus, "204", "红包营销发行额度已使用完成");

	public static final BonusBizCode BONUS_OPEN_REDACCOUNT_FAIL = new BonusBizCode(
			"BONUS_OPEN_REDACCOUNT_FAIL", ServiceCode.Bonus, "205", "开立红包账户失败");

	public static final BonusBizCode BONUS_ISSUE_REDACCOUNT_FAIL = new BonusBizCode(
			"BONUS_ISSUE_REDACCOUNT_FAIL", ServiceCode.Bonus, "206", "开立红包账户失败");

	public static final BonusBizCode BONUS_REG_MKMJNL_FAIL = new BonusBizCode(
			"BONUS_REG_MKMJNL_FAIL", ServiceCode.Bonus, "207", "登记红包营销交易流水表失败");

	public static final BonusBizCode BONUS_UPD_MKMJNL_FAIL = new BonusBizCode(
			"BONUS_UPD_MKMJNL_FAIL", ServiceCode.Bonus, "208", "更新红包营销交易流水表失败");

	public static final BonusBizCode BONUS_DEDUCTION_MKMLMT_FAIL = new BonusBizCode(
			"BONUS_DEDUCTION_MKMLMT_FAIL", ServiceCode.Bonus, "209", "扣减红包营销发行额度失败");

	public static final BonusBizCode BONUS_RECOVER_MKMLMT_FAIL = new BonusBizCode(
			"BONUS_RECOVER_MKMLMT_FAIL", ServiceCode.Bonus, "210", "恢复红包营销发行额度失败");

	public static final BonusBizCode BONUS_START_XTS_FAIL = new BonusBizCode(
			"BONUS_START_XTS_FAIL", ServiceCode.Bonus, "211", "开启分布式事务失败");

	public static final BonusBizCode BONUS_ACTIVITY_DATE_INVALID = new BonusBizCode(
			"BONUS_ACTIVITY_DATE_INVALID", ServiceCode.Bonus, "212", "营销活动的有效期无效");

	public static final BonusBizCode BONUS_ACTIVITY_RED_EXIST = new BonusBizCode(
			"BONUS_ACTIVITY_RED_EXIST", ServiceCode.Bonus, "213", "营销活动中该红包已发放");

	public static final BonusBizCode BONUS_ACTIVITYDTL_NOT_REG = new BonusBizCode(
			"BONUS_ACTIVITYDTL_NOT_REG", ServiceCode.Bonus, "214", "红包营销活动明细未登记");

	public static final BonusBizCode BONUS_ACTIVITY_DTL_LMT_FULL = new BonusBizCode(
			"BONUS_ACTIVITY_DTL_LMT_FULL", ServiceCode.Bonus, "215", "使用红包的额度超过红包可用额度");

	public static final BonusBizCode BONUS_ACTIVITY_DTL_LESS_BEGORDAMT = new BonusBizCode(
			"BONUS_ACTIVITY_DTL_LESS_BEGORDAMT", ServiceCode.Bonus, "216", "小于订单起始使用金额");

	public static final BonusBizCode BONUS_ACTIVITY_DTL_LESS_BEGREFAMT = new BonusBizCode(
			"BONUS_ACTIVITY_DTL_LESS_BEGREFAMT", ServiceCode.Bonus, "217", "小于红包最低使用金额");

	public static final BonusBizCode BONUS_ACTIVITY_DTL_OVER_ENDREFAMT = new BonusBizCode(
			"BONUS_ACTIVITY_DTL_OVER_ENDREFAMT", ServiceCode.Bonus, "218", "超过红包最高使用金额");

	public static final BonusBizCode BONUS_ACTIVITY_DTL_BAL_EXP = new BonusBizCode(
			"BONUS_ACTIVITY_DTL_BAL_EXP", ServiceCode.Bonus, "219", "红包营销活动明细表余额异常");

	public static final BonusBizCode BONUS_TXID_BUS_ERROR = new BonusBizCode(
			"BONUS_TXID_BUS_ERROR", ServiceCode.Bonus, "220", "红包营销加入到分布式事务失败");

	public static final BonusBizCode BONUS_UPD_MKMDTL_FAIL = new BonusBizCode(
			"BONUS_UPD_MKMDTL_FAIL", ServiceCode.Bonus, "221", "更新红包营销明细表失败");

	public static final BonusBizCode BONUS_TOTAMT_DTLAMT_NOTEQU = new BonusBizCode(
			"BONUS_TOTAMT_DTLAMT_NOTEQU", ServiceCode.Bonus, "222", "主单金额与明细金额累计不一致");

	public static final BonusBizCode BONUS_HOLD_REDACCOUNT_FAIL = new BonusBizCode(
			"BONUS_HOLD_REDACCOUNT_FAIL", ServiceCode.Bonus, "223", "冻结红包账户失败");

	public static final BonusBizCode BONUS_MKM_JNL_NOT_EXIST = new BonusBizCode(
			"BONUS_MKM_JNL_NOT_EXIST", ServiceCode.Bonus, "224", "该事务ID无该流水记录");

	public static final BonusBizCode BONUS_REG_MKM_HLD_FAIL = new BonusBizCode(
			"BONUS_REG_MKM_HLD_FAIL", ServiceCode.Bonus, "225", "登记红包营销冻结表失败");

	public static final BonusBizCode BONUS_UPD_MKM_DTL_FAIL = new BonusBizCode(
			"BONUS_UPD_MKM_DTL_FAIL", ServiceCode.Bonus, "226", "更新红包营销明细表失败");

	public static final BonusBizCode BONUS_UPD_USE_LMT_FAIL = new BonusBizCode(
			"BONUS_UPD_USE_LMT_FAIL", ServiceCode.Bonus, "227", "更新红包营销活动的使用额度失败");

	public static final BonusBizCode BONUS_NOT_JOIN_MKM_ACTIVITY = new BonusBizCode(
			"BONUS_NOT_JOIN_MKM_ACTIVITY", ServiceCode.Bonus, "228", "基金产品未参与该营销活动");

	public static final BonusBizCode BONUS_UNHOLD_REDACCOUNT_FAIL = new BonusBizCode(
			"BONUS_UNHOLD_REDACCOUNT_FAIL", ServiceCode.Bonus, "229", "解冻红包账户失败");

	public static final BonusBizCode BONUS_UPD_MKM_HLD_FAIL = new BonusBizCode(
			"BONUS_UPD_MKM_HLD_FAIL", ServiceCode.Bonus, "230", "更新红包营销冻结表失败");

	public static final BonusBizCode BONUS_BIZ_USERID_NOTEQU = new BonusBizCode(
			"BONUS_BIZ_USERID_NOTEQU", ServiceCode.Bonus, "231", "入参的商户号与营销活动商户号不一致");

	public static final BonusBizCode BONUS_OLD_JNL_NOT_EXIST = new BonusBizCode(
			"BONUS_OLD_JNL_NOT_EXIST", ServiceCode.Bonus, "232", "原交易记录不存在");

	public static final BonusBizCode BONUS_REFUND_AMT_NOT_ENOUGH = new BonusBizCode(
			"BONUS_REFUND_AMT_NOT_ENOUGH", ServiceCode.Bonus, "233", "退款金额不足");

	public static final BonusBizCode BONUS_NOT_FUND_BUY = new BonusBizCode(
			"BONUS_NOT_FUND_BUY", ServiceCode.Bonus, "234", "该营销活动不支持该基金的购买");

	public static final BonusBizCode BONUS_OBTAIN_TIME_OVER_LIMIT = new BonusBizCode(
			"BONUS_OBTAIN_TIME_OVER_LIMIT", ServiceCode.Bonus, "235", "该营销活动领取超过最大次数限制");

	public static final BonusBizCode BONUS_USED_OVER_LIMIT = new BonusBizCode(
			"BONUS_USED_OVER_LIMIT", ServiceCode.Bonus, "236", "该营销活动超过单次使用张数限制");

	public static final BonusBizCode BONUS_OBTAIN_AMT_OVER_LIMIT = new BonusBizCode(
			"BONUS_OBTAIN_AMT_OVER_LIMIT", ServiceCode.Bonus, "237", "该营销活动领取超过最大金额限制");

	public static final BonusBizCode BONUS_USED_OVER_ORDAMT = new BonusBizCode(
			"BONUS_USED_OVER_ORDAMT", ServiceCode.Bonus, "238", "使用红包的额度超过订单金额");

	public static final BonusBizCode BONUS_USED_BEGORDAMT_OVER_ORDAMT = new BonusBizCode(
			"BONUS_USED_BEGORDAMT_OVER_ORDAMT", ServiceCode.Bonus, "239", "红包起始最低订单金额超过订单金额");

	/** 8开头的数据库级别的错误 */
	/** db幂等异常 */
	public static final BonusBizCode BONUS_DB_SYSTEM_ERROR = new BonusBizCode(
			"BONUS_DB_SYSTEM_ERROR", ServiceCode.Bonus, "899", "db幂等异常");

	/** 9开头的系统级别的错误 */
	/** 类转换失败 */
	public static final BonusBizCode BONUS_SYSTEM_CLASS_CONVERT_ERROR = new BonusBizCode(
			"BONUS_SYSTEM_CLASS_CONVERT_ERROR", ServiceCode.Bonus, "901",
			"类转换失败");

	/** 未知错误 */
	public static final BonusBizCode BONUS_UN_KNOWN = new BonusBizCode(
			"BONUS_UN_KNOWN", ServiceCode.Bonus, "998", "未知错误");

	/** 系统异常 */
	public static final BonusBizCode BONUS_SYSTEM_ERROR = new BonusBizCode(
			"BONUS_SYSTEM_ERROR", ServiceCode.Bonus, "999", "系统异常");

    private BonusBizCode(String name, ServiceCode serviceCode, String code,
                         String desc) {
		super(name, serviceCode, code, desc);
	}

	private BonusBizCode() {

	}

}
