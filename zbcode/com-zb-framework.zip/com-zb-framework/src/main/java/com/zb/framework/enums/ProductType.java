package com.zb.framework.enums;

import com.zb.framework.base.AbstractCodedEnum;
import com.zb.framework.base.AbstractEnum;

import java.io.Serializable;

/**
 * 产品类型<br/。
 *
 * Created by  2015/1/24.
 */
public final class ProductType extends AbstractCodedEnum implements Serializable {
    private static final long serialVersionUID = -8332416134081347577L;

    public static final ProductType Public = new ProductType("Public", "01", "公募基金");

//    public static final ProductType Private = new ProductType("Private", "02", "私募基金");
//
//    public static final ProductType Trust = new ProductType("Trust", "03", "信托基金");

    public static final ProductType Special  = new ProductType("Special", "04", "专户");

    protected ProductType() {
        ; // 解决反序列化无法构造新实例的问题！！
    }

    protected ProductType(String name, String code, String desc) {
        super(name, code, desc);
    }

    @Override
    protected Class<? extends AbstractEnum> getEnumType() {
        return ProductType.class;
    }
}
