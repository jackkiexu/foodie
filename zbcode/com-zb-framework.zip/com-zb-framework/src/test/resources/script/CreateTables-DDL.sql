--测试数据库表
create table hsql_test(id int primary key, name varchar(200));
CREATE SEQUENCE SEQ_TEST INCREMENT BY 1 START WITH 1;

--Order表
CREATE TABLE TCS_ORDER
(
  ID
                    VARCHAR(32)   PRIMARY KEY,
  USER_ID
                    VARCHAR(24),
  APPLY_DATE
                    VARCHAR(8),
  APPLY_TIME
                    VARCHAR(6),
  AMOUNT
                    NUMERIC(16),
  CURRENCY_CODE
                    VARCHAR(10),
  QUTY
                    NUMERIC(16),
  QUTY_SCALE
                    VARCHAR(10),

  apply_cost_type
                    VARCHAR(2),
  PRODUCT_ID
                    NUMERIC(24),
  PRODUCT_NAME
                    VARCHAR(100),
  fund_type
                    varchar(2),
  MERCHANT_ID
                    VARCHAR(24),
  WORK_DATE
                    VARCHAR(8),
  TRANS_CODE
                    VARCHAR(3),
  SUB_TRANS_CODE
                    VARCHAR(6),
  SOURCE
                    VARCHAR(2),
  BRANCH_CODE
                    VARCHAR(5),
  FEE_TYPE
                    VARCHAR(2),
  LARGE_RED_FLAG
                    varchar(2),
  REMARK
                    VARCHAR(200),
  ASSET_LAST_CONFIRM
                    NUMERIC(1),
  CREATE_TIME
                    TIMESTAMP,
  MODIFY_TIME
                    TIMESTAMP
);